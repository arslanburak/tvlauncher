package com.burak.tvlauncher

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.net.ConnectivityManager
import android.provider.Settings
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// Apple TV'den esinlenen, hafif ana ekran:
// üstte "top shelf" (seçili uygulamanın büyük görseli), altında büyük kutular satırı,
// onun altında küçük kutularla diğer uygulamalar. Harici kütüphane yok.
class MainActivity : Activity() {

    private data class AppItem(
        val pkg: String,
        val cls: String,
        val label: String,
        val image: Drawable,
        val isBanner: Boolean
    )

    // Büyük satırda bu sırayla görünür. Kalanlar alttaki küçük satıra gider.
    private val pinned = listOf(
        "com.netflix.ninja",
        "com.google.android.youtube.tv",
        "com.amazon.amazonvideo.livingroom",
        "com.disney.disneyplus",
        "com.wbd.stream",
        "com.apple.atve.androidtv.appletv",
        "com.ttnet.tivibutv",
        "com.beonetv.tod"
    )

    private val matchP = ViewGroup.LayoutParams.MATCH_PARENT
    private val wrap = ViewGroup.LayoutParams.WRAP_CONTENT
    private val bgColor = Color.parseColor("#0B0B12")

    private lateinit var hero: ImageView
    private lateinit var clock: TextView
    private lateinit var date: TextView
    private lateinit var wifiIcon: IconView
    private lateinit var label: TextView
    private lateinit var bigRow: LinearLayout
    private lateinit var smallRow: LinearLayout
    private val handler = Handler(Looper.getMainLooper())

    private val tick = object : Runnable {
        override fun run() {
            val now = Date()
            clock.text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(now)
            date.text = SimpleDateFormat("EEEE, d MMMM", Locale("tr", "TR")).format(now)
            updateWifi()
            handler.postDelayed(this, 15000)
        }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun makeRow(): Pair<HorizontalScrollView, LinearLayout> {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(64), dp(24), dp(64), dp(24))
            clipChildren = false
            clipToPadding = false
        }
        val scroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            clipChildren = false
            clipToPadding = false
            addView(row)
        }
        return Pair(scroll, row)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = FrameLayout(this)
        root.setBackgroundColor(bgColor)
        root.clipChildren = false

        // Top shelf: seçili uygulamanın büyütülmüş görseli, alttan koyuya doğru solar
        hero = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            alpha = 0f
        }
        root.addView(hero, FrameLayout.LayoutParams(matchP, matchP))

        val shade = View(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(
                    Color.argb(70, 11, 11, 18),
                    Color.argb(150, 11, 11, 18),
                    Color.argb(255, 11, 11, 18)
                )
            )
        }
        root.addView(shade, FrameLayout.LayoutParams(matchP, matchP))

        // Saat ve tarih (sağ üst)
        val timeBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.END
        }
        clock = TextView(this).apply {
            textSize = 30f
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
            setTextColor(Color.WHITE)
            gravity = Gravity.END
        }
        date = TextView(this).apply {
            textSize = 15f
            setTextColor(Color.parseColor("#B8B8C8"))
            gravity = Gravity.END
        }
        timeBox.addView(clock)
        timeBox.addView(date)
        // Sağ üst: Wi-Fi, ayarlar çarkı, saat
        wifiIcon = IconView(this, IconView.WIFI)
        val topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            clipChildren = false
        }
        topBar.addView(iconButton(wifiIcon) { openSettings(Settings.ACTION_WIFI_SETTINGS) })
        topBar.addView(
            iconButton(IconView(this, IconView.GEAR)) { openSettings(Settings.ACTION_SETTINGS) }
        )
        topBar.addView(
            timeBox,
            LinearLayout.LayoutParams(wrap, wrap).apply { setMargins(dp(24), 0, 0, 0) }
        )
        root.addView(
            topBar,
            FrameLayout.LayoutParams(wrap, wrap, Gravity.TOP or Gravity.END).apply {
                setMargins(0, dp(24), dp(48), 0)
            }
        )

        // Alt kısım: uygulama adı + büyük satır + küçük satır
        val shelf = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            clipChildren = false
            setPadding(0, 0, 0, dp(28))
        }
        label = TextView(this).apply {
            textSize = 32f
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
            setTextColor(Color.WHITE)
        }
        shelf.addView(
            label,
            LinearLayout.LayoutParams(wrap, wrap).apply { setMargins(dp(68), 0, 0, 0) }
        )
        val big = makeRow()
        bigRow = big.second
        shelf.addView(big.first, LinearLayout.LayoutParams(matchP, wrap))

        val small = makeRow()
        smallRow = small.second
        shelf.addView(small.first, LinearLayout.LayoutParams(matchP, wrap))

        root.addView(
            shelf,
            FrameLayout.LayoutParams(matchP, wrap, Gravity.BOTTOM)
        )
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        bigRow.removeAllViews()
        smallRow.removeAllViews()
        for (app in loadApps()) {
            if (pinned.contains(app.pkg)) {
                bigRow.addView(tile(app, 220, 124, 1.14f))
            } else {
                smallRow.addView(tile(app, 150, 84, 1.2f))
            }
        }
        (bigRow.getChildAt(0) ?: smallRow.getChildAt(0))?.requestFocus()
        handler.post(tick)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(tick)
    }

    // Ana ekranda Geri tuşu bir şey yapmasın.
    @Suppress("OVERRIDE_DEPRECATION")
    override fun onBackPressed() {}

    private fun loadApps(): List<AppItem> {
        val pm = packageManager
        val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER)
        return pm.queryIntentActivities(query, 0)
            .filter { it.activityInfo.packageName != packageName }
            .map {
                val banner = it.activityInfo.loadBanner(pm)
                AppItem(
                    it.activityInfo.packageName,
                    it.activityInfo.name,
                    it.loadLabel(pm).toString(),
                    banner ?: it.loadIcon(pm),
                    banner != null
                )
            }
            .sortedWith(compareBy({
                val i = pinned.indexOf(it.pkg)
                if (i >= 0) i else 1000
            }, { it.label.lowercase() }))
    }

    private fun openSettings(action: String) {
        try {
            startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            try {
                startActivity(
                    Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            } catch (_: Exception) {}
        }
    }

    @Suppress("DEPRECATION")
    private fun updateWifi() {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val ok = cm.activeNetworkInfo?.isConnected == true
        wifiIcon.setTint(if (ok) Color.WHITE else Color.parseColor("#6E6E80"))
    }

    private fun iconButton(icon: View, action: () -> Unit): View {
        val bg = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.TRANSPARENT)
        }
        val f = FrameLayout(this).apply {
            background = bg
            isFocusable = true
            addView(icon, FrameLayout.LayoutParams(matchP, matchP))
        }
        f.setOnFocusChangeListener { v, has ->
            if (has) {
                bg.setColor(Color.argb(70, 255, 255, 255))
                v.animate().scaleX(1.15f).scaleY(1.15f).setDuration(120).start()
            } else {
                bg.setColor(Color.TRANSPARENT)
                v.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
            }
        }
        f.setOnClickListener { action() }
        f.layoutParams = LinearLayout.LayoutParams(dp(48), dp(48)).apply {
            setMargins(dp(6), 0, dp(6), 0)
        }
        return f
    }

    private fun showHero(app: AppItem) {
        hero.animate().cancel()
        if (app.isBanner) {
            hero.setImageDrawable(app.image)
            hero.alpha = 0f
            hero.animate().alpha(0.85f).setDuration(250).start()
        } else {
            hero.animate().alpha(0f).setDuration(200).start()
        }
    }

    private fun tile(app: AppItem, wDp: Int, hDp: Int, focusScale: Float): View {
        val bg = GradientDrawable().apply {
            cornerRadius = dp(16).toFloat()
            setColor(Color.parseColor("#2B2B40"))
        }
        val frame = FrameLayout(this).apply {
            background = bg
            isFocusable = true
            clipToOutline = true
            elevation = dp(3).toFloat()
        }
        val img = ImageView(this).apply {
            setImageDrawable(app.image)
            if (app.isBanner) {
                scaleType = ImageView.ScaleType.CENTER_CROP
            } else {
                scaleType = ImageView.ScaleType.FIT_CENTER
                setPadding(dp(wDp / 7), dp(hDp / 6), dp(wDp / 7), dp(hDp / 6))
            }
        }
        frame.addView(img, FrameLayout.LayoutParams(matchP, matchP))

        frame.setOnFocusChangeListener { v, hasFocus ->
            if (hasFocus) {
                v.animate().scaleX(focusScale).scaleY(focusScale)
                    .translationZ(dp(14).toFloat()).setDuration(130).start()
                bg.setStroke(dp(3), Color.WHITE)
                label.text = app.label
                showHero(app)
            } else {
                v.animate().scaleX(1f).scaleY(1f).translationZ(0f).setDuration(130).start()
                bg.setStroke(0, Color.TRANSPARENT)
            }
        }
        frame.setOnClickListener {
            val i = Intent(Intent.ACTION_MAIN)
                .setClassName(app.pkg, app.cls)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            try { startActivity(i) } catch (_: Exception) {}
        }

        frame.layoutParams = LinearLayout.LayoutParams(dp(wDp), dp(hDp)).apply {
            setMargins(0, 0, dp(20), 0)
        }
        return frame
    }
}

// Resim dosyası gerektirmeyen basit çizim ikonları (Wi-Fi ve çark)
class IconView(context: Context, private val kind: Int) : View(context) {

    companion object {
        const val WIFI = 0
        const val GEAR = 1
    }

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        color = Color.WHITE
    }

    fun setTint(c: Int) {
        paint.color = c
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        paint.strokeWidth = w * 0.07f
        if (kind == WIFI) {
            val cx = w / 2f
            val cy = h * 0.68f
            paint.style = Paint.Style.FILL
            canvas.drawCircle(cx, cy, w * 0.05f, paint)
            paint.style = Paint.Style.STROKE
            for (k in 1..3) {
                val r = w * 0.15f * k
                canvas.drawArc(RectF(cx - r, cy - r, cx + r, cy + r), 225f, 90f, false, paint)
            }
        } else {
            val cx = w / 2f
            val cy = h / 2f
            val r = w * 0.2f
            canvas.drawCircle(cx, cy, r, paint)
            for (i in 0 until 8) {
                val a = Math.toRadians(i * 45.0)
                val c = Math.cos(a).toFloat()
                val s = Math.sin(a).toFloat()
                canvas.drawLine(cx + c * r * 1.35f, cy + s * r * 1.35f,
                    cx + c * r * 1.85f, cy + s * r * 1.85f, paint)
            }
        }
    }
}
