package com.burak.tvlauncher

import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.RectF
import android.graphics.RenderEffect
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.ConnectivityManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

// PiLauncher — hafif, Apple TV'den esinlenen Android TV ana ekranı.
class MainActivity : Activity() {

    companion object {
        const val VERSION = "1.0.1"
        const val REQ_PHOTO = 4201
    }

    private data class AppItem(val pkg: String, val cls: String, val label: String, val image: Drawable, val isBanner: Boolean)
    private class City(val name: String, val lat: String, val lon: String)
    private class PItem(val label: String, val glyph: Int = -1, val tint: String = "#5B6B8C", val swatch: IntArray? = null,
                        val photo: Boolean = false, val sub: String? = null, val arrow: Boolean = false, val image: Drawable? = null, val dot: Int? = null, val toggle: Boolean? = null)

    private val pinned = listOf(
        "com.netflix.ninja", "com.google.android.youtube.tv", "com.amazon.amazonvideo.livingroom",
        "com.disney.disneyplus", "com.wbd.stream", "com.apple.atve.androidtv.appletv", "com.ttnet.tivibutv", "com.beonetv.tod"
    )
    private val cities = listOf(
        City("İstanbul", "41.01", "28.98"), City("Ankara", "39.93", "32.86"), City("İzmir", "38.42", "27.14"),
        City("Bursa", "40.19", "29.06"), City("Antalya", "36.90", "30.69"), City("Adana", "37.00", "35.32"),
        City("Konya", "37.87", "32.48"), City("Gaziantep", "37.07", "37.38"), City("Şanlıurfa", "37.16", "38.80"),
        City("Kocaeli", "40.77", "29.94"), City("Mersin", "36.80", "34.64"), City("Diyarbakır", "37.91", "40.24"),
        City("Hatay", "36.20", "36.16"), City("Manisa", "38.61", "27.43"), City("Kayseri", "38.72", "35.49"),
        City("Samsun", "41.29", "36.33"), City("Balıkesir", "39.65", "27.89"), City("Trabzon", "41.00", "39.72"),
        City("Eskişehir", "39.77", "30.52"), City("Denizli", "37.78", "29.09")
    )

    // ---- ayarlanabilir değerler ----
    private val gapValues = intArrayOf(16, 24, 34)
    private val tileGap: Int get() = gapValues[prefs.getInt("gap", 1).coerceIn(0, 2)]
    private val gridPad = 64
    private val rowGap = 24
    private val frameColors = listOf("Beyaz" to "#FFFFFF", "Turuncu" to "#FF9F0A", "Mavi" to "#4C9DF0", "Yeşil" to "#46C46E", "Pembe" to "#F06AA0", "Mor" to "#9B7BEA")
    private fun frameColor() = Color.parseColor(frameColors[prefs.getInt("frameColor", 0).coerceIn(0, frameColors.size - 1)].second)
    private val frameWidths = intArrayOf(2, 3, 4)
    private fun frameWidth() = frameWidths[prefs.getInt("frameW", 1).coerceIn(0, 2)]
    private val radiusDps = intArrayOf(8, 14, 20)
    private fun tileRadiusPx(): Float { val i = prefs.getInt("radius", 1).coerceIn(0, 3); return if (i == 3) dp(tileH / 2).toFloat() else dp(radiusDps[i]).toFloat() }
    private val tileAlphas = intArrayOf(255, 180, 110)
    private fun tileBgAlpha() = tileAlphas[prefs.getInt("tileAlpha", 0).coerceIn(0, 2)]
    private val zooms = floatArrayOf(1.12f, 1.22f, 1.32f)
    private fun focusZoom() = zooms[prefs.getInt("zoom", 1).coerceIn(0, 2)]
    private val animMults = floatArrayOf(0.55f, 1.0f, 1.5f)
    private fun animDur() = (140 * animMults[prefs.getInt("anim", 1).coerceIn(0, 2)]).toLong()
    private val blurValues = intArrayOf(0, 12, 25, 42)
    private val scrimFr = floatArrayOf(0f, 0.4f, 0.72f, 1f)

    // Kutu boyutu kaydırmalı: genişlik (dp) doğrudan ayarlanır, sütun sayısı ondan hesaplanır
    private val sizeMin = 100; private val sizeMax = 260; private val sizeStep = 8
    private fun screenWdp(): Int = (resources.displayMetrics.widthPixels / resources.displayMetrics.density).toInt()
    private val tileW: Int
        get() { val def = prefs.getInt("cols", 0).let { c -> if (c > 0) (screenWdp() - 2 * gridPad) / c - tileGap else 140 }
            return prefs.getInt("tileW", def).coerceIn(sizeMin, sizeMax) }
    private fun colsFor(w: Int): Int = maxOf(1, (screenWdp() - 2 * gridPad) / (w + tileGap))
    private val cols: Int get() = colsFor(tileW)
    private val tileH: Int get() = tileW * 84 / 150

    private fun cc(vararg h: String): IntArray = IntArray(h.size) { Color.parseColor(h[it]) }
    private val bgPresets: List<Pair<String, IntArray?>> = listOf(
        Pair("Klasik (fotoğraf)", null),
        Pair("Gece mavisi", cc("#0C1220", "#101A2E", "#2B3C5A", "#1A2740", "#223256")),
        Pair("Okyanus", cc("#0A1518", "#0E2026", "#1C4A52", "#123138", "#174249")),
        Pair("Orman", cc("#0D1410", "#121D16", "#2B4536", "#1B3023", "#24402F")),
        Pair("Gün batımı", cc("#160E12", "#241219", "#5A2E3C", "#3C1E28", "#4E2734")),
        Pair("Mor sis", cc("#100D18", "#171426", "#3C3658", "#2A2440", "#352E52")),
        Pair("Kömür", cc("#141518", "#191A1E", "#303238", "#232428", "#2A2C31")),
        Pair("Gece yarısı (düz)", cc("#0B0D12", "#0E1016", "#13161D", "#15181F", "#181C24"))
    )

    private val matchP = ViewGroup.LayoutParams.MATCH_PARENT
    private val wrap = ViewGroup.LayoutParams.WRAP_CONTENT

    private lateinit var prefs: SharedPreferences
    private lateinit var root: FrameLayout
    private lateinit var clock: TextView
    private lateinit var date: TextView
    private lateinit var weatherText: TextView
    private lateinit var wxIcon: WxIconView
    private lateinit var wifiIcon: ImageView
    private lateinit var hintView: TextView
    private lateinit var topPill: LinearLayout
    private lateinit var grid: LinearLayout
    private lateinit var gridScroll: ScrollView
    private lateinit var gridBox: FrameLayout
    private lateinit var upHint: GlyphView
    private lateinit var downHint: GlyphView
    private var rowCount = 0
    private var visibleRows = 1
    private var firstRow = 0
    private lateinit var bgView: ImageView
    private lateinit var scrimView: View
    private lateinit var tintA: View
    private lateinit var tintB: View
    private var tintFront = false
    private var tintColor: Int? = null
    private var tintGen = 0
    private var wifiBtnView: View? = null
    private var gearView: View? = null

    private val handler = Handler(Looper.getMainLooper())
    private var shown = mutableListOf<AppItem>()
    private var hiddenApps = listOf<AppItem>()
    private var movingPkg: String? = null
    private var lastPkg: String? = null
    private var lastWeather = 0L
    private var saverView: View? = null
    private var saverClock: TextView? = null
    private val openDialogs = mutableListOf<Dialog>()

    private val tick = object : Runnable {
        override fun run() {
            val now = Date()
            clock.text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(now)
            date.text = SimpleDateFormat("d MMMM, EEEE", Locale("tr", "TR")).format(now); fitText(date)
            updateWifi()
            saverClock?.text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(now)
            if (System.currentTimeMillis() - lastWeather > 30 * 60 * 1000L) { lastWeather = System.currentTimeMillis(); fetchWeather() }
            handler.postDelayed(this, 15000)
        }
    }
    private val saverRunnable = Runnable { showSaver() }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
    private fun glass(radiusDp: Int, alpha: Int): GradientDrawable = GradientDrawable().apply { cornerRadius = dp(radiusDp).toFloat(); setColor(Color.argb(alpha, 20, 22, 28)); setStroke(dp(1), Color.argb(55, 255, 255, 255)) }
    private fun iconImage(res: Int): ImageView = ImageView(this).apply { setImageResource(res); setColorFilter(Color.WHITE, PorterDuff.Mode.SRC_IN); scaleType = ImageView.ScaleType.FIT_CENTER; setPadding(dp(8), dp(8), dp(8), dp(8)) }

    private fun glyphBtn(kind: Int, action: () -> Unit): View {
        val bg = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.TRANSPARENT) }
        val g = GlyphView(this, kind)
        val f = FrameLayout(this).apply { background = bg; isFocusable = true; setPadding(dp(9), dp(9), dp(9), dp(9)); addView(g, FrameLayout.LayoutParams(matchP, matchP)) }
        f.setOnFocusChangeListener { v, has -> if (has) { bg.setColor(Color.argb(90, 255, 255, 255)); v.animate().scaleX(1.15f).scaleY(1.15f).setDuration(120).start() } else { bg.setColor(Color.TRANSPARENT); v.animate().scaleX(1f).scaleY(1f).setDuration(120).start() } }
        f.setOnClickListener { action() }
        f.setOnKeyListener { _, k, e -> if (e.action == KeyEvent.ACTION_DOWN && k == KeyEvent.KEYCODE_DPAD_DOWN) { focusGrid(); true } else false }
        f.layoutParams = LinearLayout.LayoutParams(dp(36), dp(36)).apply { setMargins(dp(2), 0, dp(2), 0) }
        return f
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("launcher", Context.MODE_PRIVATE)
        // TV yeni açıldıysa (açılıştan sonraki ilk 3 dk içinde oluşturulduysak) 15 sn boyunca yayının öne geçmesine izin verme
        if (android.os.SystemClock.elapsedRealtime() < 180_000L) bootGuardUntil = android.os.SystemClock.elapsedRealtime() + 15_000L
        root = FrameLayout(this); root.setBackgroundColor(Color.parseColor("#141414")); root.clipChildren = false

        bgView = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
        root.addView(bgView, FrameLayout.LayoutParams(matchP, matchP))
        // Dinamik arka plan: seçili uygulamanın rengi iki katman arasında yumuşak geçişle yansır
        tintA = View(this).apply { alpha = 0f }; tintB = View(this).apply { alpha = 0f }
        root.addView(tintA, FrameLayout.LayoutParams(matchP, matchP)); root.addView(tintB, FrameLayout.LayoutParams(matchP, matchP))
        scrimView = View(this).apply { background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(Color.argb(0, 0, 0, 0), Color.argb(210, 0, 0, 0))) }
        root.addView(scrimView, FrameLayout.LayoutParams(matchP, (resources.displayMetrics.heightPixels * 0.6f).toInt(), Gravity.BOTTOM))
        applyBg(); applyScrim()

        grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(gridPad), 0, dp(gridPad), 0); clipChildren = false; clipToPadding = false }
        gridScroll = object : ScrollView(this@MainActivity) {
            // Otomatik kaydırma kapalı: kaydırmayı satır satır biz yapıyoruz (yarım satır görünmesin)
            override fun computeScrollDeltaToGetChildRectOnScreen(rect: android.graphics.Rect): Int = 0
        }.apply { isVerticalScrollBarEnabled = false; clipChildren = false; clipToPadding = false; addView(grid) }
        // Kap: içindeki kaydırma alanını KENDİ sınırında keser -> taşan satırlar üst panele asla çizilmez
        gridBox = FrameLayout(this).apply { clipChildren = true; clipToPadding = true; addView(gridScroll, FrameLayout.LayoutParams(matchP, matchP)) }
        // Izgara ekranın ALTINA sabit; yüksekliği rebuildRows'ta sınırlanır, üst panele asla ulaşmaz
        root.addView(gridBox, FrameLayout.LayoutParams(matchP, dp(200), Gravity.TOP).apply { topMargin = dp(150) })
        upHint = GlyphView(this, GlyphView.CHEVRON).apply { rotation = -90f; setTint(Color.argb(170, 255, 255, 255)); visibility = View.INVISIBLE }
        downHint = GlyphView(this, GlyphView.CHEVRON).apply { rotation = 90f; setTint(Color.argb(170, 255, 255, 255)); visibility = View.INVISIBLE }
        root.addView(upHint, FrameLayout.LayoutParams(dp(22), dp(22), Gravity.TOP or Gravity.CENTER_HORIZONTAL))
        root.addView(downHint, FrameLayout.LayoutParams(dp(22), dp(22), Gravity.TOP or Gravity.CENTER_HORIZONTAL))

        buildTopBar()

        hintView = TextView(this).apply { text = "← → ↑ ↓ ile taşı   ·   Tamam ile bitir"; textSize = 14f; setTextColor(Color.WHITE); background = glass(30, 205); setPadding(dp(22), dp(10), dp(22), dp(10)); visibility = View.GONE }
        root.addView(hintView, FrameLayout.LayoutParams(wrap, wrap, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { setMargins(0, dp(96), 0, 0) })

        setContentView(root)
        val pf = android.content.IntentFilter().apply { addAction(Intent.ACTION_PACKAGE_ADDED); addAction(Intent.ACTION_PACKAGE_REMOVED); addAction(Intent.ACTION_PACKAGE_CHANGED); addAction(Intent.ACTION_PACKAGE_REPLACED); addDataScheme("package") }
        try { if (Build.VERSION.SDK_INT >= 33) registerReceiver(pkgReceiver, pf, Context.RECEIVER_EXPORTED) else registerReceiver(pkgReceiver, pf) } catch (_: Exception) {}
    }

    private fun buildTopBar() {
        val timeBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.END }
        clock = TextView(this).apply { textSize = 20f; typeface = Typeface.create("sans-serif-light", Typeface.NORMAL); setTextColor(Color.WHITE); gravity = Gravity.END }
        date = TextView(this).apply { textSize = 11.5f; setTextColor(Color.parseColor("#C9C9D3")); gravity = Gravity.END; maxLines = 1 }
        wxIcon = WxIconView(this, WxIconView.CLOUD)
        weatherText = TextView(this).apply { textSize = 11.5f; setTextColor(Color.parseColor("#C9C9D3")); maxLines = 1 }
        val wxRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(6), dp(2), dp(6), dp(2)) }
        wxRow.addView(wxIcon, LinearLayout.LayoutParams(dp(15), dp(15)).apply { setMargins(0, 0, dp(5), 0) }); wxRow.addView(weatherText)
        val wxBg = GradientDrawable().apply { cornerRadius = dp(10).toFloat(); setColor(Color.TRANSPARENT) }
        val weatherBox = FrameLayout(this).apply { background = wxBg; isFocusable = true; addView(wxRow) }
        weatherBox.setOnFocusChangeListener { _, has -> wxBg.setColor(if (has) Color.argb(70, 255, 255, 255) else Color.TRANSPARENT) }
        weatherBox.setOnClickListener { if (prefs.getString("city", null) == null) showCityPanel(null) else showWeatherDetail() }
        weatherBox.setOnKeyListener { _, k, e -> if (e.action == KeyEvent.ACTION_DOWN && k == KeyEvent.KEYCODE_DPAD_DOWN) { focusGrid(); true } else false }
        timeBox.addView(clock, LinearLayout.LayoutParams(wrap, wrap)); timeBox.addView(date, LinearLayout.LayoutParams(wrap, wrap))
        timeBox.addView(weatherBox, LinearLayout.LayoutParams(wrap, wrap).apply { setMargins(0, dp(2), 0, 0) })

        wifiIcon = iconImage(R.drawable.ic_wifi)
        val wifiBtn = FrameLayout(this).apply {
            isFocusable = true
            val bg = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.TRANSPARENT) }; background = bg; addView(wifiIcon, FrameLayout.LayoutParams(matchP, matchP))
            setOnFocusChangeListener { v, has -> if (has) { bg.setColor(Color.argb(90, 255, 255, 255)); v.animate().scaleX(1.15f).scaleY(1.15f).setDuration(120).start() } else { bg.setColor(Color.TRANSPARENT); v.animate().scaleX(1f).scaleY(1f).setDuration(120).start() } }
            setOnClickListener { openSystem(Settings.ACTION_WIFI_SETTINGS) }
            setOnKeyListener { _, k, e -> if (e.action == KeyEvent.ACTION_DOWN && k == KeyEvent.KEYCODE_DPAD_DOWN) { focusGrid(); true } else false }
            layoutParams = LinearLayout.LayoutParams(dp(36), dp(36)).apply { setMargins(dp(2), 0, dp(2), 0) }
        }
        wifiBtnView = wifiBtn
        val gearBtn = glyphBtn(GlyphView.GEAR) { curCat = 0; mainRow = 0; catRow.fill(0); showSettings() }; gearView = gearBtn

        topPill = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; background = glass(28, 110); setPadding(dp(10), dp(4), dp(14), dp(4)); clipChildren = false }
        topPill.addView(wifiBtn); topPill.addView(gearBtn)
        val divider = View(this).apply { setBackgroundColor(Color.argb(60, 255, 255, 255)) }
        topPill.addView(divider, LinearLayout.LayoutParams(dp(1), dp(30)).apply { setMargins(dp(10), 0, dp(12), 0) })
        topPill.addView(timeBox)
        topPill.addOnLayoutChangeListener { v, l, t, r, b, _, ot, _, ob -> v.pivotX = (r - l).toFloat(); v.pivotY = 0f; if (b - t != ob - ot && ::gridBox.isInitialized) v.post { layoutGrid() } }
        root.addView(topPill, FrameLayout.LayoutParams(wrap, wrap, Gravity.TOP or Gravity.END).apply { setMargins(0, dp(24), dp(40), 0) })
        applyTopScale(); applyTopItems(); updateWeatherText()
    }

    private fun applyTopItems() {
        wifiBtnView?.visibility = if (prefs.getBoolean("showWifi", true)) View.VISIBLE else View.GONE
    }

    private fun focusGrid() { (lastTileView() ?: firstTile())?.requestFocus() }
    private fun firstTile(): View? = (grid.getChildAt(0) as? ViewGroup)?.getChildAt(0)
    private fun lastTileView(): View? {
        for (r in 0 until grid.childCount) { val row = grid.getChildAt(r) as ViewGroup; for (ccc in 0 until row.childCount) if (row.getChildAt(ccc).tag == lastPkg) return row.getChildAt(ccc) }
        return firstTile()
    }

    // Uygulama listesi sadece bir uygulama kurulunca/kaldırılınca/güncellenince yeniden okunur (her dönüşte değil -> hızlı)
    private var appsDirty = true
    private val pkgReceiver = object : android.content.BroadcastReceiver() { override fun onReceive(c: Context?, i: Intent?) {
        val p = i?.data?.schemeSpecificPart; if (p != null) { colorCache.remove(p); lightBgCache.remove(p) }
        appsDirty = true; if (hasWindowFocus()) { appsDirty = false; refreshApps(lastPkg) } } }
    override fun onDestroy() { try { unregisterReceiver(pkgReceiver) } catch (_: Exception) {}; handler.removeCallbacksAndMessages(null); super.onDestroy() }
    override fun onResume() { super.onResume(); if (appsDirty) { appsDirty = false; refreshApps(lastPkg) }; handler.post(tick); resetSaverTimer() }
    // ---------- Açılışta ana ekran ----------
    // Beko'nun yayın servisi (ro.vendor.mtk.auto.enter.livetv) açılışta yayını PiLauncher'ın üstüne açıyor; bu salt okunur
    // bir sistem ayarı. Çözüm: TV açıldıktan sonraki kısa sürede biz bilerek bir şey açmadıysak hemen öne geri dön.
    private var bootGuardUntil = 0L
    private var bounces = 0
    private var leavingByUser = false
    override fun startActivityForResult(intent: Intent, requestCode: Int, options: Bundle?) { leavingByUser = true; super.startActivityForResult(intent, requestCode, options) }
    override fun onPause() {
        super.onPause(); handler.removeCallbacks(tick); handler.removeCallbacks(saverRunnable)
        val now = android.os.SystemClock.elapsedRealtime()
        if (!leavingByUser && now < bootGuardUntil && bounces < 3 && prefs.getBoolean("bootHome", true)) {
            bounces++
            handler.post { try { startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)) } catch (_: Exception) {}; leavingByUser = false }
        }
        leavingByUser = false
    }
    override fun onUserInteraction() { super.onUserInteraction(); resetSaverTimer() }

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        if (saverView != null) { if (e.action == KeyEvent.ACTION_DOWN) hideSaver(); return true }
        resetSaverTimer()
        if (movingPkg != null) {
            if (e.action == KeyEvent.ACTION_DOWN) when (e.keyCode) {
                KeyEvent.KEYCODE_DPAD_LEFT -> moveBy(-1); KeyEvent.KEYCODE_DPAD_RIGHT -> moveBy(1)
                KeyEvent.KEYCODE_DPAD_UP -> moveBy(-cols); KeyEvent.KEYCODE_DPAD_DOWN -> moveBy(cols)
                KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_BACK -> endMove(); else -> {}
            }
            return true
        }
        return super.dispatchKeyEvent(e)
    }

    @Suppress("OVERRIDE_DEPRECATION")
    override fun onBackPressed() {}

    // ---------- Uygulama listesi ----------
    private fun loadAll(): List<AppItem> {
        val pm = packageManager
        val map = LinkedHashMap<String, AppItem>()
        val lean = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER), 0)
        for (ri in lean) { val p = ri.activityInfo.packageName; if (p == packageName) continue
            val banner = ri.activityInfo.loadBanner(pm)
            map[p] = AppItem(p, ri.activityInfo.name, ri.loadLabel(pm).toString(), banner ?: ri.loadIcon(pm), banner != null) }
        if (prefs.getBoolean("showAll", false)) {
            val reg = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            for (ri in reg) { val p = ri.activityInfo.packageName; if (p == packageName || map.containsKey(p)) continue
                map[p] = AppItem(p, ri.activityInfo.name, ri.loadLabel(pm).toString(), ri.loadIcon(pm), false) }
        }
        val all = map.values.toList()
        if (prefs.getInt("sort", 0) == 1) return all.sortedBy { it.label.lowercase() }
        val order = (prefs.getString("order", "") ?: "").split("|").filter { it.isNotEmpty() }
        return all.sortedWith(compareBy({ val o = order.indexOf(it.pkg); if (o >= 0) o else { val p = pinned.indexOf(it.pkg); 10000 + (if (p >= 0) p else 1000) } }, { it.label.lowercase() }))
    }

    private fun refreshApps(focusPkg: String?) {
        val all = loadAll(); val hidden = prefs.getStringSet("hidden", emptySet()) ?: emptySet()
        shown = all.filter { !hidden.contains(it.pkg) }.toMutableList(); hiddenApps = all.filter { hidden.contains(it.pkg) }
        rebuildRows(focusPkg)
    }

    private fun rebuildRows(focusPkg: String?) {
        grid.removeAllViews(); val n = cols
        // Satırları ekranda tam ortala
        val side = maxOf(gridPad / 2, (screenWdp() - n * (tileW + tileGap)) / 2); grid.setPadding(dp(side), 0, dp(side), 0)
        val views = mutableListOf<View>(); for (app in shown) views.add(tile(app)); if (hiddenApps.isNotEmpty()) views.add(hiddenTile())
        var target: View? = null; var cur: LinearLayout? = null
        views.forEachIndexed { i, v ->
            if (i % n == 0) { val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; clipChildren = false }; cur = r
                grid.addView(r, LinearLayout.LayoutParams(wrap, wrap).apply { setMargins(0, dp(halfGap()), 0, dp(halfGap())) }) }
            cur?.addView(v); if (focusPkg != null && v.tag == focusPkg) target = v
        }
        // Yüksekliği sınırla: üstte panel + geniş boşluk hep kalsın (büyüyen kutu bile panele değmesin)
        rowCount = (views.size + n - 1) / n
        layoutGrid()
        (target ?: firstTile())?.requestFocus()
    }

    // Seçili kutu büyüdüğünde sığsın diye satırın üst/alt boşluğu (dp)
    private fun halfGap(): Int = maxOf(12, Math.ceil(tileH * (focusZoom() - 1) / 2.0).toInt() + 4)
    private fun rowPx(): Int = dp(tileH) + 2 * dp(halfGap())

    // Izgarayı panelin altındaki alana, sadece TAM satırlar görünecek şekilde yerleştir
    private fun layoutGrid() {
        val screenH = resources.displayMetrics.heightPixels
        val top = pillBottomPx() + dp(16); val bottom = screenH - dp(16)
        val avail = bottom - top; val rp = rowPx()
        visibleRows = maxOf(1, avail / rp)
        val shownRows = maxOf(1, minOf(rowCount, visibleRows))
        val h = shownRows * rp
        val y = top + (avail - h) / 2
        gridBox.layoutParams = (gridBox.layoutParams as FrameLayout.LayoutParams).apply { height = h; gravity = Gravity.TOP; topMargin = y; bottomMargin = 0 }
        (upHint.layoutParams as FrameLayout.LayoutParams).topMargin = y - dp(22)
        (downHint.layoutParams as FrameLayout.LayoutParams).topMargin = y + h
        upHint.requestLayout(); downHint.requestLayout()
        firstRow = firstRow.coerceIn(0, maxOf(0, rowCount - visibleRows))
        gridScroll.post { gridScroll.scrollTo(0, firstRow * rp) }
        updateHints()
    }
    private fun updateHints() {
        upHint.visibility = if (firstRow > 0) View.VISIBLE else View.INVISIBLE
        downHint.visibility = if (firstRow + visibleRows < rowCount) View.VISIBLE else View.INVISIBLE
    }
    private fun ensureRowVisible(v: View) {
        val r = grid.indexOfChild(v.parent as? View ?: return); if (r < 0) return
        val old = firstRow
        if (r < firstRow) firstRow = r else if (r >= firstRow + visibleRows) firstRow = r - visibleRows + 1
        if (firstRow != old) { gridScroll.smoothScrollTo(0, firstRow * rowPx()); updateHints() }
    }

    private fun saveOrder() { prefs.edit().putString("order", (shown.map { it.pkg } + hiddenApps.map { it.pkg }).joinToString("|")).apply() }
    private fun startMove(app: AppItem) { movingPkg = app.pkg; hintView.visibility = View.VISIBLE; rebuildRows(app.pkg) }
    private fun moveBy(d: Int) { val mp = movingPkg ?: return; val i = shown.indexOfFirst { it.pkg == mp }; val j = i + d; if (i < 0 || j < 0 || j >= shown.size) return; val t = shown[i]; shown[i] = shown[j]; shown[j] = t; saveOrder(); rebuildRows(mp) }
    private fun endMove() { val mp = movingPkg; movingPkg = null; hintView.visibility = View.GONE; rebuildRows(mp) }
    private fun hide(app: AppItem) { val h = (prefs.getStringSet("hidden", emptySet()) ?: emptySet()).toMutableSet(); h.add(app.pkg); prefs.edit().putStringSet("hidden", h).apply(); refreshApps(null) }
    private fun unhide(app: AppItem) { val h = (prefs.getStringSet("hidden", emptySet()) ?: emptySet()).toMutableSet(); h.remove(app.pkg); prefs.edit().putStringSet("hidden", h).apply(); refreshApps(app.pkg) }
    private fun uninstall(app: AppItem) { try { startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:" + app.pkg))) } catch (_: Exception) {} }
    private fun appInfo(app: AppItem) { try { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + app.pkg)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {} }

    // ---------- Ekran koruyucu ----------
    private val saverMins = intArrayOf(1, 3, 5, 10, 15)
    private fun resetSaverTimer() { handler.removeCallbacks(saverRunnable); if (saverView != null) return; if (!prefs.getBoolean("saver", true)) return
        val idx = prefs.getInt("saverMin", 2).coerceIn(0, saverMins.size - 1); handler.postDelayed(saverRunnable, saverMins[idx] * 60_000L) }
    private fun showSaver() {
        if (saverView != null) return
        if (openDialogs.isNotEmpty()) { while (openDialogs.isNotEmpty()) openDialogs.removeAt(0).dismiss() }
        val ov = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        saverClock = TextView(this).apply { text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date()); textSize = 92f; typeface = Typeface.create("sans-serif-thin", Typeface.NORMAL); setTextColor(Color.WHITE); gravity = Gravity.CENTER }
        val d = TextView(this).apply { text = SimpleDateFormat("d MMMM, EEEE", Locale("tr", "TR")).format(Date()); textSize = 20f; setTextColor(Color.parseColor("#B8B8C4")); gravity = Gravity.CENTER }
        col.addView(saverClock); col.addView(d)
        val wx = prefs.getString("wx", null); val city = prefs.getString("city", null)
        if (prefs.getInt("saverStyle", 0) == 0 && wx != null && city != null) { val p = wx.split("|"); col.addView(TextView(this).apply { text = city + " · " + p[0] + " " + (if (p.size > 1) p[1] else ""); textSize = 18f; setTextColor(Color.parseColor("#9AA0AC")); gravity = Gravity.CENTER; setPadding(0, dp(12), 0, 0) }) }
        ov.addView(col, FrameLayout.LayoutParams(wrap, wrap, Gravity.CENTER)); root.addView(ov, FrameLayout.LayoutParams(matchP, matchP)); saverView = ov
    }
    private fun hideSaver() { saverView?.let { root.removeView(it) }; saverView = null; saverClock = null; resetSaverTimer() }

    // ---------- Paneller ----------
    private fun panelBox(): LinearLayout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), dp(12), dp(10), dp(10))
        background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(Color.argb(222, 40, 42, 48), Color.argb(228, 22, 23, 27))).apply { cornerRadius = dp(20).toFloat(); setStroke(dp(1), Color.argb(55, 255, 255, 255)) } }
    private var dialogAt = 0L
    // Uzun basıştan kalan OK tuşu yeni paneldeki ilk satırı yanlışlıkla seçmesin
    private fun tooSoon(): Boolean = android.os.SystemClock.uptimeMillis() - dialogAt < 350
    private fun registerDialog(dlg: Dialog) { dialogAt = android.os.SystemClock.uptimeMillis(); for (d in openDialogs.toList()) if (d !== dlg) { try { d.dismiss() } catch (_: Exception) {} }; openDialogs.add(dlg); dlg.setOnKeyListener { _, _, _ -> resetSaverTimer(); false }; dlg.setOnDismissListener { openDialogs.remove(dlg); resetSaverTimer() }; resetSaverTimer() }
    private fun styleWindow(dlg: Dialog, widthDp: Int, toRight: Boolean = true) {
        val w = dlg.window ?: return; w.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT)); w.setLayout(dp(widthDp), ViewGroup.LayoutParams.WRAP_CONTENT)
        w.setGravity(Gravity.TOP or (if (toRight) Gravity.END else Gravity.CENTER_HORIZONTAL)); w.setDimAmount(0.12f); val lp = w.attributes; lp.y = pillBottomPx() + dp(12); if (toRight) lp.x = dp(40); w.attributes = lp
    }
    private fun pillBottomPx(): Int = if (topPill.height == 0) dp(130) else (topPill.top + topPill.height * topPill.scaleY).toInt()
    private fun panelListMax(): Int = maxOf(dp(150), resources.displayMetrics.heightPixels - pillBottomPx() - dp(12) - dp(24) - dp(96))
    private fun titleView(t: String): TextView = TextView(this).apply { text = t; textSize = 14.5f; typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL); setTextColor(Color.WHITE); letterSpacing = 0.01f; setPadding(dp(10), dp(2), dp(10), dp(9)) }
    private fun footView(t: String): TextView = TextView(this).apply { text = t; textSize = 10.5f; setTextColor(Color.parseColor("#7E7E89")); setPadding(dp(10), dp(8), dp(10), 0) }

    // Tek satır (kendi tıklamasıyla) — bölümlü menü için
    private fun menuRow(item: PItem, onClick: () -> Unit): View {
        val rowBg = GradientDrawable().apply { cornerRadius = dp(11).toFloat(); setColor(Color.TRANSPARENT) }
        val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; isFocusable = true; background = rowBg; setPadding(dp(8), dp(6), dp(10), dp(6)) }
        if (item.glyph >= 0) { val ic = FrameLayout(this).apply { background = GradientDrawable().apply { cornerRadius = dp(7).toFloat(); setColor(Color.parseColor(item.tint)) } }
            ic.addView(GlyphView(this, item.glyph), FrameLayout.LayoutParams(matchP, matchP)); r.addView(ic, LinearLayout.LayoutParams(dp(26), dp(26)).apply { setMargins(0, 0, dp(10), 0) }) }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(TextView(this).apply { text = item.label; textSize = 13f; setTextColor(Color.WHITE) })
        item.sub?.let { col.addView(TextView(this).apply { text = it; textSize = 10.5f; setTextColor(Color.parseColor("#9A9AA6")) }) }
        r.addView(col, LinearLayout.LayoutParams(0, wrap, 1f))
        if (item.dot != null) r.addView(View(this).apply { background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(item.dot); setStroke(dp(1), Color.argb(90, 255, 255, 255)) } }, LinearLayout.LayoutParams(dp(13), dp(13)).apply { setMargins(0, 0, dp(8), 0) })
        val sw: SwitchView? = if (item.toggle != null) SwitchView(this, item.toggle).also { r.addView(it, LinearLayout.LayoutParams(dp(38), dp(23))) } else null
        if (sw == null && item.arrow) { val ch = GlyphView(this, GlyphView.CHEVRON); ch.setTint(Color.parseColor("#8E8E99")); r.addView(ch, LinearLayout.LayoutParams(dp(16), dp(16))) }
        r.setOnFocusChangeListener { _, has -> rowBg.setColor(if (has) Color.argb(46, 255, 255, 255) else Color.TRANSPARENT); rowBg.setStroke(if (has) dp(1) else 0, Color.argb(70, 255, 255, 255)) }
        r.setOnClickListener { if (!tooSoon()) { sw?.flip(); onClick() } }
        return r
    }

    // Çoktan seçmeli panel (canlı önizleme için stayOpen)
    private fun showPanel(title: String, items: List<PItem>, checked: Int, parent: (() -> Unit)?, stayOpen: Boolean, focusAt: Int = -1, onPick: (Int) -> Unit) {
        val dlg = Dialog(this); dlg.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val box = panelBox(); box.addView(titleView(title))
        box.addView(View(this).apply { setBackgroundColor(Color.argb(35, 255, 255, 255)) }, LinearLayout.LayoutParams(matchP, dp(1)).apply { setMargins(0, 0, 0, dp(6)) })
        val selectable = stayOpen || checked >= 0
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val checks = arrayOfNulls<GlyphView>(items.size); var focusTarget: View? = null
        items.forEachIndexed { i, item ->
            val rowBg = GradientDrawable().apply { cornerRadius = dp(11).toFloat(); setColor(Color.TRANSPARENT) }
            val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; isFocusable = true; background = rowBg; setPadding(dp(8), dp(6), dp(10), dp(6)) }
            if (item.glyph >= 0) { val ic = FrameLayout(this).apply { background = GradientDrawable().apply { cornerRadius = dp(7).toFloat(); setColor(Color.parseColor(item.tint)) } }
                ic.addView(GlyphView(this, item.glyph), FrameLayout.LayoutParams(matchP, matchP)); r.addView(ic, LinearLayout.LayoutParams(dp(26), dp(26)).apply { setMargins(0, 0, dp(10), 0) }) }
            else if (item.photo || item.swatch != null) { val sw: View = if (item.photo) ImageView(this).apply { setImageDrawable(currentBgThumb()); scaleType = ImageView.ScaleType.CENTER_CROP; background = GradientDrawable().apply { cornerRadius = dp(7).toFloat(); setColor(Color.DKGRAY) }; clipToOutline = true }
                else View(this).apply { background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, item.swatch).apply { cornerRadius = dp(7).toFloat() } }
                r.addView(sw, LinearLayout.LayoutParams(dp(26), dp(26)).apply { setMargins(0, 0, dp(10), 0) }) }
            else if (item.image != null) { val iv = ImageView(this).apply { setImageDrawable(item.image); scaleType = ImageView.ScaleType.FIT_CENTER; background = GradientDrawable().apply { cornerRadius = dp(7).toFloat(); setColor(Color.parseColor("#20222A")) }; clipToOutline = true; setPadding(dp(7), dp(5), dp(7), dp(5)) }
                r.addView(iv, LinearLayout.LayoutParams(dp(44), dp(32)).apply { setMargins(0, 0, dp(12), 0) }) }
            val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            if (item.label.isNotEmpty()) col.addView(TextView(this).apply { text = item.label; textSize = 13f; setTextColor(Color.WHITE) })
            item.sub?.let { col.addView(TextView(this).apply { text = it; textSize = 10.5f; setTextColor(Color.parseColor("#9A9AA6")) }) }
            r.addView(col, LinearLayout.LayoutParams(0, wrap, 1f))
            if (item.dot != null) r.addView(View(this).apply { background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(item.dot); setStroke(dp(1), Color.argb(90, 255, 255, 255)) } }, LinearLayout.LayoutParams(dp(13), dp(13)).apply { setMargins(0, 0, dp(8), 0) })
            val sw: SwitchView? = if (item.toggle != null) SwitchView(this, item.toggle).also { r.addView(it, LinearLayout.LayoutParams(dp(38), dp(23))) } else null
            if (sw != null) {}
            else if (selectable) { val ck = GlyphView(this, GlyphView.CHECK); ck.visibility = if (i == checked) View.VISIBLE else View.INVISIBLE; r.addView(ck, LinearLayout.LayoutParams(dp(18), dp(18))); checks[i] = ck }
            else if (item.arrow) { val ch = GlyphView(this, GlyphView.CHEVRON); ch.setTint(Color.parseColor("#8E8E99")); r.addView(ch, LinearLayout.LayoutParams(dp(16), dp(16))) }
            r.setOnFocusChangeListener { _, has -> rowBg.setColor(if (has) Color.argb(46, 255, 255, 255) else Color.TRANSPARENT); rowBg.setStroke(if (has) dp(1) else 0, Color.argb(70, 255, 255, 255)) }
            r.setOnClickListener { if (tooSoon()) return@setOnClickListener
                if (sw != null) { sw.flip(); onPick(i) }
                else if (stayOpen) { checks.forEachIndexed { k, v -> v?.visibility = if (k == i) View.VISIBLE else View.INVISIBLE }; onPick(i) } else { dlg.dismiss(); onPick(i) } }
            list.addView(r, LinearLayout.LayoutParams(matchP, wrap).apply { setMargins(0, dp(1), 0, dp(1)) })
            if (i == (if (focusAt >= 0) focusAt else if (checked >= 0) checked else 0)) focusTarget = r
        }
        box.addView(ScrollView(this).apply { isVerticalScrollBarEnabled = false; addView(list) }, LinearLayout.LayoutParams(matchP, minOf(dp(items.size * 44), panelListMax())))
        box.addView(footView(backText(parent)))
        dlg.setContentView(box); styleWindow(dlg, 310); registerDialog(dlg)
        dlg.setOnCancelListener { parent?.invoke() }; dlg.setOnShowListener { focusTarget?.requestFocus() }; dlg.show()
    }

    private fun showInput(title: String, hint: String, initial: String, parent: (() -> Unit)?, onDone: (String) -> Unit) {
        val dlg = Dialog(this); dlg.requestWindowFeature(Window.FEATURE_NO_TITLE); val box = panelBox(); box.addView(titleView(title))
        val et = EditText(this).apply { setText(initial); this.hint = hint; setHintTextColor(Color.parseColor("#7C7C88")); setTextColor(Color.WHITE); textSize = 16f; setSingleLine(); imeOptions = EditorInfo.IME_ACTION_DONE
            background = GradientDrawable().apply { cornerRadius = dp(12).toFloat(); setColor(Color.argb(60, 255, 255, 255)) }; setPadding(dp(14), dp(10), dp(14), dp(10)) }
        et.setOnEditorActionListener { v, a, _ -> if (a == EditorInfo.IME_ACTION_DONE || a == EditorInfo.IME_ACTION_SEARCH) { dlg.dismiss(); onDone(v.text.toString().trim()); true } else false }
        box.addView(et, LinearLayout.LayoutParams(matchP, wrap)); box.addView(footView(backText(parent)))
        dlg.setContentView(box); styleWindow(dlg, 320); registerDialog(dlg); dlg.setOnCancelListener { parent?.invoke() }; dlg.show()
    }

    private fun showMenu(app: AppItem) {
        showPanel("Seçenekler", listOf(PItem("Taşı", GlyphView.MOVE, "#4C7DF0"), PItem("Gizle", GlyphView.EYE_OFF, "#8A6BD6"), PItem("Kaldır", GlyphView.TRASH, "#C25A5A"), PItem("Uygulama bilgisi", GlyphView.INFO, "#6F7684")), -1, null, false) { w -> when (w) { 0 -> startMove(app); 1 -> hide(app); 2 -> uninstall(app); 3 -> appInfo(app); else -> {} } }
    }
    private fun showHidden(parent: (() -> Unit)? = null) {
        if (hiddenApps.isEmpty()) { Toast.makeText(this, "Gizli uygulama yok", Toast.LENGTH_SHORT).show(); parent?.invoke(); return }
        val dlg = Dialog(this); dlg.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val box = panelBox(); box.addView(titleView("Gizlenenler")); box.addView(TextView(this).apply { text = "Ana ekrana geri almak için seç"; textSize = 10.5f; setTextColor(Color.parseColor("#9A9AA6")); setPadding(dp(10), 0, dp(10), dp(8)) })
        box.addView(View(this).apply { setBackgroundColor(Color.argb(35, 255, 255, 255)) }, LinearLayout.LayoutParams(matchP, dp(1)).apply { setMargins(0, 0, 0, dp(10)) })
        val ncol = 3; val tw = 90; val th = 51; val gap = 9
        // Büyüyen (seçili) kutu kenarlardan kesilmesin diye pay bırak, kırpmayı kapat
        val gridL = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; clipChildren = false; clipToPadding = false; setPadding(dp(8), dp(6), dp(8), dp(6)) }
        var rowL: LinearLayout? = null; var first: View? = null
        hiddenApps.forEach { app ->
            if (rowL == null || rowL!!.childCount >= ncol) { rowL = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; clipChildren = false }; gridL.addView(rowL, LinearLayout.LayoutParams(wrap, wrap).apply { setMargins(0, 0, 0, dp(gap)) }) }
            val tileBg = GradientDrawable().apply { cornerRadius = dp(12).toFloat(); setColor(if (needsLightBg(app)) Color.parseColor("#ECECF2") else Color.parseColor("#2A2C36")) }
            val ring = GradientDrawable().apply { cornerRadius = dp(12).toFloat(); setColor(Color.TRANSPARENT); setStroke(dp(1), Color.argb(40, 255, 255, 255)) }
            val f = FrameLayout(this).apply { background = tileBg; foreground = ring; isFocusable = true; clipToOutline = true }
            val iv = ImageView(this).apply { setImageDrawable(app.image); if (app.isBanner) scaleType = ImageView.ScaleType.CENTER_CROP else { scaleType = ImageView.ScaleType.FIT_CENTER; setPadding(dp(12), dp(8), dp(12), dp(8)) } }
            f.addView(iv, FrameLayout.LayoutParams(matchP, matchP))
            f.setOnFocusChangeListener { v, has -> if (has) { v.animate().scaleX(1.1f).scaleY(1.1f).translationZ(dp(6).toFloat()).setDuration(120).start(); ring.setStroke(dp(2), frameColor()) } else { v.animate().scaleX(1f).scaleY(1f).translationZ(0f).setDuration(120).start(); ring.setStroke(dp(1), Color.argb(40, 255, 255, 255)) } }
            f.setOnClickListener { if (!tooSoon()) { dlg.dismiss(); unhide(app) } }
            f.layoutParams = LinearLayout.LayoutParams(dp(tw), dp(th)).apply { setMargins(0, 0, if (rowL!!.childCount < ncol - 1) dp(gap) else 0, 0) }
            rowL!!.addView(f); if (first == null) first = f
        }
        val rows = (hiddenApps.size + ncol - 1) / ncol
        box.addView(ScrollView(this).apply { isVerticalScrollBarEnabled = false; clipChildren = false; addView(gridL) }, LinearLayout.LayoutParams(wrap, minOf(dp(rows * (th + gap) + 12), panelListMax())).apply { gravity = Gravity.CENTER_HORIZONTAL })
        box.addView(footView(backText(parent)))
        dlg.setContentView(box); styleWindow(dlg, 330); registerDialog(dlg); dlg.setOnCancelListener { parent?.invoke() }; dlg.setOnShowListener { first?.requestFocus() }; dlg.show()
    }

    // ---------- AYARLAR (bölümlü) ----------
    private val topScales = floatArrayOf(0.7f, 0.85f, 1.0f, 1.15f)
    private val topLabels = listOf("Çok küçük", "Küçük", "Orta", "Büyük")
    private fun applyTopScale() { val i = prefs.getInt("topScale", 1).coerceIn(0, topScales.size - 1); topPill.scaleX = topScales[i]; topPill.scaleY = topScales[i]; if (::gridBox.isInitialized) topPill.post { layoutGrid() } }

    private fun customBgFile() = File(filesDir, "custom_bg.jpg")
    private fun decodeBg(maxW: Int): android.graphics.Bitmap? { val f = customBgFile(); if (!f.exists()) return null
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }; BitmapFactory.decodeFile(f.path, o); var s = 1; while (o.outWidth / s > maxW) s *= 2
        return BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = s }) }
    private fun currentBgThumb(): Drawable { if (prefs.getBoolean("bgCustom", false)) { decodeBg(240)?.let { return android.graphics.drawable.BitmapDrawable(resources, it) } }; return resources.getDrawable(R.drawable.bg, theme) }
    private fun applyBg() {
        if (prefs.getBoolean("bgCustom", false)) { val bmp = decodeBg(1920); if (bmp != null) bgView.setImageBitmap(bmp) else bgView.setImageResource(R.drawable.bg) }
        else { val idx = prefs.getInt("bg", 0).coerceIn(0, bgPresets.size - 1); val colors = bgPresets[idx].second
            if (colors == null) bgView.setImageResource(R.drawable.bg) else bgView.setImageDrawable(GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, colors)) }
        if (Build.VERSION.SDK_INT >= 31) { val b = blurValues[prefs.getInt("blur", 0).coerceIn(0, blurValues.size - 1)]
            bgView.setRenderEffect(if (b > 0) RenderEffect.createBlurEffect(b.toFloat(), b.toFloat(), Shader.TileMode.CLAMP) else null) }
    }
    private fun applyScrim() { scrimView.alpha = scrimFr[prefs.getInt("scrim", 2).coerceIn(0, scrimFr.size - 1)] }

    // Ayarlar iki seviyeli: Ana menü (kategoriler) -> kategori içeriği -> seçenek paneli
    // Geri: seçenek -> kategori -> ana menü -> kapat
    private val catNames = listOf("Görünüm", "Ana ekran", "Davranış")
    private var curCat = 0
    private var mainRow = 0
    private val catRow = IntArray(3)
    private val backToCat: () -> Unit = { showCategory(curCat) }
    private val backToMain: () -> Unit = { showSettings() }
    private fun backText(parent: (() -> Unit)?): String = when {
        parent == null -> "‹  Geri: kapat"
        parent === backToCat -> "‹  Geri: " + catNames[curCat]
        parent === backToMain -> "‹  Geri: PiLauncher ayarları"
        else -> "‹  Geri: önceki menü"
    }

    // focusAt: geri dönünce imleç en son girilen satırda dursun; onPicked: hangi satıra girildiğini kaydet
    // gapBefore: bu satırdan önce ince ayraç çiz (ana menüde kategoriler ile diğer seçenekleri ayırmak için)
    private fun showMenuList(title: String, rows: List<Pair<PItem, () -> Unit>>, parent: (() -> Unit)?, focusAt: Int = 0, gapBefore: Int = -1, onPicked: (Int) -> Unit = {}) {
        val dlg = Dialog(this); dlg.requestWindowFeature(Window.FEATURE_NO_TITLE); val box = panelBox()
        box.addView(titleView(title))
        box.addView(View(this).apply { setBackgroundColor(Color.argb(35, 255, 255, 255)) }, LinearLayout.LayoutParams(matchP, dp(1)).apply { setMargins(0, 0, 0, dp(6)) })
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        var first: View? = null
        rows.forEachIndexed { idx, (item, go) ->
            if (idx == gapBefore) list.addView(View(this).apply { setBackgroundColor(Color.argb(28, 255, 255, 255)) }, LinearLayout.LayoutParams(matchP, dp(1)).apply { setMargins(dp(10), dp(6), dp(10), dp(6)) })
            // Anahtarlı satırlar (aç/kapa) paneli kapatmadan yerinde değişir
            val v = menuRow(item) { onPicked(idx); if (item.toggle == null) dlg.dismiss(); go() }
            list.addView(v, LinearLayout.LayoutParams(matchP, wrap).apply { setMargins(0, dp(1), 0, dp(1)) })
            if (idx == focusAt.coerceIn(0, rows.size - 1)) first = v
        }
        box.addView(ScrollView(this).apply { isVerticalScrollBarEnabled = false; addView(list) }, LinearLayout.LayoutParams(matchP, minOf(dp(rows.size * 46 + (if (gapBefore >= 0) 13 else 0)), panelListMax())))
        box.addView(footView(backText(parent)))
        dlg.setContentView(box); styleWindow(dlg, 330); registerDialog(dlg)
        dlg.setOnCancelListener { parent?.invoke() }; dlg.setOnShowListener { first?.requestFocus() }; dlg.show()
    }

    private fun showSettings() {
        showMenuList("PiLauncher ayarları", listOf(
            PItem("Görünüm", GlyphView.PALETTE, "#8A6BD6", sub = "Arka plan, renkler, kutular, seçim efektleri", arrow = true) to { showCategory(0) },
            PItem("Ana ekran", GlyphView.GRID, "#4C7DF0", sub = "Düzen, uygulamalar, üst panel, hava durumu", arrow = true) to { showCategory(1) },
            PItem("Davranış", GlyphView.CLOCK, "#3FA27A", sub = "Animasyon, ekran koruyucu, açılış", arrow = true) to { showCategory(2) },
            PItem("Varsayılana sıfırla", GlyphView.RESET, "#C25A5A", sub = "Ayarları ilk hâline döndür", arrow = true) to { showResetPanel() },
            PItem("Android ayarları", GlyphView.GEAR, "#6F7684", sub = "TV'nin sistem ayarlarını aç", arrow = true) to { openSystem(Settings.ACTION_SETTINGS) }
        ), null, mainRow, gapBefore = 3) { mainRow = it }
    }

    private fun showCategory(c: Int) {
        curCat = c
        val rows: List<Pair<PItem, () -> Unit>> = when (c) {
            // Görünüm: arka plan -> kutular -> seçim efektleri
            0 -> {
                val bgName = if (prefs.getBoolean("bgCustom", false)) "Kendi fotoğrafın" else bgPresets[prefs.getInt("bg", 0).coerceIn(0, bgPresets.size - 1)].first
                listOf(
                    PItem("Arka plan", GlyphView.IMAGE, "#8A6BD6", sub = bgName, arrow = true) to { showBgPanel() },
                    PItem("Bulanıklık", GlyphView.BLUR, "#5B8BD0", sub = listOf("Kapalı", "Az", "Orta", "Çok")[prefs.getInt("blur", 0).coerceIn(0, 3)], arrow = true) to { showBlurPanel() },
                    PItem("Karartma", GlyphView.CONTRAST, "#6F7684", sub = listOf("Yok", "Az", "Orta", "Çok")[prefs.getInt("scrim", 2).coerceIn(0, 3)], arrow = true) to { showScrimPanel() },
                    PItem("Dinamik arka plan", GlyphView.PALETTE, "#C2557A", sub = "Seçili uygulamanın rengi", toggle = prefs.getBoolean("dynBg", true)) to { prefs.edit().putBoolean("dynBg", !prefs.getBoolean("dynBg", true)).apply(); tintColor = null; setTintFor(shown.firstOrNull { it.pkg == lastPkg }) },
                    PItem("Kutu köşesi", GlyphView.CORNER, "#8A6BD6", sub = listOf("Az", "Orta", "Çok", "Tam")[prefs.getInt("radius", 1).coerceIn(0, 3)], arrow = true) to { showRadiusPanel() },
                    PItem("Kutu şeffaflığı", GlyphView.OPACITY, "#3A9DB8", sub = listOf("Dolu", "Hafif", "Çok saydam")[prefs.getInt("tileAlpha", 0).coerceIn(0, 2)], arrow = true) to { showTileAlphaPanel() },
                    PItem("Seçili çerçeve rengi", GlyphView.PALETTE, "#4C7DF0", sub = frameColors[prefs.getInt("frameColor", 0).coerceIn(0, frameColors.size - 1)].first, arrow = true, dot = frameColor()) to { showFrameColorPanel() },
                    PItem("Çerçeve kalınlığı", GlyphView.SLIDERS, "#3FA27A", sub = listOf("İnce", "Orta", "Kalın")[prefs.getInt("frameW", 1).coerceIn(0, 2)], arrow = true) to { showFrameWidthPanel() },
                    PItem("Seçili büyüme", GlyphView.ZOOM, "#D98A4E", sub = listOf("Az", "Orta", "Çok")[prefs.getInt("zoom", 1).coerceIn(0, 2)], arrow = true) to { showZoomPanel() },
                    PItem("Işık parlaması", GlyphView.BLUR, "#B8A04A", sub = "Seçili kutuda cam yansıması", toggle = prefs.getBoolean("shine", true)) to { prefs.edit().putBoolean("shine", !prefs.getBoolean("shine", true)).apply() }
                )
            }
            // Ana ekran: düzen -> uygulamalar -> üst panel -> hava durumu
            1 -> listOf(
                PItem("Kutu boyutu", GlyphView.GRID, "#4C7DF0", sub = "$cols sütun · kaydırarak ayarla", arrow = true) to { showSizePanel() },
                PItem("Kutu aralığı", GlyphView.SLIDERS, "#3FA27A", sub = listOf("Dar", "Orta", "Geniş")[prefs.getInt("gap", 1).coerceIn(0, 2)], arrow = true) to { showGapPanel() },
                PItem("Uygulama sıralaması", GlyphView.SORT, "#6F7684", sub = if (prefs.getInt("sort", 0) == 1) "Alfabetik" else "Manuel", arrow = true) to { showSortPanel() },
                PItem("Gizlenenler", GlyphView.EYE_OFF, "#8A6BD6", sub = if (hiddenApps.isEmpty()) "Gizli uygulama yok" else hiddenApps.size.toString() + " uygulama", arrow = true) to { showHidden(backToCat) },
                PItem("Tüm uygulamaları göster", GlyphView.APPS, "#D98A4E", sub = "Yan yüklenenler ve sistem uygulamaları", toggle = prefs.getBoolean("showAll", false)) to { prefs.edit().putBoolean("showAll", !prefs.getBoolean("showAll", false)).apply(); refreshApps(lastPkg) },
                PItem("Üst panel boyutu", GlyphView.SLIDERS, "#3FA27A", sub = topLabels[prefs.getInt("topScale", 1).coerceIn(0, topLabels.size - 1)], arrow = true) to { showTopPanel() },
                PItem("Wi-Fi düğmesi", GlyphView.MONITOR, "#5B8BD0", sub = "Üst panelde göster", toggle = prefs.getBoolean("showWifi", true)) to { prefs.edit().putBoolean("showWifi", !prefs.getBoolean("showWifi", true)).apply(); applyTopItems() },
                PItem("Hava durumu konumu", GlyphView.CLOUD, "#3A9DB8", sub = prefs.getString("city", null) ?: "Seçilmedi", arrow = true) to { showCityPanel(backToCat) },
                PItem("Hava durumu kaynağı", GlyphView.CLOUD, "#5B8BD0", sub = wxSources[prefs.getInt("wxSrc", 0).coerceIn(0, 1)], arrow = true) to { showWxSrcPanel() }
            )
            // Davranış
            else -> {
                val saverOn = prefs.getBoolean("saver", true); val sm = prefs.getInt("saverMin", 2).coerceIn(0, saverMins.size - 1)
                listOf(
                    PItem("Animasyon hızı", GlyphView.ZOOM, "#D98A4E", sub = listOf("Hızlı", "Normal", "Yavaş")[prefs.getInt("anim", 1).coerceIn(0, 2)], arrow = true) to { showAnimPanel() },
                    PItem("Ekran koruyucu", GlyphView.MONITOR, "#5B8BD0", sub = if (saverOn) saverMins[sm].toString() + " dk sonra" else "Kapalı", arrow = true) to { showSaverPanel() },
                    PItem("Ekran koruyucu stili", GlyphView.CLOCK, "#8A6BD6", sub = if (prefs.getInt("saverStyle", 0) == 0) "Saat + hava" else "Sadece saat", arrow = true) to { showSaverStylePanel() },
                    PItem("Açılışta ana ekran", GlyphView.GRID, "#3FA27A", sub = "TV açılınca yayın yerine PiLauncher", toggle = prefs.getBoolean("bootHome", true)) to { prefs.edit().putBoolean("bootHome", !prefs.getBoolean("bootHome", true)).apply() }
                )
            }
        }
        showMenuList(catNames[c], rows, backToMain, catRow[c]) { catRow[c] = it }
    }

    private fun choice(title: String, labels: List<String>, cur: Int, key: String, def: Int, apply: () -> Unit) {
        showPanel(title, labels.map { PItem(it) }, cur, backToCat, true) { i -> prefs.edit().putInt(key, i).apply(); apply() }
    }
    private fun showScrimPanel() = choice("Karartma", listOf("Yok", "Az", "Orta", "Çok"), prefs.getInt("scrim", 2), "scrim", 2) { applyScrim() }
    private fun showBlurPanel() = choice("Bulanıklık", listOf("Kapalı", "Az", "Orta", "Çok"), prefs.getInt("blur", 0), "blur", 0) { applyBg() }
    private fun showFrameColorPanel() { val cur = prefs.getInt("frameColor", 0)
        showPanel("Seçili çerçeve rengi", frameColors.map { PItem(it.first, dot = Color.parseColor(it.second)) }, cur, backToCat, true) { i -> prefs.edit().putInt("frameColor", i).apply(); rebuildRows(lastPkg) } }
    private fun showFrameWidthPanel() = choice("Çerçeve kalınlığı", listOf("İnce", "Orta", "Kalın"), prefs.getInt("frameW", 1), "frameW", 1) { rebuildRows(lastPkg) }
    private fun showRadiusPanel() = choice("Kutu köşesi", listOf("Az", "Orta", "Çok", "Tam"), prefs.getInt("radius", 1), "radius", 1) { rebuildRows(lastPkg) }
    private fun showTileAlphaPanel() = choice("Kutu şeffaflığı", listOf("Dolu", "Hafif", "Çok saydam"), prefs.getInt("tileAlpha", 0), "tileAlpha", 0) { rebuildRows(lastPkg) }
    private fun showZoomPanel() = choice("Seçili büyüme", listOf("Az", "Orta", "Çok"), prefs.getInt("zoom", 1), "zoom", 1) { rebuildRows(lastPkg) }
    // Kaydırmalı kutu boyutu paneli: ◀ ▶ ile anında önizleme, OK kaydet ve dön, Geri dön
    private fun showSizePanel() {
        val dlg = Dialog(this); dlg.requestWindowFeature(Window.FEATURE_NO_TITLE); val box = panelBox(); box.addView(titleView("Kutu boyutu"))
        box.addView(View(this).apply { setBackgroundColor(Color.argb(35, 255, 255, 255)) }, LinearLayout.LayoutParams(matchP, dp(1)).apply { setMargins(0, 0, 0, dp(14)) })
        val levels = (sizeMax - sizeMin) / sizeStep
        var lvl = ((tileW - sizeMin + sizeStep / 2) / sizeStep).coerceIn(0, levels)
        val info = TextView(this).apply { textSize = 13.5f; setTextColor(Color.WHITE); gravity = Gravity.CENTER }
        val track = object : View(this) {
            val pp = Paint(Paint.ANTI_ALIAS_FLAG); var focusedNow = false
            override fun onDraw(c: Canvas) { val h = height / 2f; val l = dp(14).toFloat(); val r = width - l; val x = l + (r - l) * lvl / levels
                pp.color = Color.argb(60, 255, 255, 255); c.drawRoundRect(RectF(l, h - dp(3), r, h + dp(3)), dp(3).toFloat(), dp(3).toFloat(), pp)
                pp.color = frameColor(); c.drawRoundRect(RectF(l, h - dp(3), x, h + dp(3)), dp(3).toFloat(), dp(3).toFloat(), pp)
                pp.color = Color.WHITE; c.drawCircle(x, h, dp(if (focusedNow) 11 else 9).toFloat(), pp) }
        }.apply { isFocusable = true }
        val small = GlyphView(this, GlyphView.GRID).apply { scaleX = 0.7f; scaleY = 0.7f }; val big = GlyphView(this, GlyphView.GRID)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        row.addView(small, LinearLayout.LayoutParams(dp(22), dp(22))); row.addView(track, LinearLayout.LayoutParams(0, dp(40), 1f)); row.addView(big, LinearLayout.LayoutParams(dp(26), dp(26)))
        fun refresh() { val w = sizeMin + lvl * sizeStep; info.text = "%" + (lvl * 100 / levels) + "  ·  " + colsFor(w) + " sütun"; track.invalidate() }
        val applyLater = Runnable { rebuildRows(lastPkg) }
        track.setOnFocusChangeListener { _, has -> track.focusedNow = has; track.invalidate() }
        track.setOnKeyListener { _, k, e ->
            if (e.action != KeyEvent.ACTION_DOWN) return@setOnKeyListener false
            when (k) {
                KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT -> { val nl = (lvl + if (k == KeyEvent.KEYCODE_DPAD_RIGHT) 1 else -1).coerceIn(0, levels)
                    if (nl != lvl) { lvl = nl; prefs.edit().putInt("tileW", sizeMin + lvl * sizeStep).remove("cols").apply(); refresh(); handler.removeCallbacks(applyLater); handler.postDelayed(applyLater, 180) }; true }
                KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> { if (!tooSoon()) { dlg.dismiss(); backToCat() }; true }
                else -> false
            } }
        box.addView(info, LinearLayout.LayoutParams(matchP, wrap).apply { setMargins(0, 0, 0, dp(4)) })
        box.addView(row, LinearLayout.LayoutParams(matchP, wrap).apply { setMargins(dp(6), 0, dp(6), dp(4)) })
        box.addView(TextView(this).apply { text = "◀ ▶ ile ayarla, değişiklik hemen görünür · OK: kaydet"; textSize = 10.5f; setTextColor(Color.parseColor("#9A9AA6")); gravity = Gravity.CENTER })
        box.addView(footView(backText(backToCat))); refresh()
        dlg.setContentView(box); styleWindow(dlg, 330); registerDialog(dlg)
        dlg.setOnCancelListener { handler.removeCallbacks(applyLater); rebuildRows(lastPkg); backToCat() }; dlg.setOnShowListener { track.requestFocus() }; dlg.show()
    }
    private fun showGapPanel() = choice("Kutu aralığı", listOf("Dar", "Orta", "Geniş"), prefs.getInt("gap", 1), "gap", 1) { rebuildRows(lastPkg) }
    private fun showSortPanel() = choice("Uygulama sıralaması", listOf("Manuel (taşıyabilirsin)", "Alfabetik"), prefs.getInt("sort", 0), "sort", 0) { refreshApps(lastPkg) }
    private fun showTopPanel() { val cur = prefs.getInt("topScale", 1).coerceIn(0, topScales.size - 1)
        showPanel("Üst panel boyutu", topLabels.map { PItem(it) }, cur, backToCat, true) { i -> prefs.edit().putInt("topScale", i).apply(); applyTopScale() } }
    private fun showSaverPanel(focusAt: Int = -1) { val on = prefs.getBoolean("saver", true)
        val items = mutableListOf(PItem("Ekran koruyucu", GlyphView.MONITOR, "#5B8BD0", toggle = on)); saverMins.forEach { items.add(PItem("$it dakika sonra")) }
        val cur = 1 + prefs.getInt("saverMin", 2).coerceIn(0, saverMins.size - 1)
        showPanel("Ekran koruyucu", items, cur, backToCat, true, if (focusAt >= 0) focusAt else 0) { i ->
            if (i == 0) prefs.edit().putBoolean("saver", !prefs.getBoolean("saver", true)).apply()
            else { val wasOn = prefs.getBoolean("saver", true); prefs.edit().putBoolean("saver", true).putInt("saverMin", i - 1).apply(); if (!wasOn) showSaverPanel(i) }
            resetSaverTimer() } }
    private fun showWxSrcPanel() = choice("Hava durumu kaynağı", listOf("MET Norway (yr.no) · önerilen", "Open-Meteo"), prefs.getInt("wxSrc", 0), "wxSrc", 0) { prefs.edit().remove("wxfull").apply(); lastWeather = System.currentTimeMillis(); fetchWeather() }
    private fun showSaverStylePanel() = choice("Ekran koruyucu stili", listOf("Saat + hava durumu", "Sadece saat"), prefs.getInt("saverStyle", 0), "saverStyle", 0) {}
    private fun showAnimPanel() = choice("Animasyon hızı", listOf("Hızlı", "Normal", "Yavaş"), prefs.getInt("anim", 1), "anim", 1) {}
    // Sıfırlama: onay paneli, iki seçenek. Konum ve hava verisi korunur.
    private fun showResetPanel() {
        showPanel("Varsayılana sıfırla", listOf(
            PItem("Ayarları sıfırla", GlyphView.RESET, "#C25A5A", sub = "Uygulama sırası ve gizlenenler korunur"),
            PItem("Her şeyi sıfırla", GlyphView.TRASH, "#9E3B3B", sub = "Sıralama ve gizlenenler de sıfırlanır"),
            PItem("Vazgeç", GlyphView.CHEVRON, "#6F7684")), -1, backToMain, false) { i -> if (i == 2) showSettings() else resetSettings(i == 1) }
    }
    private fun resetSettings(everything: Boolean) {
        val keep = mutableSetOf("city", "lat", "lon", "wx", "wxfull")
        if (!everything) keep.addAll(listOf("order", "hidden"))
        val e = prefs.edit(); for (k in prefs.all.keys) if (k !in keep) e.remove(k); e.commit()
        if (everything) try { customBgFile().delete() } catch (_: Exception) {}
        firstRow = 0; curCat = 0; mainRow = 3; catRow.fill(0); tintColor = null
        applyBg(); applyScrim(); applyTopItems(); applyTopScale(); updateWeatherText()
        refreshApps(null); setTintFor(shown.firstOrNull { it.pkg == lastPkg }); resetSaverTimer()
        Toast.makeText(this, if (everything) "Her şey varsayılana döndü" else "Ayarlar varsayılana döndü", Toast.LENGTH_SHORT).show()
        handler.postDelayed({ showSettings() }, 150)
    }

    // ---------- Fotoğraf ----------
    private fun showBgPanel() {
        val items = mutableListOf(PItem("Kendi fotoğrafın…", GlyphView.IMAGE, "#D98A4E", arrow = true)); bgPresets.forEachIndexed { idx, p -> items.add(PItem(p.first, swatch = p.second, photo = (idx == 0))) }
        val cur = if (prefs.getBoolean("bgCustom", false)) 0 else 1 + prefs.getInt("bg", 0).coerceIn(0, bgPresets.size - 1)
        showPanel("Arka plan", items, cur, backToCat, true) { i -> if (i == 0) pickPhoto() else { prefs.edit().putBoolean("bgCustom", false).putInt("bg", i - 1).apply(); applyBg() } }
    }
    private fun pickPhoto() {
        try { startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "image/*" }, REQ_PHOTO) }
        catch (e: Exception) { try { startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).apply { type = "image/*" }, REQ_PHOTO) } catch (_: Exception) { Toast.makeText(this, "Dosya seçici bulunamadı", Toast.LENGTH_LONG).show() } }
    }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_PHOTO && resultCode == RESULT_OK) { val uri = data?.data ?: return
            Thread { try { contentResolver.openInputStream(uri)?.use { input -> FileOutputStream(customBgFile()).use { input.copyTo(it) } }
                handler.post { prefs.edit().putBoolean("bgCustom", true).apply(); applyBg(); Toast.makeText(this, "Arka plan güncellendi", Toast.LENGTH_SHORT).show() } }
                catch (e: Exception) { handler.post { Toast.makeText(this, "Fotoğraf okunamadı", Toast.LENGTH_LONG).show() } } }.start() }
    }

    // ---------- Hava durumu ----------
    // Kaynaklar: 0 = MET Norway (yr.no, Norveç Meteoroloji Enstitüsü), 1 = Open-Meteo. İkisi de aynı biçime çevrilir.
    private val wxSources = listOf("MET Norway (yr.no)", "Open-Meteo")
    private val UA = "PiLauncher/$VERSION (github.com/arslanburak/tvlauncher)"
    private fun saveCity(name: String, lat: String, lon: String) { prefs.edit().putString("city", name).putString("lat", lat).putString("lon", lon).remove("wx").remove("wxfull").apply(); updateWeatherText(); lastWeather = System.currentTimeMillis(); fetchWeather() }
    private fun showCityPanel(parent: (() -> Unit)?) { val items = listOf(PItem("Mahalle, sokak ya da şehir ara…", GlyphView.ZOOM, "#3A9DB8", sub = "Örn: Caferağa Kadıköy, Bağdat Caddesi", arrow = true)) + cities.map { PItem(it.name) }
        val ci = cities.indexOfFirst { it.name == prefs.getString("city", "") }; val cur = if (ci >= 0) ci + 1 else -1
        showPanel("Hava durumu konumu", items, cur, parent, false, 0) { i -> if (i == 0) showCitySearch(parent) else { val c = cities[i - 1]; saveCity(c.name, c.lat, c.lon); parent?.invoke() } } }
    private fun showCitySearch(parent: (() -> Unit)?) { showInput("Konum ara", "Mahalle, sokak, ilçe ya da şehir", "", parent) { q -> if (q.isNotEmpty()) searchCity(q, parent) else showCitySearch(parent) } }
    private fun httpGet(url: String): String { val conn = URL(url).openConnection() as HttpURLConnection; conn.connectTimeout = 9000; conn.readTimeout = 9000
        conn.setRequestProperty("User-Agent", UA); conn.setRequestProperty("Accept-Language", "tr"); return conn.inputStream.bufferedReader().use { it.readText() } }
    // OpenStreetMap (Nominatim) ile mahalle/sokak düzeyinde arama
    private fun searchCity(q: String, parent: (() -> Unit)?) {
        Toast.makeText(this, "Aranıyor…", Toast.LENGTH_SHORT).show()
        Thread { val found = mutableListOf<City>(); val titles = mutableListOf<String>(); val subs = mutableListOf<String>()
            try { val arr = org.json.JSONArray(httpGet("https://nominatim.openstreetmap.org/search?q=" + URLEncoder.encode(q, "UTF-8") + "&format=jsonv2&addressdetails=1&limit=8&accept-language=tr"))
                for (k in 0 until arr.length()) { val o = arr.getJSONObject(k); val a = o.optJSONObject("address") ?: JSONObject()
                    fun ad(vararg keys: String): String { for (key in keys) { val v = a.optString(key, ""); if (v.isNotEmpty()) return v }; return "" }
                    val local = ad("neighbourhood", "suburb", "quarter", "village", "hamlet", "town", "city_district", "district", "county", "city", "province", "state")
                    val type = o.optString("addresstype", ""); val nm = o.optString("name", "")
                    val short = if (nm.isNotEmpty() && type !in listOf("road", "house", "building", "amenity", "shop", "tourism", "leisure", "office", "highway")) nm else local.ifEmpty { nm }
                    val parts = o.optString("display_name", "").split(",").map { it.trim() }.filter { it.isNotEmpty() && !it.all { ch -> ch.isDigit() } && !it.endsWith("Bölgesi") && it != "Türkiye" }
                    if (parts.isEmpty()) continue
                    found.add(City(short.ifEmpty { parts[0] }, o.optString("lat"), o.optString("lon"))); titles.add(parts[0]); subs.add(parts.drop(1).take(3).joinToString(", "))
                }
            } catch (_: Exception) {}
            handler.post { if (found.isEmpty()) { Toast.makeText(this, "Konum bulunamadı ya da internet yok", Toast.LENGTH_LONG).show(); showCitySearch(parent) }
                else showPanel("Sonuçlar", titles.indices.map { PItem(titles[it], sub = subs[it].ifEmpty { null }) }, -1, { showCitySearch(parent) }, false) { i -> saveCity(found[i].name, found[i].lat, found[i].lon); parent?.invoke() } }
        }.start()
    }
    private fun wxText(code: Int): String = when (code) { 0 -> "Açık"; 1 -> "Az bulutlu"; 2 -> "Parçalı bulutlu"; 3 -> "Kapalı"; 45, 48 -> "Sisli"; 51, 53, 55, 56, 57 -> "Çiseleme"
        61 -> "Hafif yağmur"; 63 -> "Yağmurlu"; 65 -> "Şiddetli yağmur"; 66, 67 -> "Karla karışık"; 71 -> "Hafif kar"; 73, 77 -> "Karlı"; 75 -> "Yoğun kar"
        80 -> "Hafif sağanak"; 81 -> "Sağanak"; 82 -> "Kuvvetli sağanak"; 85, 86 -> "Kar sağanağı"; 95, 96, 99 -> "Gök gürültülü"; else -> "" }
    private fun wxKind(code: Int): Int { val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY); val night = h < 6 || h >= 19
        return when (code) { 0, 1 -> if (night) WxIconView.MOON else WxIconView.SUN; 2 -> if (night) WxIconView.CLOUD else WxIconView.PARTLY; 3 -> WxIconView.CLOUD; 45, 48 -> WxIconView.FOG; 51, 53, 55, 56, 57, 61, 63, 65, 66, 67, 80, 81, 82 -> WxIconView.RAIN; 71, 73, 75, 77, 85, 86 -> WxIconView.SNOW; 95, 96, 99 -> WxIconView.STORM; else -> WxIconView.CLOUD } }
    private fun wxKindDay(code: Int): Int = when (code) { 0, 1 -> WxIconView.SUN; 2 -> WxIconView.PARTLY; else -> wxKind(code) }
    // MET Norway sembol kodu -> WMO kodu
    private fun metCode(sym: String): Int { val s = sym.substringBefore("_")
        return when { s.contains("thunder") -> 95; s.contains("sleet") -> if (s.startsWith("heavy")) 67 else 66
            s.contains("snow") -> if (s.startsWith("light")) 71 else if (s.startsWith("heavy")) 75 else 73
            s.contains("rainshowers") -> if (s.startsWith("light")) 80 else if (s.startsWith("heavy")) 82 else 81
            s.contains("rain") -> if (s.startsWith("light")) 61 else if (s.startsWith("heavy")) 65 else 63
            s == "fog" -> 45; s == "cloudy" -> 3; s == "partlycloudy" -> 2; s == "fair" -> 1; s == "clearsky" -> 0; else -> 3 } }
    // Hissedilen sıcaklık (Steadman / Avustralya BoM formülü)
    private fun feels(t: Double, windKmh: Double, rh: Double): Double { val e = rh / 100.0 * 6.105 * Math.exp(17.27 * t / (237.7 + t)); return t + 0.33 * e - 0.70 * (windKmh / 3.6) - 4.0 }
    private fun fetchMet(lat: String, lon: String): JSONObject {
        val ts = JSONObject(httpGet("https://api.met.no/weatherapi/locationforecast/2.0/compact?lat=" + "%.4f".format(Locale.US, lat.toDouble()) + "&lon=" + "%.4f".format(Locale.US, lon.toDouble()))).getJSONObject("properties").getJSONArray("timeseries")
        val iso = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).apply { timeZone = java.util.TimeZone.getTimeZone("UTC") }
        val dayF = SimpleDateFormat("yyyy-MM-dd", Locale.US); val now = System.currentTimeMillis()
        var curIdx = 0; for (i in 0 until ts.length()) { val t = iso.parse(ts.getJSONObject(i).getString("time"))!!.time; if (t <= now + 30 * 60_000L) curIdx = i else break }
        fun sym(d: JSONObject): String? = (d.optJSONObject("next_1_hours") ?: d.optJSONObject("next_6_hours"))?.optJSONObject("summary")?.optString("symbol_code")
        val cd = ts.getJSONObject(curIdx).getJSONObject("data"); val inst = cd.getJSONObject("instant").getJSONObject("details")
        val t = inst.getDouble("air_temperature"); val rh = inst.optDouble("relative_humidity", 50.0); val wind = inst.optDouble("wind_speed", 0.0) * 3.6
        val out = JSONObject().put("src", 0).put("t", t).put("f", feels(t, wind, rh)).put("h", rh).put("w", wind).put("c", metCode(sym(cd) ?: "cloudy"))
        val order = mutableListOf<String>(); val mx = HashMap<String, Double>(); val mn = HashMap<String, Double>(); val pr = HashMap<String, Double>(); val noon = HashMap<String, Pair<Int, Int>>()
        for (i in curIdx until ts.length()) { val e = ts.getJSONObject(i); val tm = iso.parse(e.getString("time"))!!; val day = dayF.format(tm); val d = e.getJSONObject("data")
            if (day !in order) { if (order.size >= 5) break; order.add(day) }
            val tt = d.getJSONObject("instant").getJSONObject("details").getDouble("air_temperature"); mx[day] = maxOf(mx[day] ?: tt, tt); mn[day] = minOf(mn[day] ?: tt, tt)
            val n1 = d.optJSONObject("next_1_hours"); val n6 = d.optJSONObject("next_6_hours")
            val amt = if (n1 != null) n1.optJSONObject("details")?.optDouble("precipitation_amount", 0.0) ?: 0.0 else n6?.optJSONObject("details")?.optDouble("precipitation_amount", 0.0) ?: 0.0
            pr[day] = (pr[day] ?: 0.0) + amt
            val s = sym(d); val hr = Calendar.getInstance().apply { time = tm }.get(Calendar.HOUR_OF_DAY)
            if (s != null) { val dist = Math.abs(hr - 13); val prev = noon[day]; if (prev == null || dist < prev.first) noon[day] = Pair(dist, metCode(s)) }
        }
        val days = org.json.JSONArray(); for (day in order) days.put(JSONObject().put("d", day).put("c", noon[day]?.second ?: 3).put("mx", mx[day]).put("mn", mn[day]).put("p", pr[day] ?: 0.0).put("pp", -1))
        return out.put("days", days)
    }
    private fun fetchOpenMeteo(lat: String, lon: String): JSONObject {
        val o = JSONObject(httpGet("https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current=temperature_2m,apparent_temperature,relative_humidity_2m,weather_code,wind_speed_10m&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_sum,precipitation_probability_max&timezone=auto&forecast_days=5"))
        val c = o.getJSONObject("current"); val d = o.getJSONObject("daily")
        val out = JSONObject().put("src", 1).put("t", c.getDouble("temperature_2m")).put("f", c.getDouble("apparent_temperature")).put("h", c.optDouble("relative_humidity_2m", 0.0)).put("w", c.optDouble("wind_speed_10m", 0.0)).put("c", c.getInt("weather_code"))
        val days = org.json.JSONArray(); val tm = d.getJSONArray("time")
        for (i in 0 until tm.length()) days.put(JSONObject().put("d", tm.getString(i)).put("c", d.getJSONArray("weather_code").optInt(i, 3)).put("mx", d.getJSONArray("temperature_2m_max").optDouble(i, 0.0)).put("mn", d.getJSONArray("temperature_2m_min").optDouble(i, 0.0))
            .put("p", d.getJSONArray("precipitation_sum").optDouble(i, 0.0)).put("pp", d.getJSONArray("precipitation_probability_max").optInt(i, -1)))
        return out.put("days", days)
    }
    private fun fetchWeather() { val lat = prefs.getString("lat", null) ?: return; val lon = prefs.getString("lon", null) ?: return; val src = prefs.getInt("wxSrc", 0)
        Thread { try { val o = try { if (src == 0) fetchMet(lat, lon) else fetchOpenMeteo(lat, lon) } catch (e: Exception) { if (src == 0) fetchOpenMeteo(lat, lon) else fetchMet(lat, lon) }
            val temp = Math.round(o.getDouble("t")).toInt(); val code = o.getInt("c")
            prefs.edit().putString("wx", "$temp°|" + wxText(code) + "|" + code).putString("wxfull", o.toString()).apply(); handler.post { updateWeatherText() } } catch (_: Exception) {} }.start() }
    private fun fitText(tv: TextView) { tv.minWidth = Math.ceil(tv.paint.measureText(tv.text.toString()).toDouble()).toInt() + tv.paddingLeft + tv.paddingRight + 2; tv.requestLayout() }
    private fun updateWeatherText() { updateWeatherText0(); fitText(weatherText) }
    private fun updateWeatherText0() { val city = prefs.getString("city", null)
        if (city == null) { wxIcon.visibility = View.GONE; weatherText.text = "Konum seç"; return }
        val wx = prefs.getString("wx", null); if (wx == null) { wxIcon.visibility = View.GONE; weatherText.text = city }
        else { val p = wx.split("|"); val code = if (p.size > 2) (p[2].toIntOrNull() ?: 3) else 3; wxIcon.setKind(wxKind(code)); wxIcon.visibility = View.VISIBLE; weatherText.text = city + " · " + p[0] + " " + (if (p.size > 1) p[1] else "") } }
    private fun showWeatherDetail() {
        val full = prefs.getString("wxfull", null); val city = prefs.getString("city", null) ?: return
        if (full == null || !full.contains("\"days\"")) { lastWeather = System.currentTimeMillis(); fetchWeather(); Toast.makeText(this, "Hava durumu yükleniyor…", Toast.LENGTH_SHORT).show(); return }
        val dlg = Dialog(this); dlg.requestWindowFeature(Window.FEATURE_NO_TITLE); val box = panelBox(); var srcName = ""
        try { val o = JSONObject(full); srcName = wxSources.getOrElse(o.optInt("src", 0)) { "" }
            val temp = Math.round(o.getDouble("t")).toInt(); val fl = Math.round(o.getDouble("f")).toInt(); val hum = Math.round(o.optDouble("h", 0.0)).toInt(); val wind = Math.round(o.optDouble("w", 0.0)).toInt(); val code = o.getInt("c")
            val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            head.addView(WxIconView(this, wxKind(code)), LinearLayout.LayoutParams(dp(46), dp(46)).apply { setMargins(0, 0, dp(14), 0) })
            val hc = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            hc.addView(TextView(this).apply { text = city; textSize = 15f; setTextColor(Color.parseColor("#C9C9D3")); maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END })
            hc.addView(TextView(this).apply { text = "$temp°  ·  " + wxText(code); textSize = 26f; typeface = Typeface.create("sans-serif-light", Typeface.NORMAL); setTextColor(Color.WHITE) })
            head.addView(hc, LinearLayout.LayoutParams(0, wrap, 1f)); box.addView(head, LinearLayout.LayoutParams(matchP, wrap).apply { setMargins(dp(8), dp(2), dp(8), dp(10)) })
            val stats = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            fun stat(t: String, v: String): View { val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
                col.addView(TextView(this).apply { text = v; textSize = 16f; setTextColor(Color.WHITE); gravity = Gravity.CENTER }); col.addView(TextView(this).apply { text = t; textSize = 11f; setTextColor(Color.parseColor("#9A9AA6")); gravity = Gravity.CENTER }); return col }
            stats.addView(stat("Hissedilen", "$fl°"), LinearLayout.LayoutParams(0, wrap, 1f)); stats.addView(stat("Nem", "%$hum"), LinearLayout.LayoutParams(0, wrap, 1f)); stats.addView(stat("Rüzgar", "$wind km/s"), LinearLayout.LayoutParams(0, wrap, 1f))
            box.addView(stats, LinearLayout.LayoutParams(matchP, wrap).apply { setMargins(0, dp(4), 0, dp(12)) })
            box.addView(View(this).apply { setBackgroundColor(Color.argb(35, 255, 255, 255)) }, LinearLayout.LayoutParams(matchP, dp(1)).apply { setMargins(0, 0, 0, dp(8)) })
            val days = o.getJSONArray("days"); val dayFmt = SimpleDateFormat("EEEE", Locale("tr", "TR")); val parse = SimpleDateFormat("yyyy-MM-dd", Locale.US)
            for (i in 0 until days.length()) { val dd = days.getJSONObject(i); val rr = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(8), dp(7), dp(8), dp(7)) }
                val dayName = if (i == 0) "Bugün" else try { dayFmt.format(parse.parse(dd.getString("d"))!!) } catch (_: Exception) { dd.getString("d") }
                rr.addView(TextView(this).apply { text = dayName; textSize = 14f; setTextColor(Color.WHITE) }, LinearLayout.LayoutParams(0, wrap, 1.2f)); rr.addView(WxIconView(this, wxKindDay(dd.optInt("c", 3))), LinearLayout.LayoutParams(dp(22), dp(22)))
                val pp = dd.optInt("pp", -1); val mm = dd.optDouble("p", 0.0)
                val rain = if (pp > 0) "  %$pp" else if (mm >= 0.5) "  " + Math.round(mm) + " mm" else "   "
                rr.addView(TextView(this).apply { text = rain; textSize = 12.5f; setTextColor(Color.parseColor("#8FC1FF")) }, LinearLayout.LayoutParams(0, wrap, 0.8f))
                rr.addView(TextView(this).apply { text = Math.round(dd.getDouble("mx")).toString() + "°  " + Math.round(dd.getDouble("mn")) + "°"; textSize = 14f; setTextColor(Color.parseColor("#D0D0DA")); gravity = Gravity.END }, LinearLayout.LayoutParams(0, wrap, 1f)); box.addView(rr) }
        } catch (_: Exception) { box.addView(TextView(this).apply { text = "Hava durumu okunamadı"; setTextColor(Color.WHITE); textSize = 15f }) }
        box.addView(footView("‹  Geri: kapat" + (if (srcName.isNotEmpty()) "   ·   Kaynak: $srcName" else ""))); dlg.setContentView(box); styleWindow(dlg, 340); registerDialog(dlg); dlg.show()
    }

    private fun openSystem(action: String) { try { startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { try { startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {} } }
    @Suppress("DEPRECATION")
    private fun updateWifi() { val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager; wifiIcon.setColorFilter(if (cm.activeNetworkInfo?.isConnected == true) Color.WHITE else Color.parseColor("#7A8594"), PorterDuff.Mode.SRC_IN) }

    // Şeffaf zeminli, koyu logolu afişler (ör. HBO Max) koyu kutuda görünmüyor -> açık zemin ver
    private val lightBgCache = HashMap<String, Boolean>()
    private fun needsLightBg(app: AppItem): Boolean = lightBgCache.getOrPut(app.pkg) {
        try {
            val w = 48; val h = 27; val bmp = android.graphics.Bitmap.createBitmap(w, h, android.graphics.Bitmap.Config.ARGB_8888)
            val d = app.image; val old = android.graphics.Rect(d.bounds); d.setBounds(0, 0, w, h); d.draw(Canvas(bmp)); d.bounds = old
            var clear = 0; var opaque = 0; var lum = 0.0
            for (y in 0 until h) for (x in 0 until w) { val c = bmp.getPixel(x, y); val a = Color.alpha(c)
                if (a < 40) clear++ else { opaque++; lum += (0.299 * Color.red(c) + 0.587 * Color.green(c) + 0.114 * Color.blue(c)) / 255.0 } }
            bmp.recycle()
            val total = w * h; opaque > 0 && clear > total * 0.25 && lum / opaque < 0.42
        } catch (_: Exception) { false }
    }

    // ---------- Dinamik arka plan ----------
    // Sistem animasyonları kapalı olsa da çalışsın diye kare kare kendi zamanlayıcımız
    private fun animateFrames(durMs: Long, onFrame: (Float) -> Unit, onEnd: () -> Unit = {}) {
        val start = android.os.SystemClock.uptimeMillis()
        val cb = object : android.view.Choreographer.FrameCallback { override fun doFrame(t: Long) {
            val p = ((android.os.SystemClock.uptimeMillis() - start).toFloat() / durMs).coerceIn(0f, 1f); onFrame(p)
            if (p < 1f) android.view.Choreographer.getInstance().postFrameCallback(this) else onEnd() } }
        android.view.Choreographer.getInstance().postFrameCallback(cb)
    }
    private fun ease(p: Float): Float = 1f - (1f - p) * (1f - p) * (1f - p)
    private val colorCache = HashMap<String, Int>()
    // Afişin baskın canlı rengi (gri/beyaz/siyah afişlerde renk yok -> 0)
    private fun appColor(app: AppItem): Int = colorCache.getOrPut(app.pkg) {
        try { val w = 40; val h = 22; val bmp = android.graphics.Bitmap.createBitmap(w, h, android.graphics.Bitmap.Config.ARGB_8888)
            val d = app.image; val old = android.graphics.Rect(d.bounds); d.setBounds(0, 0, w, h); d.draw(Canvas(bmp)); d.bounds = old
            var sx = 0.0; var sy = 0.0; var wsum = 0.0; val hsv = FloatArray(3)
            for (y in 0 until h) for (x in 0 until w) { val c = bmp.getPixel(x, y); if (Color.alpha(c) < 120) continue
                Color.colorToHSV(c, hsv); if (hsv[1] < 0.28f || hsv[2] < 0.18f) continue
                val wt = (hsv[1] * hsv[2]).toDouble(); val rad = Math.toRadians(hsv[0].toDouble()); sx += Math.cos(rad) * wt; sy += Math.sin(rad) * wt; wsum += wt }
            bmp.recycle()
            if (wsum < w * h * 0.04) 0 else { var hue = Math.toDegrees(Math.atan2(sy, sx)).toFloat(); if (hue < 0) hue += 360f; Color.HSVToColor(floatArrayOf(hue, 0.7f, 0.62f)) }
        } catch (_: Exception) { 0 } }
    private fun setTintFor(app: AppItem?) {
        val c = if (app == null || !prefs.getBoolean("dynBg", true)) 0 else appColor(app)
        if (c == (tintColor ?: -1)) return; tintColor = c
        val incoming = if (tintFront) tintA else tintB; val outgoing = if (tintFront) tintB else tintA; tintFront = !tintFront
        incoming.background = if (c == 0) null else GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.argb(150, Color.red(c), Color.green(c), Color.blue(c)), Color.argb(70, Color.red(c), Color.green(c), Color.blue(c)), Color.argb(0, 0, 0, 0)))
        val a0 = incoming.alpha; val b0 = outgoing.alpha
        val gen = ++tintGen
        animateFrames(450, { p -> if (gen == tintGen) { val e = ease(p); incoming.alpha = a0 + (1f - a0) * e; outgoing.alpha = b0 * (1f - e) } })
    }
    private fun launchApp(app: AppItem) {
        try { startActivity(Intent(Intent.ACTION_MAIN).setClassName(app.pkg, app.cls).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
    }

    // ---------- Kutular ----------
    private fun tile(app: AppItem): View {
        val light = needsLightBg(app)
        val bg = GradientDrawable().apply { cornerRadius = tileRadiusPx(); setColor(if (light) Color.argb(tileBgAlpha(), 236, 236, 242) else Color.argb(tileBgAlpha(), 43, 43, 64)) }
        // Seçim çerçevesi ön planda çizilir (arka planda kalınca afiş üstünü örtüyor, sadece üst/alt kenarda ince şerit görünüyordu)
        val ring = GradientDrawable().apply { cornerRadius = tileRadiusPx(); setColor(Color.TRANSPARENT) }
        val frame = FrameLayout(this).apply { background = bg; foreground = ring; isFocusable = true; clipToOutline = true; elevation = dp(3).toFloat(); alpha = 0.9f; tag = app.pkg }
        val img = ImageView(this).apply { setImageDrawable(app.image); if (app.isBanner) scaleType = ImageView.ScaleType.CENTER_CROP else { scaleType = ImageView.ScaleType.FIT_CENTER; setPadding(dp(tileW / 7), dp(tileH / 6), dp(tileW / 7), dp(tileH / 6)) } }
        frame.addView(img, FrameLayout.LayoutParams(matchP, matchP))
        val shine = ShineView(this); frame.addView(shine, FrameLayout.LayoutParams(matchP, matchP))
        frame.setOnFocusChangeListener { v, hasFocus ->
            if (hasFocus) { lastPkg = app.pkg; ensureRowVisible(v); setTintFor(app); if (prefs.getBoolean("shine", true)) shine.play() else shine.stop(); val z = focusZoom(); v.animate().scaleX(z).scaleY(z).alpha(1f).translationZ(dp(18).toFloat()).setDuration(animDur()).start(); ring.setStroke(dp(frameWidth()), if (movingPkg == app.pkg) Color.parseColor("#FF9F0A") else frameColor()) }
            else { v.animate().scaleX(1f).scaleY(1f).alpha(0.9f).translationZ(0f).setDuration(animDur()).start(); ring.setStroke(0, Color.TRANSPARENT); shine.stop() }
        }
        frame.setOnClickListener { launchApp(app) }
        frame.setOnLongClickListener { showMenu(app); true }
        frame.setOnKeyListener { view, k, e -> edgeKeys(view, k, e) }
        frame.layoutParams = LinearLayout.LayoutParams(dp(tileW), dp(tileH)).apply { setMargins(dp(tileGap) / 2, 0, dp(tileGap) - dp(tileGap) / 2, 0) }
        return frame
    }
    private fun hiddenTile(): View {
        val bg = glass(16, 90); val frame = FrameLayout(this).apply { background = bg; isFocusable = true; tag = "__hidden__" }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        box.addView(GlyphView(this, GlyphView.EYE_OFF), LinearLayout.LayoutParams(dp(24), dp(24))); box.addView(TextView(this).apply { text = "Gizlenenler (" + hiddenApps.size + ")"; textSize = 12f; setTextColor(Color.WHITE); gravity = Gravity.CENTER })
        frame.addView(box, FrameLayout.LayoutParams(matchP, matchP))
        frame.setOnFocusChangeListener { v, hasFocus -> if (hasFocus) { ensureRowVisible(v); v.animate().scaleX(focusZoom()).scaleY(focusZoom()).setDuration(animDur()).start(); bg.setStroke(dp(3), Color.WHITE) } else { v.animate().scaleX(1f).scaleY(1f).setDuration(animDur()).start(); bg.setStroke(dp(1), Color.argb(55, 255, 255, 255)) } }
        frame.setOnClickListener { showHidden() }; frame.setOnKeyListener { view, k, e -> edgeKeys(view, k, e) }
        frame.layoutParams = LinearLayout.LayoutParams(dp(tileW), dp(tileH)).apply { setMargins(dp(tileGap) / 2, 0, dp(tileGap) - dp(tileGap) / 2, 0) }
        return frame
    }
    private fun edgeKeys(view: View, keyCode: Int, event: KeyEvent): Boolean {
        if (event.action != KeyEvent.ACTION_DOWN) return false
        val row = view.parent as? ViewGroup ?: return false; val idx = row.indexOfChild(view)
        if (keyCode == KeyEvent.KEYCODE_DPAD_RIGHT && idx == row.childCount - 1) return true
        if (keyCode == KeyEvent.KEYCODE_DPAD_LEFT && idx == 0) return true
        if (keyCode == KeyEvent.KEYCODE_DPAD_UP && grid.indexOfChild(row) == 0) { gearView?.requestFocus(); return true }
        return false
    }
}

// Küçük çizim simgeleri
class GlyphView(context: Context, private val kind: Int) : View(context) {
    companion object {
        const val GRID = 0; const val PALETTE = 1; const val CLOUD = 2; const val RESET = 3; const val MOVE = 4; const val EYE_OFF = 5; const val TRASH = 6; const val INFO = 7
        const val CHECK = 8; const val CHEVRON = 9; const val SLIDERS = 10; const val MONITOR = 13; const val GEAR = 15
        const val IMAGE = 16; const val CONTRAST = 17; const val BLUR = 18; const val CORNER = 19; const val OPACITY = 20; const val ZOOM = 21; const val SORT = 22; const val CLOCK = 23; const val APPS = 24
    }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }
    private val gearPath: Path by lazy { androidx.core.graphics.PathParser.createPathFromPathData("M19.14,12.94c0.04,-0.3 0.06,-0.61 0.06,-0.94c0,-0.32 -0.02,-0.64 -0.07,-0.94l2.03,-1.58c0.18,-0.14 0.23,-0.41 0.12,-0.61l-1.92,-3.32c-0.12,-0.22 -0.37,-0.29 -0.59,-0.22l-2.39,0.96c-0.5,-0.38 -1.03,-0.7 -1.62,-0.94L14.4,2.81c-0.04,-0.24 -0.24,-0.41 -0.48,-0.41h-3.84c-0.24,0 -0.43,0.17 -0.47,0.41L9.25,5.35C8.66,5.59 8.12,5.92 7.63,6.29L5.24,5.33c-0.22,-0.08 -0.47,0 -0.59,0.22L2.74,8.87C2.62,9.08 2.66,9.34 2.86,9.48l2.03,1.58C4.84,11.36 4.8,11.69 4.8,12s0.02,0.64 0.07,0.94l-2.03,1.58c-0.18,0.14 -0.23,0.41 -0.12,0.61l1.92,3.32c0.12,0.22 0.37,0.29 0.59,0.22l2.39,-0.96c0.5,0.38 1.03,0.7 1.62,0.94l0.36,2.54c0.05,0.24 0.24,0.41 0.48,0.41h3.84c0.24,0 0.44,-0.17 0.47,-0.41l0.36,-2.54c0.59,-0.24 1.13,-0.56 1.62,-0.94l2.39,0.96c0.22,0.08 0.47,0 0.59,-0.22l1.92,-3.32c0.12,-0.22 0.07,-0.47 -0.12,-0.61L19.14,12.94zM12,15.6c-1.98,0 -3.6,-1.62 -3.6,-3.6s1.62,-3.6 3.6,-3.6s3.6,1.62 3.6,3.6S13.98,15.6 12,15.6z") }
    fun setTint(c: Int) { p.color = c; invalidate() }
    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat(); val cx = w / 2f; val cy = height / 2f; p.strokeWidth = w * 0.085f; p.style = Paint.Style.STROKE
        when (kind) {
            GRID -> { p.style = Paint.Style.FILL; val s = w * 0.2f; val g = w * 0.07f; for (i in 0..1) for (j in 0..1) { val l = cx - g / 2 - s + i * (s + g); val t = cy - g / 2 - s + j * (s + g); canvas.drawRoundRect(RectF(l, t, l + s, t + s), w * 0.04f, w * 0.04f, p) } }
            PALETTE -> { canvas.drawCircle(cx, cy, w * 0.29f, p); p.style = Paint.Style.FILL; canvas.drawCircle(cx - w * 0.10f, cy - w * 0.07f, w * 0.045f, p); canvas.drawCircle(cx + w * 0.07f, cy - w * 0.12f, w * 0.045f, p); canvas.drawCircle(cx + w * 0.14f, cy + w * 0.05f, w * 0.045f, p); canvas.drawCircle(cx - w * 0.04f, cy + w * 0.10f, w * 0.045f, p) }
            CLOUD -> { p.style = Paint.Style.FILL; canvas.drawCircle(cx - w * 0.13f, cy + w * 0.04f, w * 0.13f, p); canvas.drawCircle(cx + w * 0.02f, cy - w * 0.05f, w * 0.17f, p); canvas.drawCircle(cx + w * 0.16f, cy + w * 0.05f, w * 0.12f, p); canvas.drawRoundRect(RectF(cx - w * 0.24f, cy + w * 0.04f, cx + w * 0.27f, cy + w * 0.17f), w * 0.06f, w * 0.06f, p) }
            RESET -> { val r = w * 0.26f; canvas.drawArc(RectF(cx - r, cy - r, cx + r, cy + r), -40f, 270f, false, p); val ang = Math.toRadians(230.0); val px = cx + (r * Math.cos(ang)).toFloat(); val py = cy + (r * Math.sin(ang)).toFloat(); val nx = Math.cos(ang).toFloat(); val ny = Math.sin(ang).toFloat(); val path = Path(); path.moveTo(px - ny * w * 0.13f, py + nx * w * 0.13f); path.lineTo(px + nx * w * 0.10f, py + ny * w * 0.10f); path.lineTo(px - nx * w * 0.10f, py - ny * w * 0.10f); path.close(); p.style = Paint.Style.FILL; canvas.drawPath(path, p) }
            MOVE -> { val a = w * 0.28f; val h = w * 0.12f; canvas.drawLine(cx - a, cy, cx + a, cy, p); canvas.drawLine(cx, cy - a, cx, cy + a, p); canvas.drawLine(cx - a, cy, cx - a + h, cy - h, p); canvas.drawLine(cx - a, cy, cx - a + h, cy + h, p); canvas.drawLine(cx + a, cy, cx + a - h, cy - h, p); canvas.drawLine(cx + a, cy, cx + a - h, cy + h, p); canvas.drawLine(cx, cy - a, cx - h, cy - a + h, p); canvas.drawLine(cx, cy - a, cx + h, cy - a + h, p); canvas.drawLine(cx, cy + a, cx - h, cy + a - h, p); canvas.drawLine(cx, cy + a, cx + h, cy + a - h, p) }
            EYE_OFF -> { canvas.drawOval(RectF(cx - w * 0.3f, cy - w * 0.17f, cx + w * 0.3f, cy + w * 0.17f), p); p.style = Paint.Style.FILL; canvas.drawCircle(cx, cy, w * 0.07f, p); p.style = Paint.Style.STROKE; canvas.drawLine(cx - w * 0.27f, cy + w * 0.27f, cx + w * 0.27f, cy - w * 0.27f, p) }
            TRASH -> { canvas.drawLine(cx - w * 0.25f, cy - w * 0.16f, cx + w * 0.25f, cy - w * 0.16f, p); canvas.drawLine(cx - w * 0.08f, cy - w * 0.25f, cx + w * 0.08f, cy - w * 0.25f, p); canvas.drawRoundRect(RectF(cx - w * 0.18f, cy - w * 0.16f, cx + w * 0.18f, cy + w * 0.28f), w * 0.05f, w * 0.05f, p); canvas.drawLine(cx - w * 0.05f, cy - w * 0.06f, cx - w * 0.05f, cy + w * 0.18f, p); canvas.drawLine(cx + w * 0.05f, cy - w * 0.06f, cx + w * 0.05f, cy + w * 0.18f, p) }
            INFO -> { canvas.drawCircle(cx, cy, w * 0.3f, p); p.style = Paint.Style.FILL; canvas.drawCircle(cx, cy - w * 0.11f, w * 0.04f, p); p.style = Paint.Style.STROKE; canvas.drawLine(cx, cy - w * 0.03f, cx, cy + w * 0.15f, p) }
            CHECK -> { val path = Path(); path.moveTo(cx - w * 0.2f, cy); path.lineTo(cx - w * 0.05f, cy + w * 0.15f); path.lineTo(cx + w * 0.22f, cy - w * 0.14f); canvas.drawPath(path, p) }
            CHEVRON -> { val path = Path(); path.moveTo(cx - w * 0.08f, cy - w * 0.2f); path.lineTo(cx + w * 0.1f, cy); path.lineTo(cx - w * 0.08f, cy + w * 0.2f); canvas.drawPath(path, p) }
            SLIDERS -> { canvas.drawLine(cx - w * 0.3f, cy - w * 0.14f, cx + w * 0.3f, cy - w * 0.14f, p); canvas.drawLine(cx - w * 0.3f, cy + w * 0.14f, cx + w * 0.3f, cy + w * 0.14f, p); p.style = Paint.Style.FILL; canvas.drawCircle(cx - w * 0.1f, cy - w * 0.14f, w * 0.085f, p); canvas.drawCircle(cx + w * 0.12f, cy + w * 0.14f, w * 0.085f, p) }
            MONITOR -> { canvas.drawRoundRect(RectF(cx - w * 0.3f, cy - w * 0.24f, cx + w * 0.3f, cy + w * 0.12f), w * 0.04f, w * 0.04f, p); canvas.drawLine(cx - w * 0.12f, cy + w * 0.26f, cx + w * 0.12f, cy + w * 0.26f, p); canvas.drawLine(cx, cy + w * 0.12f, cx, cy + w * 0.26f, p) }
            GEAR -> { // Android'in standart ayarlar (dişli) simgesi
                val path = Path(gearPath); val m = android.graphics.Matrix(); val sc = w * (if (w > 26 * resources.displayMetrics.density) 0.62f else 0.92f) / 24f; m.setScale(sc, sc); m.postTranslate(cx - 12f * sc, cy - 12f * sc); path.transform(m)
                p.style = Paint.Style.FILL; canvas.drawPath(path, p) }
            IMAGE -> { canvas.drawRoundRect(RectF(cx - w * 0.3f, cy - w * 0.24f, cx + w * 0.3f, cy + w * 0.24f), w * 0.05f, w * 0.05f, p); p.style = Paint.Style.FILL; canvas.drawCircle(cx - w * 0.12f, cy - w * 0.08f, w * 0.05f, p); p.style = Paint.Style.STROKE; val path = Path(); path.moveTo(cx - w * 0.26f, cy + w * 0.16f); path.lineTo(cx - w * 0.06f, cy - w * 0.04f); path.lineTo(cx + w * 0.1f, cy + w * 0.12f); path.lineTo(cx + w * 0.18f, cy + w * 0.04f); path.lineTo(cx + w * 0.28f, cy + w * 0.16f); canvas.drawPath(path, p) }
            CONTRAST -> { canvas.drawCircle(cx, cy, w * 0.28f, p); val path = Path(); path.addArc(RectF(cx - w * 0.28f, cy - w * 0.28f, cx + w * 0.28f, cy + w * 0.28f), 90f, 180f); p.style = Paint.Style.FILL; canvas.drawPath(path, p) }
            BLUR -> { p.style = Paint.Style.FILL; canvas.drawCircle(cx, cy, w * 0.26f, p); p.color = Color.argb(120, 255, 255, 255); canvas.drawCircle(cx + w * 0.12f, cy - w * 0.1f, w * 0.14f, p) }
            CORNER -> { val path = Path(); path.moveTo(cx - w * 0.26f, cy + w * 0.26f); path.lineTo(cx - w * 0.26f, cy - w * 0.08f); path.cubicTo(cx - w * 0.26f, cy - w * 0.26f, cx - w * 0.26f, cy - w * 0.26f, cx - w * 0.08f, cy - w * 0.26f); path.lineTo(cx + w * 0.26f, cy - w * 0.26f); canvas.drawPath(path, p) }
            OPACITY -> { for (i in 0..2) for (j in 0..2) { if ((i + j) % 2 == 0) { p.style = Paint.Style.FILL; val s = w * 0.17f; val l = cx - w * 0.26f + i * s; val t = cy - w * 0.26f + j * s; canvas.drawRect(l, t, l + s, t + s, p) } }; p.style = Paint.Style.STROKE; canvas.drawCircle(cx, cy, w * 0.26f, p) }
            ZOOM -> { canvas.drawCircle(cx - w * 0.06f, cy - w * 0.06f, w * 0.2f, p); canvas.drawLine(cx + w * 0.09f, cy + w * 0.09f, cx + w * 0.26f, cy + w * 0.26f, p); canvas.drawLine(cx - w * 0.14f, cy - w * 0.06f, cx + w * 0.02f, cy - w * 0.06f, p); canvas.drawLine(cx - w * 0.06f, cy - w * 0.14f, cx - w * 0.06f, cy + w * 0.02f, p) }
            SORT -> { canvas.drawLine(cx - w * 0.22f, cy - w * 0.2f, cx + w * 0.05f, cy - w * 0.2f, p); canvas.drawLine(cx - w * 0.22f, cy, cx + w * 0.18f, cy, p); canvas.drawLine(cx - w * 0.22f, cy + w * 0.2f, cx + w * 0.28f, cy + w * 0.2f, p) }
            CLOCK -> { canvas.drawCircle(cx, cy, w * 0.28f, p); canvas.drawLine(cx, cy, cx, cy - w * 0.16f, p); canvas.drawLine(cx, cy, cx + w * 0.12f, cy + w * 0.06f, p) }
            APPS -> { p.style = Paint.Style.FILL; val s = w * 0.14f; val g = w * 0.1f; for (i in 0..2) for (j in 0..2) { val l = cx - g - s * 1.5f + i * (s + g * 0.6f); val t = cy - g - s * 1.5f + j * (s + g * 0.6f); canvas.drawCircle(l + s / 2, t + s / 2, s * 0.5f, p) } }
            else -> {}
        }
    }
}

// Hava durumu simgeleri
class WxIconView(context: Context, private var kind: Int) : View(context) {
    companion object { const val SUN = 0; const val MOON = 1; const val PARTLY = 2; const val CLOUD = 3; const val RAIN = 4; const val SNOW = 5; const val STORM = 6; const val FOG = 7 }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }
    fun setKind(k: Int) { kind = k; invalidate() }
    private fun cloud(c: Canvas, cx: Float, cy: Float, s: Float, color: Int) { p.style = Paint.Style.FILL; p.color = color; c.drawCircle(cx - 0.22f * s, cy + 0.06f * s, 0.2f * s, p); c.drawCircle(cx + 0.02f * s, cy - 0.06f * s, 0.26f * s, p); c.drawCircle(cx + 0.26f * s, cy + 0.07f * s, 0.18f * s, p); c.drawRoundRect(RectF(cx - 0.42f * s, cy + 0.06f * s, cx + 0.44f * s, cy + 0.26f * s), 0.1f * s, 0.1f * s, p) }
    private fun sun(c: Canvas, cx: Float, cy: Float, r: Float) { p.color = Color.parseColor("#FFD27A"); p.style = Paint.Style.FILL; c.drawCircle(cx, cy, r, p); p.style = Paint.Style.STROKE; p.strokeWidth = r * 0.35f; for (i in 0 until 8) { val a = Math.toRadians(i * 45.0); val cs = Math.cos(a).toFloat(); val sn = Math.sin(a).toFloat(); c.drawLine(cx + cs * r * 1.5f, cy + sn * r * 1.5f, cx + cs * r * 1.95f, cy + sn * r * 1.95f, p) } }
    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat(); val cx = w / 2f; val cy = height / 2f; val white = Color.parseColor("#E8EBF2")
        when (kind) {
            SUN -> sun(canvas, cx, cy, w * 0.2f)
            MOON -> { val a = Path(); a.addCircle(cx, cy, w * 0.3f, Path.Direction.CW); val b = Path(); b.addCircle(cx + w * 0.15f, cy - w * 0.1f, w * 0.26f, Path.Direction.CW); a.op(b, Path.Op.DIFFERENCE); p.style = Paint.Style.FILL; p.color = white; canvas.drawPath(a, p) }
            PARTLY -> { sun(canvas, cx + w * 0.16f, cy - w * 0.16f, w * 0.12f); cloud(canvas, cx - w * 0.04f, cy + w * 0.08f, w * 0.85f, white) }
            CLOUD -> cloud(canvas, cx, cy, w * 0.95f, white)
            RAIN -> { cloud(canvas, cx, cy - w * 0.12f, w * 0.9f, white); p.style = Paint.Style.STROKE; p.color = Color.parseColor("#8FC1FF"); p.strokeWidth = w * 0.07f; for (i in 0..2) { val x = cx - w * 0.2f + i * w * 0.2f; canvas.drawLine(x, cy + w * 0.22f, x - w * 0.05f, cy + w * 0.36f, p) } }
            SNOW -> { cloud(canvas, cx, cy - w * 0.12f, w * 0.9f, white); p.style = Paint.Style.FILL; p.color = Color.WHITE; for (i in 0..2) canvas.drawCircle(cx - w * 0.2f + i * w * 0.2f, cy + w * 0.3f, w * 0.045f, p) }
            STORM -> { cloud(canvas, cx, cy - w * 0.14f, w * 0.9f, Color.parseColor("#B4BCC9")); val b = Path(); b.moveTo(cx + w * 0.06f, cy + w * 0.1f); b.lineTo(cx - w * 0.08f, cy + w * 0.3f); b.lineTo(cx, cy + w * 0.3f); b.lineTo(cx - w * 0.06f, cy + w * 0.46f); b.lineTo(cx + w * 0.14f, cy + w * 0.2f); b.lineTo(cx + w * 0.05f, cy + w * 0.2f); b.close(); p.style = Paint.Style.FILL; p.color = Color.parseColor("#FFD27A"); canvas.drawPath(b, p) }
            FOG -> { p.style = Paint.Style.STROKE; p.color = Color.parseColor("#C5CAD6"); p.strokeWidth = w * 0.08f; canvas.drawLine(cx - w * 0.3f, cy - w * 0.16f, cx + w * 0.3f, cy - w * 0.16f, p); canvas.drawLine(cx - w * 0.22f, cy, cx + w * 0.34f, cy, p); canvas.drawLine(cx - w * 0.3f, cy + w * 0.16f, cx + w * 0.22f, cy + w * 0.16f, p) }
            else -> {}
        }
    }
}

// Apple tarzı aç/kapa anahtarı (sistem animasyonları kapalı olsa da kayarak geçer)
class SwitchView(context: Context, initial: Boolean) : View(context) {
    var on = initial; private set
    private var pos = if (initial) 1f else 0f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    fun flip() { on = !on; val from = pos; val to = if (on) 1f else 0f; val start = android.os.SystemClock.uptimeMillis()
        val cb = object : android.view.Choreographer.FrameCallback { override fun doFrame(t: Long) {
            val k = ((android.os.SystemClock.uptimeMillis() - start) / 180f).coerceIn(0f, 1f); val e = 1f - (1f - k) * (1f - k)
            pos = from + (to - from) * e; invalidate(); if (k < 1f) android.view.Choreographer.getInstance().postFrameCallback(this) } }
        android.view.Choreographer.getInstance().postFrameCallback(cb) }
    private fun mix(a: Int, b: Int, t: Float): Int = Color.rgb((Color.red(a) + (Color.red(b) - Color.red(a)) * t).toInt(), (Color.green(a) + (Color.green(b) - Color.green(a)) * t).toInt(), (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t).toInt())
    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat(); val r = h / 2f
        p.style = Paint.Style.FILL; p.color = mix(Color.parseColor("#48484E"), Color.parseColor("#34C759"), pos); c.drawRoundRect(RectF(0f, 0f, w, h), r, r, p)
        val kr = r - h * 0.09f; val cx = r + (w - 2 * r) * pos
        p.color = Color.argb(60, 0, 0, 0); c.drawCircle(cx, r + h * 0.04f, kr, p)
        p.color = Color.WHITE; c.drawCircle(cx, r, kr, p)
    }
}

// Apple TV tarzı cam yansıması: seçilince kutunun üzerinden çapraz bir ışık bandı kayar, üstte hafif parlaklık kalır
class ShineView(context: Context) : View(context) {
    private var active = false; private var prog = 2f; private var gen = 0
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    fun play() { active = true; val g = ++gen; prog = 0f; val start = android.os.SystemClock.uptimeMillis() + 120
        val cb = object : android.view.Choreographer.FrameCallback { override fun doFrame(t: Long) { if (g != gen) return
            val k = ((android.os.SystemClock.uptimeMillis() - start) / 850f).coerceIn(0f, 1f); prog = k * k * (3 - 2 * k); invalidate()
            if (k < 1f) android.view.Choreographer.getInstance().postFrameCallback(this) else { prog = 2f; invalidate() } } }
        android.view.Choreographer.getInstance().postFrameCallback(cb) }
    fun stop() { active = false; gen++; prog = 2f; invalidate() }
    override fun onDraw(c: Canvas) {
        if (!active) return
        val w = width.toFloat(); val h = height.toFloat()
        // Üstte sabit, çok hafif cam parlaklığı
        p.shader = android.graphics.LinearGradient(0f, 0f, 0f, h * 0.55f, Color.argb(34, 255, 255, 255), Color.argb(0, 255, 255, 255), Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w, h, p)
        // Kayan çapraz ışık bandı
        if (prog <= 1f) { val band = w * 0.28f; val cx = -band + (w + 2 * band) * prog
            p.shader = android.graphics.LinearGradient(cx - band, -band * 0.45f, cx + band, band * 0.45f, intArrayOf(Color.argb(0, 255, 255, 255), Color.argb(95, 255, 255, 255), Color.argb(0, 255, 255, 255)), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
            c.drawRect(0f, 0f, w, h, p) }
        p.shader = null
    }
}
