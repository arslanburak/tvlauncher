package com.burak.tvlauncher

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.PorterDuff
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.ConnectivityManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// Hafif, Apple TV'den esinlenen ana ekran.
// Uygulamaya uzun basınca (Tamam tuşuna basılı tut): Taşı / Gizle / Kaldır / Uygulama bilgisi.
class MainActivity : Activity() {

    private data class AppItem(
        val pkg: String,
        val cls: String,
        val label: String,
        val image: Drawable,
        val isBanner: Boolean
    )

    // İlk açılışta bu sırayla görünür. Sonra taşıdığın sıra kaydedilir.
    private val pinned = listOf(
        "com.netflix.ninja",
        "com.google.android.youtube.tv",
        "com.amazon.amazonvideo.livingroom",
        "com.disney.disneyplus",
        "com.wbd.stream",
        "com.apple.atve.androidtv.appletv",
        "com.ttnet.tivibutv",
        "com.beonetv.tod"
    )

    // Düzenle menüsünden değiştirilebilir ayarlar
    private val rowSize: Int get() = prefs.getInt("rowSize", 8)   // Üst satırdaki uygulama sayısı
    private val tileW: Int get() = prefs.getInt("tileW", 150)     // Kutu genişliği (dp)
    private val tileH: Int get() = tileW * 84 / 150

    // Arka plan seçenekleri: yumuşak tonlar (5 renkli dikey degrade)
    private fun c(vararg h: String): IntArray = IntArray(h.size) { Color.parseColor(h[it]) }

    private val bgPresets: List<Pair<String, IntArray?>> = listOf(
        Pair("Klasik (fotoğraf)", null),
        Pair("Gece mavisi", c("#0F1624", "#141D2E", "#55627A", "#2E3E58", "#3C5272")),
        Pair("Orman yeşili", c("#121714", "#19211C", "#66756B", "#34463C", "#455A4C")),
        Pair("Gül kurusu", c("#1A1214", "#211619", "#7A6468", "#4A2E36", "#5C3A44")),
        Pair("Kum", c("#1C1A18", "#23201D", "#8A8379", "#5A5248", "#6E6458")),
        Pair("Mor alacakaranlık", c("#15131C", "#1C1A26", "#70697F", "#433C58", "#544B6B")),
        Pair("Antrasit (düz)", c("#17181C", "#1B1C21", "#202228", "#23252B", "#272A31"))
    )

    private val matchP = ViewGroup.LayoutParams.MATCH_PARENT
    private val wrap = ViewGroup.LayoutParams.WRAP_CONTENT

    private lateinit var prefs: SharedPreferences
    private lateinit var clock: TextView
    private lateinit var date: TextView
    private lateinit var wifiIcon: ImageView
    private lateinit var label: TextView
    private lateinit var row1: LinearLayout
    private lateinit var row2: LinearLayout
    private lateinit var bgView: ImageView
    private val handler = Handler(Looper.getMainLooper())

    private var shown = mutableListOf<AppItem>()
    private var hiddenApps = listOf<AppItem>()
    private var movingPkg: String? = null
    private var lastPkg: String? = null

    private val tick = object : Runnable {
        override fun run() {
            val now = Date()
            clock.text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(now)
            date.text = SimpleDateFormat("EEEE, d MMMM", Locale("tr", "TR")).format(now)
            updateWifi()
            handler.postDelayed(this, 15000)
        }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun makeRow(): Pair<HorizontalScrollView, LinearLayout> {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(64), dp(16), dp(64), dp(16))
            clipChildren = false
            clipToPadding = false
        }
        val scroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            clipChildren = false
            clipToPadding = false
            addView(row)
        }
        return Pair(scroll, row)
    }

    private fun iconImage(res: Int): ImageView = ImageView(this).apply {
        setImageResource(res)
        setColorFilter(Color.WHITE, PorterDuff.Mode.SRC_IN)
        scaleType = ImageView.ScaleType.FIT_CENTER
        setPadding(dp(10), dp(10), dp(10), dp(10))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("launcher", Context.MODE_PRIVATE)

        val root = FrameLayout(this)
        root.setBackgroundColor(Color.parseColor("#1A1A1A"))
        root.clipChildren = false

        // Arka plan: yumuşak, yazısız flu degrade
        bgView = ImageView(this).apply { scaleType = ImageView.ScaleType.FIT_XY }
        root.addView(bgView, FrameLayout.LayoutParams(matchP, matchP))
        applyBg()

        // Saat ve tarih
        val timeBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.END
        }
        clock = TextView(this).apply {
            textSize = 30f
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
            setTextColor(Color.WHITE)
            gravity = Gravity.END
        }
        date = TextView(this).apply {
            textSize = 15f
            setTextColor(Color.parseColor("#D0D0D8"))
            gravity = Gravity.END
        }
        timeBox.addView(clock)
        timeBox.addView(date)

        // Sağ üst: Wi-Fi, ayarlar, saat
        wifiIcon = iconImage(R.drawable.ic_wifi)
        val topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            clipChildren = false
        }
        topBar.addView(iconButton(wifiIcon) { openSettings(Settings.ACTION_WIFI_SETTINGS) })
        topBar.addView(
            iconButton(iconImage(R.drawable.ic_settings)) { openSettings(Settings.ACTION_SETTINGS) }
        )
        topBar.addView(
            timeBox,
            LinearLayout.LayoutParams(wrap, wrap).apply { setMargins(dp(24), 0, 0, 0) }
        )
        root.addView(
            topBar,
            FrameLayout.LayoutParams(wrap, wrap, Gravity.TOP or Gravity.END).apply {
                setMargins(0, dp(24), dp(48), 0)
            }
        )

        // Alt kısım: uygulama adı + iki satır
        val shelf = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            clipChildren = false
            setPadding(0, 0, 0, dp(28))
        }
        label = TextView(this).apply {
            textSize = 30f
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
            setTextColor(Color.WHITE)
            setShadowLayer(10f, 0f, 2f, Color.argb(170, 0, 0, 0))
        }
        shelf.addView(
            label,
            LinearLayout.LayoutParams(wrap, wrap).apply { setMargins(dp(68), 0, 0, 0) }
        )
        val r1 = makeRow()
        row1 = r1.second
        shelf.addView(r1.first, LinearLayout.LayoutParams(matchP, wrap))
        val r2 = makeRow()
        row2 = r2.second
        shelf.addView(r2.first, LinearLayout.LayoutParams(matchP, wrap))

        // Alt kısımda "Düzenle" butonu
        val pill = GradientDrawable().apply {
            cornerRadius = dp(22).toFloat()
            setColor(Color.argb(80, 0, 0, 0))
        }
        val editBtn = TextView(this).apply {
            text = "Düzenle"
            textSize = 15f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(dp(24), dp(8), dp(24), dp(8))
            background = pill
            isFocusable = true
        }
        editBtn.setOnFocusChangeListener { v, hasFocus ->
            if (hasFocus) {
                v.animate().scaleX(1.1f).scaleY(1.1f).setDuration(120).start()
                pill.setStroke(dp(2), Color.WHITE)
                label.text = "Ana ekran ayarları"
            } else {
                v.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
                pill.setStroke(0, Color.TRANSPARENT)
            }
        }
        editBtn.setOnClickListener { showSettings() }
        shelf.addView(
            editBtn,
            LinearLayout.LayoutParams(wrap, wrap).apply { setMargins(dp(68), dp(8), 0, 0) }
        )

        root.addView(shelf, FrameLayout.LayoutParams(matchP, wrap, Gravity.BOTTOM))
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        refreshApps(lastPkg)
        handler.post(tick)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(tick)
    }

    // Taşıma modunda yön tuşları kutuyu kaydırır, Tamam/Geri bitirir.
    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        if (movingPkg != null) {
            if (e.action == KeyEvent.ACTION_DOWN) {
                when (e.keyCode) {
                    KeyEvent.KEYCODE_DPAD_LEFT -> moveBy(-1)
                    KeyEvent.KEYCODE_DPAD_RIGHT -> moveBy(1)
                    KeyEvent.KEYCODE_DPAD_CENTER,
                    KeyEvent.KEYCODE_ENTER,
                    KeyEvent.KEYCODE_BACK -> endMove()
                    else -> {}
                }
            }
            return true
        }
        return super.dispatchKeyEvent(e)
    }

    // Ana ekranda Geri tuşu bir şey yapmasın.
    @Suppress("OVERRIDE_DEPRECATION")
    override fun onBackPressed() {}

    // ---------- Uygulama listesi, sıra, gizleme ----------

    private fun loadAll(): List<AppItem> {
        val pm = packageManager
        val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER)
        val order = (prefs.getString("order", "") ?: "").split("|").filter { it.isNotEmpty() }
        return pm.queryIntentActivities(query, 0)
            .filter { it.activityInfo.packageName != packageName }
            .map {
                val banner = it.activityInfo.loadBanner(pm)
                AppItem(
                    it.activityInfo.packageName,
                    it.activityInfo.name,
                    it.loadLabel(pm).toString(),
                    banner ?: it.loadIcon(pm),
                    banner != null
                )
            }
            .sortedWith(compareBy({
                val o = order.indexOf(it.pkg)
                if (o >= 0) {
                    o
                } else {
                    val p = pinned.indexOf(it.pkg)
                    10000 + (if (p >= 0) p else 1000)
                }
            }, { it.label.lowercase() }))
    }

    private fun refreshApps(focusPkg: String?) {
        val all = loadAll()
        val hidden = prefs.getStringSet("hidden", emptySet()) ?: emptySet()
        shown = all.filter { !hidden.contains(it.pkg) }.toMutableList()
        hiddenApps = all.filter { hidden.contains(it.pkg) }
        rebuildRows(focusPkg)
    }

    private fun rebuildRows(focusPkg: String?) {
        row1.removeAllViews()
        row2.removeAllViews()
        var target: View? = null
        shown.forEachIndexed { i, app ->
            val t = tile(app)
            if (i < rowSize) row1.addView(t) else row2.addView(t)
            if (app.pkg == focusPkg) target = t
        }
        if (hiddenApps.isNotEmpty()) row2.addView(hiddenTile())
        (target ?: row1.getChildAt(0) ?: row2.getChildAt(0))?.requestFocus()
    }

    private fun saveOrder() {
        val list = shown.map { it.pkg } + hiddenApps.map { it.pkg }
        prefs.edit().putString("order", list.joinToString("|")).apply()
    }

    private fun startMove(app: AppItem) {
        movingPkg = app.pkg
        rebuildRows(app.pkg)
    }

    private fun moveBy(d: Int) {
        val mp = movingPkg ?: return
        val i = shown.indexOfFirst { it.pkg == mp }
        val j = i + d
        if (i < 0 || j < 0 || j >= shown.size) return
        val tmp = shown[i]
        shown[i] = shown[j]
        shown[j] = tmp
        saveOrder()
        rebuildRows(mp)
    }

    private fun endMove() {
        val mp = movingPkg
        movingPkg = null
        rebuildRows(mp)
    }

    private fun hide(app: AppItem) {
        val h = (prefs.getStringSet("hidden", emptySet()) ?: emptySet()).toMutableSet()
        h.add(app.pkg)
        prefs.edit().putStringSet("hidden", h).apply()
        refreshApps(null)
    }

    private fun unhide(app: AppItem) {
        val h = (prefs.getStringSet("hidden", emptySet()) ?: emptySet()).toMutableSet()
        h.remove(app.pkg)
        prefs.edit().putStringSet("hidden", h).apply()
        refreshApps(app.pkg)
    }

    private fun showMenu(app: AppItem) {
        val items = arrayOf("Taşı", "Gizle", "Kaldır", "Uygulama bilgisi")
        AlertDialog.Builder(this)
            .setTitle(app.label)
            .setItems(items) { _, which ->
                when (which) {
                    0 -> startMove(app)
                    1 -> hide(app)
                    2 -> uninstall(app)
                    3 -> appInfo(app)
                    else -> {}
                }
            }
            .show()
    }

    private fun showHidden() {
        val names = hiddenApps.map { it.label }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Gizlenenler: göstermek için seç")
            .setItems(names) { _, which -> unhide(hiddenApps[which]) }
            .show()
    }

    private fun uninstall(app: AppItem) {
        try {
            startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:" + app.pkg)))
        } catch (_: Exception) {}
    }

    private fun appInfo(app: AppItem) {
        try {
            startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + app.pkg))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (_: Exception) {}
    }

    // ---------- Ayarlar, Wi-Fi ----------

    private fun openSettings(action: String) {
        try {
            startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            try {
                startActivity(
                    Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            } catch (_: Exception) {}
        }
    }

    @Suppress("DEPRECATION")
    private fun updateWifi() {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val ok = cm.activeNetworkInfo?.isConnected == true
        wifiIcon.setColorFilter(
            if (ok) Color.WHITE else Color.parseColor("#7A8594"),
            PorterDuff.Mode.SRC_IN
        )
    }

    private fun iconButton(icon: View, action: () -> Unit): View {
        val bg = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.TRANSPARENT)
        }
        val f = FrameLayout(this).apply {
            background = bg
            isFocusable = true
            addView(icon, FrameLayout.LayoutParams(matchP, matchP))
        }
        f.setOnFocusChangeListener { v, has ->
            if (has) {
                bg.setColor(Color.argb(70, 255, 255, 255))
                v.animate().scaleX(1.15f).scaleY(1.15f).setDuration(120).start()
            } else {
                bg.setColor(Color.TRANSPARENT)
                v.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
            }
        }
        f.setOnClickListener { action() }
        f.layoutParams = LinearLayout.LayoutParams(dp(48), dp(48)).apply {
            setMargins(dp(6), 0, dp(6), 0)
        }
        return f
    }

    // ---------- Ana ekran ayarları ----------

    private fun applyBg() {
        val idx = prefs.getInt("bg", 0).coerceIn(0, bgPresets.size - 1)
        val colors = bgPresets[idx].second
        if (colors == null) {
            bgView.setImageResource(R.drawable.bg)
        } else {
            bgView.setImageDrawable(
                GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, colors)
            )
        }
    }

    private fun showSettings() {
        val items = arrayOf(
            "Kutu boyutu",
            "Arka plan",
            "Üst satırdaki uygulama sayısı",
            "Varsayılana sıfırla"
        )
        AlertDialog.Builder(this)
            .setTitle("Ana ekran ayarları")
            .setItems(items) { _, which ->
                when (which) {
                    0 -> showSizeChoice()
                    1 -> showBgChoice()
                    2 -> showRowChoice()
                    3 -> resetSettings()
                    else -> {}
                }
            }
            .show()
    }

    // Seçim anında uygulanır, böylece arkada sonucu görürsün.
    private fun showChoice(title: String, labels: Array<String>, checked: Int, onPick: (Int) -> Unit) {
        val dlg = AlertDialog.Builder(this)
            .setTitle(title)
            .setSingleChoiceItems(labels, checked) { _, which -> onPick(which) }
            .setPositiveButton("Tamam", null)
            .create()
        dlg.show()
        dlg.window?.setDimAmount(0.1f)
        dlg.window?.setGravity(Gravity.TOP or Gravity.START)
    }

    private fun showSizeChoice() {
        val sizes = intArrayOf(110, 130, 150, 180, 210)
        val labels = arrayOf("Çok küçük", "Küçük", "Orta (varsayılan)", "Büyük", "Çok büyük")
        val cur = sizes.indexOf(tileW).let { if (it >= 0) it else 2 }
        showChoice("Kutu boyutu", labels, cur) { i ->
            prefs.edit().putInt("tileW", sizes[i]).apply()
            rebuildRows(lastPkg)
        }
    }

    private fun showBgChoice() {
        val labels = bgPresets.map { it.first }.toTypedArray()
        val cur = prefs.getInt("bg", 0).coerceIn(0, bgPresets.size - 1)
        showChoice("Arka plan", labels, cur) { i ->
            prefs.edit().putInt("bg", i).apply()
            applyBg()
        }
    }

    private fun showRowChoice() {
        val counts = intArrayOf(4, 5, 6, 7, 8, 9, 10, 99)
        val labels = counts.map { if (it == 99) "Hepsi tek satırda" else "$it uygulama" }.toTypedArray()
        val cur = counts.indexOf(rowSize).let { if (it >= 0) it else 4 }
        showChoice("Üst satırdaki uygulama sayısı", labels, cur) { i ->
            prefs.edit().putInt("rowSize", counts[i]).apply()
            rebuildRows(lastPkg)
        }
    }

    private fun resetSettings() {
        prefs.edit().remove("tileW").remove("bg").remove("rowSize").apply()
        applyBg()
        rebuildRows(lastPkg)
    }

    // ---------- Kutular ----------

    private fun tile(app: AppItem): View {
        val bg = GradientDrawable().apply {
            cornerRadius = dp(14).toFloat()
            setColor(Color.parseColor("#2B2B40"))
        }
        val frame = FrameLayout(this).apply {
            background = bg
            isFocusable = true
            clipToOutline = true
            elevation = dp(3).toFloat()
            tag = app.pkg
        }
        val img = ImageView(this).apply {
            setImageDrawable(app.image)
            if (app.isBanner) {
                scaleType = ImageView.ScaleType.CENTER_CROP
            } else {
                scaleType = ImageView.ScaleType.FIT_CENTER
                setPadding(dp(tileW / 7), dp(tileH / 6), dp(tileW / 7), dp(tileH / 6))
            }
        }
        frame.addView(img, FrameLayout.LayoutParams(matchP, matchP))

        frame.setOnFocusChangeListener { v, hasFocus ->
            if (hasFocus) {
                lastPkg = app.pkg
                v.animate().scaleX(1.15f).scaleY(1.15f)
                    .translationZ(dp(14).toFloat()).setDuration(130).start()
                val moving = movingPkg == app.pkg
                bg.setStroke(dp(3), if (moving) Color.parseColor("#FF9F0A") else Color.WHITE)
                label.text = if (moving) {
                    app.label + "   (← → ile kaydır, Tamam ile bitir)"
                } else {
                    app.label
                }
            } else {
                v.animate().scaleX(1f).scaleY(1f).translationZ(0f).setDuration(130).start()
                bg.setStroke(0, Color.TRANSPARENT)
            }
        }
        frame.setOnClickListener {
            val i = Intent(Intent.ACTION_MAIN)
                .setClassName(app.pkg, app.cls)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            try { startActivity(i) } catch (_: Exception) {}
        }
        frame.setOnLongClickListener {
            showMenu(app)
            true
        }

        frame.layoutParams = LinearLayout.LayoutParams(dp(tileW), dp(tileH)).apply {
            setMargins(0, 0, dp(20), 0)
        }
        return frame
    }

    // Gizlenen uygulama varsa son satırın sonunda çıkan kutu
    private fun hiddenTile(): View {
        val bg = GradientDrawable().apply {
            cornerRadius = dp(14).toFloat()
            setColor(Color.argb(90, 0, 0, 0))
        }
        val frame = FrameLayout(this).apply {
            background = bg
            isFocusable = true
        }
        val tv = TextView(this).apply {
            text = "Gizlenenler (" + hiddenApps.size + ")"
            textSize = 15f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        frame.addView(tv, FrameLayout.LayoutParams(matchP, matchP))
        frame.setOnFocusChangeListener { v, hasFocus ->
            if (hasFocus) {
                v.animate().scaleX(1.15f).scaleY(1.15f).setDuration(130).start()
                bg.setStroke(dp(3), Color.WHITE)
                label.text = "Gizlenen uygulamalar"
            } else {
                v.animate().scaleX(1f).scaleY(1f).setDuration(130).start()
                bg.setStroke(0, Color.TRANSPARENT)
            }
        }
        frame.setOnClickListener { showHidden() }
        frame.layoutParams = LinearLayout.LayoutParams(dp(tileW), dp(tileH)).apply {
            setMargins(0, 0, dp(20), 0)
        }
        return frame
    }
}
