package com.burak.tvlauncher

import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.ConnectivityManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

// Hafif, Apple TV'den esinlenen ana ekran.
// Uygulamaya uzun basınca (Tamam tuşuna basılı tut): Taşı / Gizle / Kaldır / Uygulama bilgisi.
// Alttaki "Düzenle": sütun sayısı, arka plan, hava durumu konumu, karşılama adı.
class MainActivity : Activity() {

    private data class AppItem(
        val pkg: String,
        val cls: String,
        val label: String,
        val image: Drawable,
        val isBanner: Boolean
    )

    private class City(val name: String, val lat: String, val lon: String)

    // Panel satırı: etiket, sol simge, simge rengi, renk örneği, ikinci satır, ok
    private class PItem(
        val label: String,
        val glyph: Int = -1,
        val tint: String = "#5B6B8C",
        val swatch: IntArray? = null,
        val photo: Boolean = false,
        val sub: String? = null,
        val arrow: Boolean = false
    )

    // İlk açılışta bu sırayla görünür. Sonra taşıdığın sıra kaydedilir.
    private val pinned = listOf(
        "com.netflix.ninja",
        "com.google.android.youtube.tv",
        "com.amazon.amazonvideo.livingroom",
        "com.disney.disneyplus",
        "com.wbd.stream",
        "com.apple.atve.androidtv.appletv",
        "com.ttnet.tivibutv",
        "com.beonetv.tod"
    )

    private val cities = listOf(
        City("İstanbul", "41.01", "28.98"),
        City("Ankara", "39.93", "32.86"),
        City("İzmir", "38.42", "27.14"),
        City("Bursa", "40.19", "29.06"),
        City("Antalya", "36.90", "30.69"),
        City("Adana", "37.00", "35.32"),
        City("Konya", "37.87", "32.48"),
        City("Gaziantep", "37.07", "37.38"),
        City("Şanlıurfa", "37.16", "38.80"),
        City("Kocaeli", "40.77", "29.94"),
        City("Mersin", "36.80", "34.64"),
        City("Diyarbakır", "37.91", "40.24"),
        City("Hatay", "36.20", "36.16"),
        City("Manisa", "38.61", "27.43"),
        City("Kayseri", "38.72", "35.49"),
        City("Samsun", "41.29", "36.33"),
        City("Balıkesir", "39.65", "27.89"),
        City("Trabzon", "41.00", "39.72"),
        City("Eskişehir", "39.77", "30.52"),
        City("Denizli", "37.78", "29.09")
    )

    private val tileGap = 24          // Kutular arası boşluk (dp)
    private val gridPad = 64          // Sağ/sol kenar boşluğu (dp)
    private val rowGap = 24           // Satırlar arası boşluk (dp)
    private val focusScale = 1.25f    // Seçili kutunun büyüme oranı

    private val cols: Int get() = prefs.getInt("cols", 5)   // Sütun sayısı

    // Kutu boyutu sütun sayısına göre otomatik hesaplanır (az sütun = büyük kutu)
    private val tileW: Int
        get() {
            val sw = (resources.displayMetrics.widthPixels / resources.displayMetrics.density).toInt()
            return (sw - 2 * gridPad) / cols - tileGap
        }
    private val tileH: Int get() = tileW * 84 / 150

    // Arka plan seçenekleri: yumuşak tonlar (5 renkli dikey degrade)
    private fun c(vararg h: String): IntArray = IntArray(h.size) { Color.parseColor(h[it]) }

    private val bgPresets: List<Pair<String, IntArray?>> = listOf(
        Pair("Klasik (fotoğraf)", null),
        Pair("Gece mavisi", c("#0F1624", "#141D2E", "#55627A", "#2E3E58", "#3C5272")),
        Pair("Orman yeşili", c("#121714", "#19211C", "#66756B", "#34463C", "#455A4C")),
        Pair("Gül kurusu", c("#1A1214", "#211619", "#7A6468", "#4A2E36", "#5C3A44")),
        Pair("Kum", c("#1C1A18", "#23201D", "#8A8379", "#5A5248", "#6E6458")),
        Pair("Mor alacakaranlık", c("#15131C", "#1C1A26", "#70697F", "#433C58", "#544B6B")),
        Pair("Antrasit (düz)", c("#17181C", "#1B1C21", "#202228", "#23252B", "#272A31"))
    )

    private val matchP = ViewGroup.LayoutParams.MATCH_PARENT
    private val wrap = ViewGroup.LayoutParams.WRAP_CONTENT

    private lateinit var prefs: SharedPreferences
    private lateinit var greeting: TextView
    private lateinit var clock: TextView
    private lateinit var date: TextView
    private lateinit var weatherText: TextView
    private lateinit var wxIcon: WxIconView
    private lateinit var wifiIcon: ImageView
    private lateinit var label: TextView
    private lateinit var subLabel: TextView
    private lateinit var grid: LinearLayout
    private lateinit var gridScroll: ScrollView
    private lateinit var bgView: ImageView
    private val handler = Handler(Looper.getMainLooper())

    private var shown = mutableListOf<AppItem>()
    private var hiddenApps = listOf<AppItem>()
    private var movingPkg: String? = null
    private var lastPkg: String? = null
    private var lastWeather = 0L

    private val hintApp = "Açmak için Tamam   ·   Seçenekler için Tamam'a basılı tut"

    private val tick = object : Runnable {
        override fun run() {
            val now = Date()
            clock.text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(now)
            date.text = SimpleDateFormat("d MMMM, EEEE", Locale("tr", "TR")).format(now)
            greeting.text = greetingText()
            updateWifi()
            if (System.currentTimeMillis() - lastWeather > 30 * 60 * 1000L) {
                lastWeather = System.currentTimeMillis()
                fetchWeather()
            }
            handler.postDelayed(this, 15000)
        }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun greetingText(): String {
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val g = when {
            h < 5 -> "İyi geceler"
            h < 12 -> "Günaydın"
            h < 18 -> "İyi günler"
            else -> "İyi akşamlar"
        }
        val n = prefs.getString("name", "") ?: ""
        return if (n.isEmpty()) g else g + ", " + n
    }

    // Koyu saydam "cam" arka plan
    private fun glass(radiusDp: Int, alpha: Int): GradientDrawable = GradientDrawable().apply {
        cornerRadius = dp(radiusDp).toFloat()
        setColor(Color.argb(alpha, 20, 22, 28))
        setStroke(dp(1), Color.argb(55, 255, 255, 255))
    }

    private fun iconImage(res: Int): ImageView = ImageView(this).apply {
        setImageResource(res)
        setColorFilter(Color.WHITE, PorterDuff.Mode.SRC_IN)
        scaleType = ImageView.ScaleType.FIT_CENTER
        setPadding(dp(10), dp(10), dp(10), dp(10))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("launcher", Context.MODE_PRIVATE)

        val root = FrameLayout(this)
        root.setBackgroundColor(Color.parseColor("#1A1A1A"))
        root.clipChildren = false

        // Arka plan + alttan yumuşak karartma (okunabilirlik için)
        bgView = ImageView(this).apply { scaleType = ImageView.ScaleType.FIT_XY }
        root.addView(bgView, FrameLayout.LayoutParams(matchP, matchP))
        applyBg()
        val scrim = View(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.argb(0, 0, 0, 0), Color.argb(150, 0, 0, 0))
            )
        }
        root.addView(
            scrim,
            FrameLayout.LayoutParams(
                matchP, (resources.displayMetrics.heightPixels * 0.6f).toInt(), Gravity.BOTTOM
            )
        )

        // Sol üst: karşılama
        greeting = TextView(this).apply {
            textSize = 26f
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
            setTextColor(Color.WHITE)
            setShadowLayer(10f, 0f, 2f, Color.argb(140, 0, 0, 0))
        }
        root.addView(
            greeting,
            FrameLayout.LayoutParams(wrap, wrap, Gravity.TOP or Gravity.START).apply {
                setMargins(dp(gridPad + 4), dp(42), 0, 0)
            }
        )

        // Sağ üst: koyu saydam hap (Wi-Fi, ayarlar | saat, tarih, hava durumu)
        val timeBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.END
            clipChildren = false
        }
        clock = TextView(this).apply {
            textSize = 24f
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
            setTextColor(Color.WHITE)
            gravity = Gravity.END
        }
        date = TextView(this).apply {
            textSize = 12.5f
            setTextColor(Color.parseColor("#C9C9D3"))
            gravity = Gravity.END
        }
        wxIcon = WxIconView(this, WxIconView.CLOUD)
        weatherText = TextView(this).apply {
            textSize = 12.5f
            setTextColor(Color.parseColor("#C9C9D3"))
        }
        val wxRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(3), dp(8), dp(3))
        }
        wxRow.addView(
            wxIcon,
            LinearLayout.LayoutParams(dp(18), dp(18)).apply { setMargins(0, 0, dp(6), 0) }
        )
        wxRow.addView(weatherText)
        val wxBg = GradientDrawable().apply {
            cornerRadius = dp(10).toFloat()
            setColor(Color.TRANSPARENT)
        }
        val weatherBox = FrameLayout(this).apply {
            background = wxBg
            isFocusable = true
            addView(wxRow)
        }
        weatherBox.setOnFocusChangeListener { _, has ->
            wxBg.setColor(if (has) Color.argb(70, 255, 255, 255) else Color.TRANSPARENT)
        }
        weatherBox.setOnClickListener { showCityPanel(null) }
        timeBox.addView(clock)
        timeBox.addView(date)
        timeBox.addView(
            weatherBox,
            LinearLayout.LayoutParams(wrap, wrap).apply { setMargins(0, dp(2), 0, 0) }
        )

        wifiIcon = iconImage(R.drawable.ic_wifi)
        val topPill = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = glass(32, 105)
            setPadding(dp(8), dp(8), dp(22), dp(8))
            clipChildren = false
        }
        topPill.addView(iconButton(wifiIcon) { openSettings(Settings.ACTION_WIFI_SETTINGS) })
        topPill.addView(
            iconButton(iconImage(R.drawable.ic_settings)) { openSettings(Settings.ACTION_SETTINGS) }
        )
        val divider = View(this).apply { setBackgroundColor(Color.argb(60, 255, 255, 255)) }
        topPill.addView(
            divider,
            LinearLayout.LayoutParams(dp(1), dp(40)).apply { setMargins(dp(10), 0, dp(16), 0) }
        )
        topPill.addView(timeBox)
        root.addView(
            topPill,
            FrameLayout.LayoutParams(wrap, wrap, Gravity.TOP or Gravity.END).apply {
                setMargins(0, dp(28), dp(48), 0)
            }
        )
        updateWeatherText()

        // Alt kısım: uygulama adı + ızgara + Düzenle
        val shelf = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            clipChildren = false
            setPadding(0, 0, 0, dp(16))
        }
        label = TextView(this).apply {
            textSize = 30f
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
            setTextColor(Color.WHITE)
            setShadowLayer(10f, 0f, 2f, Color.argb(170, 0, 0, 0))
        }
        shelf.addView(
            label,
            LinearLayout.LayoutParams(wrap, wrap).apply { setMargins(dp(gridPad + 4), 0, 0, 0) }
        )
        subLabel = TextView(this).apply {
            textSize = 13f
            setTextColor(Color.parseColor("#C0C0CB"))
            setShadowLayer(8f, 0f, 1f, Color.argb(150, 0, 0, 0))
        }
        shelf.addView(
            subLabel,
            LinearLayout.LayoutParams(wrap, wrap).apply { setMargins(dp(gridPad + 4), dp(2), 0, 0) }
        )

        grid = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(gridPad), dp(24), dp(gridPad), dp(24))
            clipChildren = false
            clipToPadding = false
        }
        gridScroll = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            clipChildren = false
            clipToPadding = false
            addView(grid)
        }
        shelf.addView(gridScroll, LinearLayout.LayoutParams(matchP, wrap))

        // Düzenle: ortada, koyu saydam hap
        val editBg = glass(40, 150)
        val editBtn = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = editBg
            isFocusable = true
            setPadding(dp(22), dp(9), dp(26), dp(9))
        }
        val editGlyph = GlyphView(this, GlyphView.SLIDERS)
        editBtn.addView(
            editGlyph,
            LinearLayout.LayoutParams(dp(20), dp(20)).apply { setMargins(0, 0, dp(10), 0) }
        )
        editBtn.addView(TextView(this).apply {
            text = "Düzenle"
            textSize = 14f
            setTextColor(Color.WHITE)
        })
        editBtn.setOnFocusChangeListener { v, hasFocus ->
            if (hasFocus) {
                v.animate().scaleX(1.1f).scaleY(1.1f).setDuration(120).start()
                editBg.setColor(Color.argb(205, 42, 44, 52))
                editBg.setStroke(dp(2), Color.WHITE)
                label.text = "Ana ekran ayarları"
                subLabel.text = "Sütun sayısı, arka plan, hava durumu ve karşılama adı"
            } else {
                v.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
                editBg.setColor(Color.argb(150, 20, 22, 28))
                editBg.setStroke(dp(1), Color.argb(55, 255, 255, 255))
            }
        }
        editBtn.setOnClickListener { showSettings() }
        shelf.addView(
            editBtn,
            LinearLayout.LayoutParams(wrap, wrap).apply {
                gravity = Gravity.CENTER_HORIZONTAL
                setMargins(0, dp(8), 0, 0)
            }
        )

        root.addView(shelf, FrameLayout.LayoutParams(matchP, wrap, Gravity.BOTTOM))
        setContentView(root)
        greeting.text = greetingText()
    }

    override fun onResume() {
        super.onResume()
        refreshApps(lastPkg)
        handler.post(tick)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(tick)
    }

    // Taşıma modunda yön tuşları kutuyu kaydırır, Tamam/Geri bitirir.
    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        if (movingPkg != null) {
            if (e.action == KeyEvent.ACTION_DOWN) {
                when (e.keyCode) {
                    KeyEvent.KEYCODE_DPAD_LEFT -> moveBy(-1)
                    KeyEvent.KEYCODE_DPAD_RIGHT -> moveBy(1)
                    KeyEvent.KEYCODE_DPAD_UP -> moveBy(-cols)
                    KeyEvent.KEYCODE_DPAD_DOWN -> moveBy(cols)
                    KeyEvent.KEYCODE_DPAD_CENTER,
                    KeyEvent.KEYCODE_ENTER,
                    KeyEvent.KEYCODE_BACK -> endMove()
                    else -> {}
                }
            }
            return true
        }
        return super.dispatchKeyEvent(e)
    }

    // Ana ekranda Geri tuşu bir şey yapmasın.
    @Suppress("OVERRIDE_DEPRECATION")
    override fun onBackPressed() {}

    // ---------- Uygulama listesi, sıra, gizleme ----------

    private fun loadAll(): List<AppItem> {
        val pm = packageManager
        val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER)
        val order = (prefs.getString("order", "") ?: "").split("|").filter { it.isNotEmpty() }
        return pm.queryIntentActivities(query, 0)
            .filter { it.activityInfo.packageName != packageName }
            .map {
                val banner = it.activityInfo.loadBanner(pm)
                AppItem(
                    it.activityInfo.packageName,
                    it.activityInfo.name,
                    it.loadLabel(pm).toString(),
                    banner ?: it.loadIcon(pm),
                    banner != null
                )
            }
            .sortedWith(compareBy({
                val o = order.indexOf(it.pkg)
                if (o >= 0) {
                    o
                } else {
                    val p = pinned.indexOf(it.pkg)
                    10000 + (if (p >= 0) p else 1000)
                }
            }, { it.label.lowercase() }))
    }

    private fun refreshApps(focusPkg: String?) {
        val all = loadAll()
        val hidden = prefs.getStringSet("hidden", emptySet()) ?: emptySet()
        shown = all.filter { !hidden.contains(it.pkg) }.toMutableList()
        hiddenApps = all.filter { hidden.contains(it.pkg) }
        rebuildRows(focusPkg)
    }

    private fun rebuildRows(focusPkg: String?) {
        grid.removeAllViews()
        val n = cols
        val views = mutableListOf<View>()
        for (app in shown) views.add(tile(app))
        if (hiddenApps.isNotEmpty()) views.add(hiddenTile())

        var target: View? = null
        var cur: LinearLayout? = null
        views.forEachIndexed { i, v ->
            if (i % n == 0) {
                val r = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    clipChildren = false
                }
                cur = r
                grid.addView(
                    r,
                    LinearLayout.LayoutParams(wrap, wrap).apply { setMargins(0, 0, 0, dp(rowGap)) }
                )
            }
            cur?.addView(v)
            if (focusPkg != null && v.tag == focusPkg) target = v
        }

        // Ekrana sığan satır kadarını göster, fazlası dikey kayar
        val rows = (views.size + n - 1) / n
        val rowSpace = tileH + rowGap
        val screenH = (resources.displayMetrics.heightPixels / resources.displayMetrics.density).toInt()
        val maxRows = maxOf(1, (screenH - 250 - 48) / rowSpace)
        val lp = gridScroll.layoutParams
        lp.height = dp(minOf(rows, maxRows) * rowSpace + 48)
        gridScroll.layoutParams = lp

        (target ?: views.firstOrNull())?.requestFocus()
    }

    private fun saveOrder() {
        val list = shown.map { it.pkg } + hiddenApps.map { it.pkg }
        prefs.edit().putString("order", list.joinToString("|")).apply()
    }

    private fun startMove(app: AppItem) {
        movingPkg = app.pkg
        rebuildRows(app.pkg)
    }

    private fun moveBy(d: Int) {
        val mp = movingPkg ?: return
        val i = shown.indexOfFirst { it.pkg == mp }
        val j = i + d
        if (i < 0 || j < 0 || j >= shown.size) return
        val tmp = shown[i]
        shown[i] = shown[j]
        shown[j] = tmp
        saveOrder()
        rebuildRows(mp)
    }

    private fun endMove() {
        val mp = movingPkg
        movingPkg = null
        rebuildRows(mp)
    }

    private fun hide(app: AppItem) {
        val h = (prefs.getStringSet("hidden", emptySet()) ?: emptySet()).toMutableSet()
        h.add(app.pkg)
        prefs.edit().putStringSet("hidden", h).apply()
        refreshApps(null)
    }

    private fun unhide(app: AppItem) {
        val h = (prefs.getStringSet("hidden", emptySet()) ?: emptySet()).toMutableSet()
        h.remove(app.pkg)
        prefs.edit().putStringSet("hidden", h).apply()
        refreshApps(app.pkg)
    }

    private fun uninstall(app: AppItem) {
        try {
            startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:" + app.pkg)))
        } catch (_: Exception) {}
    }

    private fun appInfo(app: AppItem) {
        try {
            startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + app.pkg))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (_: Exception) {}
    }

    // ---------- Koyu saydam paneller (tüm menüler bu formda) ----------

    private fun panelBox(): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(16), dp(14), dp(12))
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.argb(238, 42, 44, 50), Color.argb(238, 24, 25, 29))
            ).apply {
                cornerRadius = dp(24).toFloat()
                setStroke(dp(1), Color.argb(55, 255, 255, 255))
            }
        }
    }

    private fun styleWindow(dlg: Dialog, widthDp: Int) {
        val w = dlg.window ?: return
        w.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        w.setLayout(dp(widthDp), ViewGroup.LayoutParams.WRAP_CONTENT)
        w.setGravity(Gravity.TOP or Gravity.CENTER_HORIZONTAL)
        w.setDimAmount(0.14f)
        val lp = w.attributes
        lp.y = dp(36)
        w.attributes = lp
    }

    private fun titleView(t: String): TextView = TextView(this).apply {
        this.text = t
        textSize = 17f
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        setTextColor(Color.WHITE)
        setPadding(dp(10), dp(2), dp(10), dp(12))
    }

    private fun footView(t: String): TextView = TextView(this).apply {
        this.text = t
        textSize = 11.5f
        setTextColor(Color.parseColor("#8E8E99"))
        setPadding(dp(10), dp(10), dp(10), 0)
    }

    // parent: Geri tuşuna basınca dönülecek menü (null ise tamamen kapanır)
    // stayOpen: seçince panel kapanmasın (sütun, arka plan gibi canlı önizleme için)
    private fun showPanel(
        title: String,
        items: List<PItem>,
        checked: Int,
        parent: (() -> Unit)?,
        stayOpen: Boolean,
        onPick: (Int) -> Unit
    ) {
        val dlg = Dialog(this)
        dlg.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val box = panelBox()
        box.addView(titleView(title))
        val line = View(this).apply { setBackgroundColor(Color.argb(35, 255, 255, 255)) }
        box.addView(line, LinearLayout.LayoutParams(matchP, dp(1)).apply { setMargins(0, 0, 0, dp(6)) })

        val selectable = stayOpen || checked >= 0
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val checks = mutableListOf<GlyphView>()
        var focusTarget: View? = null

        items.forEachIndexed { i, item ->
            val rowBg = GradientDrawable().apply {
                cornerRadius = dp(14).toFloat()
                setColor(Color.TRANSPARENT)
            }
            val r = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                isFocusable = true
                background = rowBg
                setPadding(dp(10), dp(8), dp(12), dp(8))
            }
            if (item.glyph >= 0) {
                val ic = FrameLayout(this).apply {
                    background = GradientDrawable().apply {
                        cornerRadius = dp(9).toFloat()
                        setColor(Color.parseColor(item.tint))
                    }
                }
                ic.addView(GlyphView(this, item.glyph), FrameLayout.LayoutParams(matchP, matchP))
                r.addView(
                    ic,
                    LinearLayout.LayoutParams(dp(34), dp(34)).apply { setMargins(0, 0, dp(12), 0) }
                )
            } else if (item.photo || item.swatch != null) {
                val sw: View
                if (item.photo) {
                    sw = ImageView(this).apply {
                        setImageResource(R.drawable.bg)
                        scaleType = ImageView.ScaleType.CENTER_CROP
                        background = GradientDrawable().apply {
                            cornerRadius = dp(9).toFloat()
                            setColor(Color.DKGRAY)
                        }
                        clipToOutline = true
                    }
                } else {
                    val sc = item.swatch ?: IntArray(2)
                    sw = View(this).apply {
                        background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, sc).apply {
                            cornerRadius = dp(9).toFloat()
                        }
                    }
                }
                r.addView(
                    sw,
                    LinearLayout.LayoutParams(dp(34), dp(34)).apply { setMargins(0, 0, dp(12), 0) }
                )
            }

            val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            col.addView(TextView(this).apply {
                this.text = item.label
                textSize = 15.5f
                setTextColor(Color.WHITE)
            })
            val subText = item.sub
            if (subText != null) {
                col.addView(TextView(this).apply {
                    this.text = subText
                    textSize = 12f
                    setTextColor(Color.parseColor("#9A9AA6"))
                })
            }
            r.addView(col, LinearLayout.LayoutParams(0, wrap, 1f))

            if (selectable) {
                val ck = GlyphView(this, GlyphView.CHECK)
                ck.visibility = if (i == checked) View.VISIBLE else View.INVISIBLE
                r.addView(ck, LinearLayout.LayoutParams(dp(22), dp(22)))
                checks.add(ck)
            } else if (item.arrow) {
                val ch = GlyphView(this, GlyphView.CHEVRON)
                ch.setTint(Color.parseColor("#8E8E99"))
                r.addView(ch, LinearLayout.LayoutParams(dp(20), dp(20)))
            }

            r.setOnFocusChangeListener { _, has ->
                rowBg.setColor(if (has) Color.argb(60, 255, 255, 255) else Color.TRANSPARENT)
                rowBg.setStroke(if (has) dp(1) else 0, Color.argb(90, 255, 255, 255))
            }
            r.setOnClickListener {
                if (stayOpen) {
                    checks.forEachIndexed { k, v ->
                        v.visibility = if (k == i) View.VISIBLE else View.INVISIBLE
                    }
                    onPick(i)
                } else {
                    dlg.dismiss()
                    onPick(i)
                }
            }
            list.addView(r, LinearLayout.LayoutParams(matchP, wrap).apply { setMargins(0, dp(1), 0, dp(1)) })
            if (i == (if (checked >= 0) checked else 0)) focusTarget = r
        }
        val sv = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            addView(list)
        }
        box.addView(sv, LinearLayout.LayoutParams(matchP, dp(minOf(items.size * 56, 330))))
        box.addView(footView(if (parent != null) "‹  Geri: önceki menü" else "Geri: kapat"))

        dlg.setContentView(box)
        styleWindow(dlg, 360)
        dlg.setOnCancelListener { parent?.invoke() }
        dlg.setOnShowListener { focusTarget?.requestFocus() }
        dlg.show()
    }

    private fun showInput(
        title: String,
        hint: String,
        initial: String,
        parent: (() -> Unit)?,
        onDone: (String) -> Unit
    ) {
        val dlg = Dialog(this)
        dlg.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val box = panelBox()
        box.addView(titleView(title))
        val et = EditText(this).apply {
            setText(initial)
            this.hint = hint
            setHintTextColor(Color.parseColor("#7C7C88"))
            setTextColor(Color.WHITE)
            textSize = 16f
            setSingleLine()
            imeOptions = EditorInfo.IME_ACTION_DONE
            background = GradientDrawable().apply {
                cornerRadius = dp(12).toFloat()
                setColor(Color.argb(60, 255, 255, 255))
            }
            setPadding(dp(14), dp(10), dp(14), dp(10))
        }
        et.setOnEditorActionListener { v, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_DONE || actionId == EditorInfo.IME_ACTION_SEARCH) {
                dlg.dismiss()
                onDone(v.text.toString().trim())
                true
            } else {
                false
            }
        }
        box.addView(et, LinearLayout.LayoutParams(matchP, wrap))
        box.addView(footView(if (parent != null) "‹  Geri: önceki menü" else "Geri: kapat"))
        dlg.setContentView(box)
        styleWindow(dlg, 360)
        dlg.setOnCancelListener { parent?.invoke() }
        dlg.show()
    }

    private fun showMenu(app: AppItem) {
        showPanel(
            app.label,
            listOf(
                PItem("Taşı", GlyphView.MOVE, "#4C7DF0"),
                PItem("Gizle", GlyphView.EYE_OFF, "#8A6BD6"),
                PItem("Kaldır", GlyphView.TRASH, "#C25A5A"),
                PItem("Uygulama bilgisi", GlyphView.INFO, "#6F7684")
            ),
            -1, null, false
        ) { which ->
            when (which) {
                0 -> startMove(app)
                1 -> hide(app)
                2 -> uninstall(app)
                3 -> appInfo(app)
                else -> {}
            }
        }
    }

    private fun showHidden() {
        showPanel(
            "Gizlenenler",
            hiddenApps.map { PItem(it.label, sub = "Göstermek için seç") },
            -1, null, false
        ) { which -> unhide(hiddenApps[which]) }
    }

    // ---------- Ana ekran ayarları ----------

    private fun applyBg() {
        val idx = prefs.getInt("bg", 0).coerceIn(0, bgPresets.size - 1)
        val colors = bgPresets[idx].second
        if (colors == null) {
            bgView.setImageResource(R.drawable.bg)
        } else {
            bgView.setImageDrawable(
                GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, colors)
            )
        }
    }

    private fun showSettings() {
        val bgName = bgPresets[prefs.getInt("bg", 0).coerceIn(0, bgPresets.size - 1)].first
        val city = prefs.getString("city", null)
        val name = prefs.getString("name", "") ?: ""
        showPanel(
            "Ana ekran ayarları",
            listOf(
                PItem("Sütun sayısı", GlyphView.GRID, "#4C7DF0", sub = cols.toString() + " sütun", arrow = true),
                PItem("Arka plan", GlyphView.PALETTE, "#8A6BD6", sub = bgName, arrow = true),
                PItem("Hava durumu konumu", GlyphView.CLOUD, "#3A9DB8", sub = city ?: "Seçilmedi", arrow = true),
                PItem("Karşılama adı", GlyphView.USER, "#D98A4E", sub = if (name.isEmpty()) "Yok" else name, arrow = true),
                PItem("Varsayılana sıfırla", GlyphView.RESET, "#6F7684")
            ),
            -1, null, false
        ) { which ->
            when (which) {
                0 -> showColsPanel()
                1 -> showBgPanel()
                2 -> showCityPanel { showSettings() }
                3 -> showNameInput()
                4 -> resetSettings()
                else -> {}
            }
        }
    }

    private fun showColsPanel() {
        val opts = intArrayOf(4, 5, 6, 7, 8, 9)
        val labels = opts.map { PItem(it.toString() + " sütun", sub = if (it <= 4) "Büyük kutular" else if (it >= 8) "Küçük kutular" else null) }
        val cur = opts.indexOf(cols).let { if (it >= 0) it else 1 }
        showPanel("Sütun sayısı", labels, cur, { showSettings() }, true) { i ->
            prefs.edit().putInt("cols", opts[i]).apply()
            rebuildRows(lastPkg)
        }
    }

    private fun showBgPanel() {
        val items = bgPresets.mapIndexed { idx, p ->
            PItem(p.first, swatch = p.second, photo = (idx == 0))
        }
        val cur = prefs.getInt("bg", 0).coerceIn(0, bgPresets.size - 1)
        showPanel("Arka plan", items, cur, { showSettings() }, true) { i ->
            prefs.edit().putInt("bg", i).apply()
            applyBg()
        }
    }

    private fun showNameInput() {
        val cur = prefs.getString("name", "") ?: ""
        showInput("Karşılama adı", "Adını yaz (boş bırakırsan sadece selam)", cur, { showSettings() }) { q ->
            prefs.edit().putString("name", q).apply()
            greeting.text = greetingText()
        }
    }

    private fun resetSettings() {
        prefs.edit().remove("cols").remove("bg").apply()
        applyBg()
        rebuildRows(lastPkg)
    }

    // ---------- Hava durumu (Open-Meteo, anahtar gerekmez) ----------

    private fun saveCity(name: String, lat: String, lon: String) {
        prefs.edit().putString("city", name).putString("lat", lat).putString("lon", lon)
            .remove("wx").apply()
        updateWeatherText()
        lastWeather = System.currentTimeMillis()
        fetchWeather()
    }

    private fun showCityPanel(parent: (() -> Unit)?) {
        val items = cities.map { PItem(it.name) } + PItem("Başka şehir ara…", arrow = true)
        val cur = cities.indexOfFirst { it.name == prefs.getString("city", "") }
        showPanel("Hava durumu konumu", items, cur, parent, false) { i ->
            if (i < cities.size) {
                saveCity(cities[i].name, cities[i].lat, cities[i].lon)
            } else {
                showCitySearch(parent)
            }
        }
    }

    private fun showCitySearch(parent: (() -> Unit)?) {
        showInput("Şehir ara", "Şehir adını yaz, sonra Enter", "", parent) { q ->
            if (q.isNotEmpty()) searchCity(q, parent) else showCitySearch(parent)
        }
    }

    private fun searchCity(q: String, parent: (() -> Unit)?) {
        Thread {
            var found: List<City> = emptyList()
            var labels: List<String> = emptyList()
            try {
                val url = "https://geocoding-api.open-meteo.com/v1/search?name=" +
                    URLEncoder.encode(q, "UTF-8") + "&count=6&language=tr&format=json"
                val conn = URL(url).openConnection() as HttpURLConnection
                conn.connectTimeout = 8000
                conn.readTimeout = 8000
                val txt = conn.inputStream.bufferedReader().use { it.readText() }
                val arr = JSONObject(txt).optJSONArray("results")
                if (arr != null) {
                    val cs = mutableListOf<City>()
                    val ls = mutableListOf<String>()
                    for (k in 0 until arr.length()) {
                        val o = arr.getJSONObject(k)
                        val name = o.optString("name")
                        val admin = o.optString("admin1")
                        val country = o.optString("country")
                        cs.add(City(name, o.getDouble("latitude").toString(), o.getDouble("longitude").toString()))
                        ls.add(listOf(name, admin, country).filter { it.isNotEmpty() }.joinToString(", "))
                    }
                    found = cs
                    labels = ls
                }
            } catch (_: Exception) {}
            handler.post {
                if (found.isEmpty()) {
                    Toast.makeText(this, "Şehir bulunamadı ya da internet yok", Toast.LENGTH_LONG).show()
                    showCitySearch(parent)
                } else {
                    showPanel("Sonuçlar", labels.map { PItem(it) }, -1, { showCitySearch(parent) }, false) { i ->
                        saveCity(found[i].name, found[i].lat, found[i].lon)
                    }
                }
            }
        }.start()
    }

    private fun wxText(code: Int): String = when (code) {
        0 -> "Açık"
        1 -> "Çoğunlukla açık"
        2 -> "Parçalı bulutlu"
        3 -> "Kapalı"
        45, 48 -> "Sisli"
        51, 53, 55, 56, 57 -> "Çiseleme"
        61, 63, 65, 66, 67 -> "Yağmurlu"
        71, 73, 75, 77 -> "Karlı"
        80, 81, 82 -> "Sağanak"
        85, 86 -> "Kar sağanağı"
        95, 96, 99 -> "Fırtına"
        else -> ""
    }

    private fun wxKind(code: Int): Int {
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val night = h < 6 || h >= 20
        return when (code) {
            0, 1 -> if (night) WxIconView.MOON else WxIconView.SUN
            2 -> WxIconView.PARTLY
            3 -> WxIconView.CLOUD
            45, 48 -> WxIconView.FOG
            51, 53, 55, 56, 57, 61, 63, 65, 66, 67, 80, 81, 82 -> WxIconView.RAIN
            71, 73, 75, 77, 85, 86 -> WxIconView.SNOW
            95, 96, 99 -> WxIconView.STORM
            else -> WxIconView.CLOUD
        }
    }

    private fun fetchWeather() {
        val lat = prefs.getString("lat", null) ?: return
        val lon = prefs.getString("lon", null) ?: return
        Thread {
            try {
                val url = "https://api.open-meteo.com/v1/forecast?latitude=" + lat +
                    "&longitude=" + lon + "&current=temperature_2m,weather_code&timezone=auto"
                val conn = URL(url).openConnection() as HttpURLConnection
                conn.connectTimeout = 8000
                conn.readTimeout = 8000
                val txt = conn.inputStream.bufferedReader().use { it.readText() }
                val cur = JSONObject(txt).getJSONObject("current")
                val temp = Math.round(cur.getDouble("temperature_2m")).toInt()
                val code = cur.getInt("weather_code")
                prefs.edit().putString("wx", temp.toString() + "°|" + wxText(code) + "|" + code).apply()
                handler.post { updateWeatherText() }
            } catch (_: Exception) {}
        }.start()
    }

    private fun updateWeatherText() {
        val city = prefs.getString("city", null)
        if (city == null) {
            wxIcon.visibility = View.GONE
            weatherText.text = "Hava durumu için konum seç"
            return
        }
        val wx = prefs.getString("wx", null)
        if (wx == null) {
            wxIcon.visibility = View.GONE
            weatherText.text = city
        } else {
            val p = wx.split("|")
            val code = if (p.size > 2) (p[2].toIntOrNull() ?: 3) else 3
            wxIcon.setKind(wxKind(code))
            wxIcon.visibility = View.VISIBLE
            weatherText.text = city + " · " + p[0] + " " + (if (p.size > 1) p[1] else "")
        }
    }

    // ---------- Ayarlar, Wi-Fi ----------

    private fun openSettings(action: String) {
        try {
            startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            try {
                startActivity(
                    Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            } catch (_: Exception) {}
        }
    }

    @Suppress("DEPRECATION")
    private fun updateWifi() {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val ok = cm.activeNetworkInfo?.isConnected == true
        wifiIcon.setColorFilter(
            if (ok) Color.WHITE else Color.parseColor("#7A8594"),
            PorterDuff.Mode.SRC_IN
        )
    }

    private fun iconButton(icon: View, action: () -> Unit): View {
        val bg = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.TRANSPARENT)
        }
        val f = FrameLayout(this).apply {
            background = bg
            isFocusable = true
            addView(icon, FrameLayout.LayoutParams(matchP, matchP))
        }
        f.setOnFocusChangeListener { v, has ->
            if (has) {
                bg.setColor(Color.argb(80, 255, 255, 255))
                v.animate().scaleX(1.15f).scaleY(1.15f).setDuration(120).start()
            } else {
                bg.setColor(Color.TRANSPARENT)
                v.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
            }
        }
        f.setOnClickListener { action() }
        f.layoutParams = LinearLayout.LayoutParams(dp(44), dp(44)).apply {
            setMargins(dp(4), 0, dp(4), 0)
        }
        return f
    }

    // ---------- Kutular ----------

    // Satırın sonunda sağ, başında sol tuş başka yere atlamasın
    private fun stopEdges(v: View) {
        v.setOnKeyListener { view, keyCode, event ->
            var consume = false
            if (event.action == KeyEvent.ACTION_DOWN) {
                val p = view.parent as? ViewGroup
                if (p != null) {
                    if (keyCode == KeyEvent.KEYCODE_DPAD_RIGHT &&
                        p.indexOfChild(view) == p.childCount - 1
                    ) consume = true
                    if (keyCode == KeyEvent.KEYCODE_DPAD_LEFT && p.indexOfChild(view) == 0) {
                        consume = true
                    }
                }
            }
            consume
        }
    }

    private fun tile(app: AppItem): View {
        val bg = GradientDrawable().apply {
            cornerRadius = dp(16).toFloat()
            setColor(Color.parseColor("#2B2B40"))
        }
        val frame = FrameLayout(this).apply {
            background = bg
            isFocusable = true
            clipToOutline = true
            elevation = dp(3).toFloat()
            alpha = 0.9f
            tag = app.pkg
        }
        val img = ImageView(this).apply {
            setImageDrawable(app.image)
            if (app.isBanner) {
                scaleType = ImageView.ScaleType.CENTER_CROP
            } else {
                scaleType = ImageView.ScaleType.FIT_CENTER
                setPadding(dp(tileW / 7), dp(tileH / 6), dp(tileW / 7), dp(tileH / 6))
            }
        }
        frame.addView(img, FrameLayout.LayoutParams(matchP, matchP))

        frame.setOnFocusChangeListener { v, hasFocus ->
            if (hasFocus) {
                lastPkg = app.pkg
                v.animate().scaleX(focusScale).scaleY(focusScale).alpha(1f)
                    .translationZ(dp(18).toFloat()).setDuration(140).start()
                val moving = movingPkg == app.pkg
                bg.setStroke(dp(3), if (moving) Color.parseColor("#FF9F0A") else Color.WHITE)
                label.text = app.label
                subLabel.text = if (moving) {
                    "← → ↑ ↓ ile taşı   ·   Tamam ile bitir"
                } else {
                    hintApp
                }
            } else {
                v.animate().scaleX(1f).scaleY(1f).alpha(0.9f).translationZ(0f).setDuration(140).start()
                bg.setStroke(0, Color.TRANSPARENT)
            }
        }
        frame.setOnClickListener {
            val i = Intent(Intent.ACTION_MAIN)
                .setClassName(app.pkg, app.cls)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            try { startActivity(i) } catch (_: Exception) {}
        }
        frame.setOnLongClickListener {
            showMenu(app)
            true
        }
        stopEdges(frame)

        frame.layoutParams = LinearLayout.LayoutParams(dp(tileW), dp(tileH)).apply {
            setMargins(0, 0, dp(tileGap), 0)
        }
        return frame
    }

    // Gizlenen uygulama varsa ızgaranın sonunda çıkan kutu
    private fun hiddenTile(): View {
        val bg = glass(16, 90)
        val frame = FrameLayout(this).apply {
            background = bg
            isFocusable = true
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
        }
        val g = GlyphView(this, GlyphView.EYE_OFF)
        box.addView(g, LinearLayout.LayoutParams(dp(26), dp(26)))
        box.addView(TextView(this).apply {
            text = "Gizlenenler (" + hiddenApps.size + ")"
            textSize = 12.5f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        })
        frame.addView(box, FrameLayout.LayoutParams(matchP, matchP))
        frame.setOnFocusChangeListener { v, hasFocus ->
            if (hasFocus) {
                v.animate().scaleX(focusScale).scaleY(focusScale).setDuration(140).start()
                bg.setStroke(dp(3), Color.WHITE)
                label.text = "Gizlenen uygulamalar"
                subLabel.text = "Gizlediğin uygulamaları geri getir"
            } else {
                v.animate().scaleX(1f).scaleY(1f).setDuration(140).start()
                bg.setStroke(dp(1), Color.argb(55, 255, 255, 255))
            }
        }
        frame.setOnClickListener { showHidden() }
        stopEdges(frame)
        frame.layoutParams = LinearLayout.LayoutParams(dp(tileW), dp(tileH)).apply {
            setMargins(0, 0, dp(tileGap), 0)
        }
        return frame
    }
}

// Resim dosyası gerektirmeyen küçük çizim simgeleri (menü ve butonlar için)
class GlyphView(context: Context, private val kind: Int) : View(context) {

    companion object {
        const val GRID = 0
        const val PALETTE = 1
        const val CLOUD = 2
        const val RESET = 3
        const val MOVE = 4
        const val EYE_OFF = 5
        const val TRASH = 6
        const val INFO = 7
        const val CHECK = 8
        const val CHEVRON = 9
        const val SLIDERS = 10
        const val USER = 11
    }

    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }

    fun setTint(c: Int) {
        p.color = c
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val cx = w / 2f
        val cy = height / 2f
        p.strokeWidth = w * 0.085f
        p.style = Paint.Style.STROKE
        when (kind) {
            GRID -> {
                p.style = Paint.Style.FILL
                val s = w * 0.2f
                val g = w * 0.07f
                for (i in 0..1) {
                    for (j in 0..1) {
                        val l = cx - g / 2 - s + i * (s + g)
                        val t = cy - g / 2 - s + j * (s + g)
                        canvas.drawRoundRect(RectF(l, t, l + s, t + s), w * 0.04f, w * 0.04f, p)
                    }
                }
            }
            PALETTE -> {
                canvas.drawCircle(cx, cy, w * 0.29f, p)
                p.style = Paint.Style.FILL
                canvas.drawCircle(cx - w * 0.10f, cy - w * 0.07f, w * 0.045f, p)
                canvas.drawCircle(cx + w * 0.07f, cy - w * 0.12f, w * 0.045f, p)
                canvas.drawCircle(cx + w * 0.14f, cy + w * 0.05f, w * 0.045f, p)
                canvas.drawCircle(cx - w * 0.04f, cy + w * 0.10f, w * 0.045f, p)
            }
            CLOUD -> {
                p.style = Paint.Style.FILL
                canvas.drawCircle(cx - w * 0.13f, cy + w * 0.04f, w * 0.13f, p)
                canvas.drawCircle(cx + w * 0.02f, cy - w * 0.05f, w * 0.17f, p)
                canvas.drawCircle(cx + w * 0.16f, cy + w * 0.05f, w * 0.12f, p)
                canvas.drawRoundRect(
                    RectF(cx - w * 0.24f, cy + w * 0.04f, cx + w * 0.27f, cy + w * 0.17f),
                    w * 0.06f, w * 0.06f, p
                )
            }
            RESET -> {
                val r = w * 0.26f
                canvas.drawArc(RectF(cx - r, cy - r, cx + r, cy + r), -40f, 270f, false, p)
                val ang = Math.toRadians(230.0)
                val px = cx + (r * Math.cos(ang)).toFloat()
                val py = cy + (r * Math.sin(ang)).toFloat()
                val tx = (-Math.sin(ang)).toFloat()
                val ty = Math.cos(ang).toFloat()
                val nx = Math.cos(ang).toFloat()
                val ny = Math.sin(ang).toFloat()
                val path = Path()
                path.moveTo(px + tx * w * 0.13f, py + ty * w * 0.13f)
                path.lineTo(px + nx * w * 0.10f, py + ny * w * 0.10f)
                path.lineTo(px - nx * w * 0.10f, py - ny * w * 0.10f)
                path.close()
                p.style = Paint.Style.FILL
                canvas.drawPath(path, p)
            }
            MOVE -> {
                val a = w * 0.28f
                val h = w * 0.12f
                canvas.drawLine(cx - a, cy, cx + a, cy, p)
                canvas.drawLine(cx - a, cy, cx - a + h, cy - h, p)
                canvas.drawLine(cx - a, cy, cx - a + h, cy + h, p)
                canvas.drawLine(cx + a, cy, cx + a - h, cy - h, p)
                canvas.drawLine(cx + a, cy, cx + a - h, cy + h, p)
            }
            EYE_OFF -> {
                canvas.drawOval(RectF(cx - w * 0.3f, cy - w * 0.17f, cx + w * 0.3f, cy + w * 0.17f), p)
                p.style = Paint.Style.FILL
                canvas.drawCircle(cx, cy, w * 0.07f, p)
                p.style = Paint.Style.STROKE
                canvas.drawLine(cx - w * 0.27f, cy + w * 0.27f, cx + w * 0.27f, cy - w * 0.27f, p)
            }
            TRASH -> {
                canvas.drawLine(cx - w * 0.25f, cy - w * 0.16f, cx + w * 0.25f, cy - w * 0.16f, p)
                canvas.drawLine(cx - w * 0.08f, cy - w * 0.25f, cx + w * 0.08f, cy - w * 0.25f, p)
                canvas.drawRoundRect(
                    RectF(cx - w * 0.18f, cy - w * 0.16f, cx + w * 0.18f, cy + w * 0.28f),
                    w * 0.05f, w * 0.05f, p
                )
                canvas.drawLine(cx - w * 0.05f, cy - w * 0.06f, cx - w * 0.05f, cy + w * 0.18f, p)
                canvas.drawLine(cx + w * 0.05f, cy - w * 0.06f, cx + w * 0.05f, cy + w * 0.18f, p)
            }
            INFO -> {
                canvas.drawCircle(cx, cy, w * 0.3f, p)
                p.style = Paint.Style.FILL
                canvas.drawCircle(cx, cy - w * 0.11f, w * 0.04f, p)
                p.style = Paint.Style.STROKE
                canvas.drawLine(cx, cy - w * 0.03f, cx, cy + w * 0.15f, p)
            }
            CHECK -> {
                val path = Path()
                path.moveTo(cx - w * 0.2f, cy + w * 0.0f)
                path.lineTo(cx - w * 0.05f, cy + w * 0.15f)
                path.lineTo(cx + w * 0.22f, cy - w * 0.14f)
                canvas.drawPath(path, p)
            }
            CHEVRON -> {
                val path = Path()
                path.moveTo(cx - w * 0.08f, cy - w * 0.2f)
                path.lineTo(cx + w * 0.1f, cy)
                path.lineTo(cx - w * 0.08f, cy + w * 0.2f)
                canvas.drawPath(path, p)
            }
            SLIDERS -> {
                canvas.drawLine(cx - w * 0.3f, cy - w * 0.14f, cx + w * 0.3f, cy - w * 0.14f, p)
                canvas.drawLine(cx - w * 0.3f, cy + w * 0.14f, cx + w * 0.3f, cy + w * 0.14f, p)
                p.style = Paint.Style.FILL
                canvas.drawCircle(cx - w * 0.1f, cy - w * 0.14f, w * 0.085f, p)
                canvas.drawCircle(cx + w * 0.12f, cy + w * 0.14f, w * 0.085f, p)
            }
            USER -> {
                p.style = Paint.Style.FILL
                canvas.drawCircle(cx, cy - w * 0.1f, w * 0.11f, p)
                p.style = Paint.Style.STROKE
                canvas.drawArc(
                    RectF(cx - w * 0.22f, cy + w * 0.04f, cx + w * 0.22f, cy + w * 0.46f),
                    180f, 180f, false, p
                )
            }
            else -> {}
        }
    }
}

// Hava durumu simgeleri (kodla çizilir)
class WxIconView(context: Context, private var kind: Int) : View(context) {

    companion object {
        const val SUN = 0
        const val MOON = 1
        const val PARTLY = 2
        const val CLOUD = 3
        const val RAIN = 4
        const val SNOW = 5
        const val STORM = 6
        const val FOG = 7
    }

    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }

    fun setKind(k: Int) {
        kind = k
        invalidate()
    }

    private fun cloud(c: Canvas, cx: Float, cy: Float, s: Float, color: Int) {
        p.style = Paint.Style.FILL
        p.color = color
        c.drawCircle(cx - 0.22f * s, cy + 0.06f * s, 0.2f * s, p)
        c.drawCircle(cx + 0.02f * s, cy - 0.06f * s, 0.26f * s, p)
        c.drawCircle(cx + 0.26f * s, cy + 0.07f * s, 0.18f * s, p)
        c.drawRoundRect(
            RectF(cx - 0.42f * s, cy + 0.06f * s, cx + 0.44f * s, cy + 0.26f * s),
            0.1f * s, 0.1f * s, p
        )
    }

    private fun sun(c: Canvas, cx: Float, cy: Float, r: Float) {
        p.color = Color.parseColor("#FFD27A")
        p.style = Paint.Style.FILL
        c.drawCircle(cx, cy, r, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = r * 0.35f
        for (i in 0 until 8) {
            val a = Math.toRadians(i * 45.0)
            val cs = Math.cos(a).toFloat()
            val sn = Math.sin(a).toFloat()
            c.drawLine(cx + cs * r * 1.5f, cy + sn * r * 1.5f, cx + cs * r * 1.95f, cy + sn * r * 1.95f, p)
        }
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val cx = w / 2f
        val cy = height / 2f
        val white = Color.parseColor("#E8EBF2")
        when (kind) {
            SUN -> sun(canvas, cx, cy, w * 0.2f)
            MOON -> {
                val a = Path()
                a.addCircle(cx, cy, w * 0.3f, Path.Direction.CW)
                val b = Path()
                b.addCircle(cx + w * 0.15f, cy - w * 0.1f, w * 0.26f, Path.Direction.CW)
                a.op(b, Path.Op.DIFFERENCE)
                p.style = Paint.Style.FILL
                p.color = white
                canvas.drawPath(a, p)
            }
            PARTLY -> {
                sun(canvas, cx + w * 0.16f, cy - w * 0.16f, w * 0.12f)
                cloud(canvas, cx - w * 0.04f, cy + w * 0.08f, w * 0.85f, white)
            }
            CLOUD -> cloud(canvas, cx, cy, w * 0.95f, white)
            RAIN -> {
                cloud(canvas, cx, cy - w * 0.12f, w * 0.9f, white)
                p.style = Paint.Style.STROKE
                p.color = Color.parseColor("#8FC1FF")
                p.strokeWidth = w * 0.07f
                for (i in 0..2) {
                    val x = cx - w * 0.2f + i * w * 0.2f
                    canvas.drawLine(x, cy + w * 0.22f, x - w * 0.05f, cy + w * 0.36f, p)
                }
            }
            SNOW -> {
                cloud(canvas, cx, cy - w * 0.12f, w * 0.9f, white)
                p.style = Paint.Style.FILL
                p.color = Color.WHITE
                for (i in 0..2) {
                    canvas.drawCircle(cx - w * 0.2f + i * w * 0.2f, cy + w * 0.3f, w * 0.045f, p)
                }
            }
            STORM -> {
                cloud(canvas, cx, cy - w * 0.14f, w * 0.9f, Color.parseColor("#B4BCC9"))
                val b = Path()
                b.moveTo(cx + w * 0.06f, cy + w * 0.1f)
                b.lineTo(cx - w * 0.08f, cy + w * 0.3f)
                b.lineTo(cx + w * 0.0f, cy + w * 0.3f)
                b.lineTo(cx - w * 0.06f, cy + w * 0.46f)
                b.lineTo(cx + w * 0.14f, cy + w * 0.2f)
                b.lineTo(cx + w * 0.05f, cy + w * 0.2f)
                b.close()
                p.style = Paint.Style.FILL
                p.color = Color.parseColor("#FFD27A")
                canvas.drawPath(b, p)
            }
            FOG -> {
                p.style = Paint.Style.STROKE
                p.color = Color.parseColor("#C5CAD6")
                p.strokeWidth = w * 0.08f
                canvas.drawLine(cx - w * 0.3f, cy - w * 0.16f, cx + w * 0.3f, cy - w * 0.16f, p)
                canvas.drawLine(cx - w * 0.22f, cy, cx + w * 0.34f, cy, p)
                canvas.drawLine(cx - w * 0.3f, cy + w * 0.16f, cx + w * 0.22f, cy + w * 0.16f, p)
            }
            else -> {}
        }
    }
}
