package com.github.pilauncher

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.InputStream
import java.io.OutputStream
import java.math.BigInteger
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.security.KeyFactory
import java.security.KeyPairGenerator
import java.security.MessageDigest
import java.security.PrivateKey
import java.security.SecureRandom
import java.security.Signature
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate
import java.security.interfaces.RSAPublicKey
import java.security.spec.PKCS8EncodedKeySpec
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLSocket
import javax.net.ssl.X509TrustManager

// ---------- Telefon İle Yönet (DENEME) ----------
// Telefon, TV'deki QR kodu okutunca açılan sayfadan TV'yi kumanda eder. Tuşlar iki yoldan gönderilebilir:
// 1) Google'ın TV'deki kumanda servisi (Android TV Remote v2; telefon kumanda uygulamalarının kullandığı servis): bir kez
//    eşleştirme kodu ister, sonra bütün tuşları (kanal tuşları dahil) gönderir. PiLauncher ona TV'nin içinden bağlanır.
// 2) Erişilebilirlik servisi (PiAccess): yön/OK/Geri/Home; kanal tuşları yoktur.
// Oturum: her QR yeni bir anahtar üretir; TV kapanana (ekran kapanana) ya da yeni QR açılana kadar geçerlidir.

/** Erişilebilirlik servisi: yalnızca sistemin hazır "genel eylem"lerini (yön tuşları, Geri, Home) tetikler; ekran içeriğini okumaz. */
class PiAccess : android.accessibilityservice.AccessibilityService() {
    companion object { @Volatile var inst: PiAccess? = null }
    override fun onServiceConnected() { inst = this }
    override fun onUnbind(intent: Intent?): Boolean { inst = null; return super.onUnbind(intent) }
    override fun onDestroy() { inst = null; super.onDestroy() }
    override fun onAccessibilityEvent(event: android.view.accessibility.AccessibilityEvent?) {}
    override fun onInterrupt() {}
}

/** Kumanda servisine bağlanırken kullanılan kimlik: RSA anahtarı ve kendinden imzalı sertifika (bir kez üretilir, TV'de saklanır). */
object RemoteCert {
    private fun der(tag: Int, c: ByteArray): ByteArray { val o = ByteArrayOutputStream(); o.write(tag)
        if (c.size < 128) o.write(c.size) else if (c.size < 256) { o.write(0x81); o.write(c.size) } else { o.write(0x82); o.write(c.size shr 8); o.write(c.size and 255) }
        o.write(c); return o.toByteArray() }
    private fun cat(vararg p: ByteArray): ByteArray { val o = ByteArrayOutputStream(); p.forEach { o.write(it) }; return o.toByteArray() }
    private fun hex(s: String) = ByteArray(s.length / 2) { s.substring(it * 2, it * 2 + 2).toInt(16).toByte() }
    /** Dönen: (PKCS#8 özel anahtar, DER sertifika) */
    // plain = true: uzantısız sertifika (yalnız sınama için; kumanda servisi bunu kabul etmiyor)
    fun generate(plain: Boolean = false): Pair<ByteArray, ByteArray> {
        val kp = KeyPairGenerator.getInstance("RSA").apply { initialize(2048) }.generateKeyPair()
        val alg = der(0x30, cat(der(0x06, hex("2A864886F70D01010B")), der(0x05, ByteArray(0))))          // sha256WithRSAEncryption
        val name = der(0x30, der(0x31, der(0x30, cat(der(0x06, hex("550403")), der(0x0C, "atvremote".toByteArray())))))
        val tf = java.text.SimpleDateFormat("yyMMddHHmmss'Z'", java.util.Locale.US).apply { timeZone = java.util.TimeZone.getTimeZone("UTC") }
        val now = System.currentTimeMillis()
        val validity = der(0x30, cat(der(0x17, tf.format(java.util.Date(now - 86_400_000L)).toByteArray()), der(0x17, tf.format(java.util.Date(now + 3650L * 86_400_000L)).toByteArray())))
        // Uzantılar, çalıştığı bilinen kumanda istemcilerindekiyle aynı: temel kısıtlar (CA, yol uzunluğu 0) ve alternatif ad.
        // (Uzantısız sertifikayla eşleştirme kabul ediliyor ama kumanda bağlantısı el sıkışmada kapatılıyordu; sebebi doğrulanamadı.)
        val bc = der(0x30, cat(der(0x06, hex("551D13")), der(0x04, der(0x30, cat(der(0x01, byteArrayOf(-1)), der(0x02, byteArrayOf(0)))))))
        val san = der(0x30, cat(der(0x06, hex("551D11")), der(0x04, der(0x30, der(0x82, "atvremote".toByteArray())))))
        val ext = if (plain) ByteArray(0) else der(0xA3, der(0x30, cat(bc, san)))
        val serial = der(0x02, BigInteger(63, SecureRandom()).add(BigInteger.ONE).toByteArray())
        val tbs = der(0x30, cat(der(0xA0, der(0x02, byteArrayOf(2))), serial, alg, name, validity, name, kp.public.encoded, ext))
        val sig = Signature.getInstance("SHA256withRSA").apply { initSign(kp.private); update(tbs) }.sign()
        return Pair(kp.private.encoded, der(0x30, cat(tbs, alg, der(0x03, cat(byteArrayOf(0), sig)))))
    }
    fun context(key: ByteArray, cert: ByteArray): Pair<SSLContext, X509Certificate> {
        val pk: PrivateKey = KeyFactory.getInstance("RSA").generatePrivate(PKCS8EncodedKeySpec(key))
        val c = CertificateFactory.getInstance("X.509").generateCertificate(cert.inputStream()) as X509Certificate
        // Kimlik her zaman gönderilir. Hazır anahtar yöneticisi, sunucunun "kabul ettiğim imzacılar" listesine uymayan
        // sertifikayı hiç göndermiyor; kumanda servisi (6466) böyle bir liste yolladığı için eşleşmiş olsak da bağlantı reddediliyordu.
        val km = object : javax.net.ssl.X509ExtendedKeyManager() {
            override fun chooseClientAlias(keyType: Array<out String>?, issuers: Array<out java.security.Principal>?, socket: Socket?): String = "k"
            override fun chooseEngineClientAlias(keyType: Array<out String>?, issuers: Array<out java.security.Principal>?, engine: javax.net.ssl.SSLEngine?): String = "k"
            override fun getClientAliases(keyType: String?, issuers: Array<out java.security.Principal>?): Array<String> = arrayOf("k")
            override fun getCertificateChain(alias: String?): Array<X509Certificate> = arrayOf(c)
            override fun getPrivateKey(alias: String?): PrivateKey = pk
            override fun chooseServerAlias(keyType: String?, issuers: Array<out java.security.Principal>?, socket: Socket?): String = "k"
            override fun chooseEngineServerAlias(keyType: String?, issuers: Array<out java.security.Principal>?, engine: javax.net.ssl.SSLEngine?): String = "k"
            override fun getServerAliases(keyType: String?, issuers: Array<out java.security.Principal>?): Array<String> = arrayOf("k") }
        // TV'nin kendi servisi kendinden imzalı sertifika kullanır; bağlantı yalnızca TV'nin kendisine yapılır
        val tm = object : X509TrustManager {
            override fun checkClientTrusted(chain: Array<out X509Certificate>?, authType: String?) {}
            override fun checkServerTrusted(chain: Array<out X509Certificate>?, authType: String?) {}
            override fun getAcceptedIssuers(): Array<X509Certificate> = arrayOf() }
        val ctx = SSLContext.getInstance("TLS"); ctx.init(arrayOf(km), arrayOf(tm), SecureRandom())
        return Pair(ctx, c)
    }
    private fun unsigned(n: BigInteger): ByteArray { var h = n.toString(16); if (h.length % 2 == 1) h = "0$h"; return hex(h) }
    /** Eşleştirme kanıtı: iki tarafın açık anahtarı + TV'de görünen kodun son 4 hanesi. Kodun ilk 2 hanesi sonucu doğrular. */
    fun secret(client: RSAPublicKey, server: RSAPublicKey, code: String): ByteArray? {
        val md = MessageDigest.getInstance("SHA-256")
        md.update(unsigned(client.modulus)); md.update(unsigned(client.publicExponent)); md.update(unsigned(server.modulus)); md.update(unsigned(server.publicExponent))
        md.update(hex(code.substring(2)))
        val h = md.digest()
        return if ((h[0].toInt() and 255) == code.substring(0, 2).toInt(16)) h else null
    }
}

/** Küçük protobuf yazıcı/okuyucu (yalnızca sayı ve bayt alanları) */
class PB {
    val o = ByteArrayOutputStream()
    private fun v(x: Long) { var n = x; while (n and 0x7FL.inv() != 0L) { o.write(((n and 0x7F) or 0x80).toInt()); n = n ushr 7 }; o.write(n.toInt()) }
    fun int(f: Int, x: Int): PB { v((f shl 3).toLong()); v(x.toLong() and 0xFFFFFFFFL); return this }
    fun bytes(f: Int, b: ByteArray): PB { v(((f shl 3) or 2).toLong()); v(b.size.toLong()); o.write(b); return this }
    fun str(f: Int, s: String) = bytes(f, s.toByteArray(Charsets.UTF_8))
    fun msg(f: Int, m: PB) = bytes(f, m.o.toByteArray())
    fun framed(): ByteArray { val b = o.toByteArray(); val p = PB(); p.v(b.size.toLong()); p.o.write(b); return p.o.toByteArray() }
    companion object {
        fun parse(b: ByteArray): Map<Int, Any> { val m = HashMap<Int, Any>(); var i = 0
            fun vr(): Long { var r = 0L; var s = 0; while (true) { val x = b[i++].toInt() and 255; r = r or ((x and 0x7F).toLong() shl s); if (x and 0x80 == 0) return r; s += 7 } }
            try { while (i < b.size) { val t = vr().toInt(); val f = t ushr 3
                when (t and 7) { 0 -> m[f] = vr(); 2 -> { val n = vr().toInt(); m[f] = b.copyOfRange(i, i + n); i += n }; 1 -> i += 8; 5 -> i += 4; else -> return m } } } catch (_: Exception) {}
            return m }
        fun read(i: InputStream): ByteArray? { var len = 0; var s = 0
            while (true) { val x = i.read(); if (x < 0) return null; len = len or ((x and 0x7F) shl s); if (x and 0x80 == 0) break; s += 7; if (s > 28) return null }
            if (len > 1 shl 20) return null
            val b = ByteArray(len); var g = 0; while (g < len) { val n = i.read(b, g, len - g); if (n < 0) return null; g += n }
            return b }
    }
}

object RemoteHub {
    @Volatile var token = ""; private set
    @Volatile var port = 0; private set
    /** Google servisi: off, connecting, need (eşleştirme gerekli), pair (kod isteniyor), code (kod bekleniyor), ok, err */
    @Volatile var gState = "off"; private set
    @Volatile var gMsg = ""; private set
    @Volatile var lastVia = ""; private set
    /** PiLauncher ekranda mı (başka uygulamadayken arka plandan uygulama açma kısıtı için) */
    @Volatile var foreground = false
    @Volatile private var gen = 0
    private var app: Context? = null
    private var server: ServerSocket? = null
    private var pool: java.util.concurrent.ExecutorService? = null
    private var ip = ""
    private var ssl: SSLContext? = null
    private var myCert: X509Certificate? = null
    @Volatile private var rSock: SSLSocket? = null
    private var rOut: OutputStream? = null
    private val wLock = Any()
    @Volatile private var pSock: SSLSocket? = null
    private var pHost = ""
    private var screenRx: BroadcastReceiver? = null
    private val main = Handler(Looper.getMainLooper())
    private fun log(t: String) = android.util.Log.w("PiLauncher", "kumanda: $t")
    val active: Boolean get() = server != null

    /** Yeni oturum (yeni anahtar). Önceki oturum ve bağlantıları kapanır. */
    @Synchronized fun start(ctx: Context, localIp: String): Boolean {
        stop(); app = ctx.applicationContext; ip = localIp
        return try {
            token = ByteArray(16).also { SecureRandom().nextBytes(it) }.joinToString("") { "%02x".format(it) }
            val s = ServerSocket(0); server = s; port = s.localPort; val g = ++gen
            val p = java.util.concurrent.Executors.newFixedThreadPool(4); pool = p
            Thread { while (g == gen) { val c = try { s.accept() } catch (_: Exception) { break }
                try { p.execute { handle(c) } } catch (_: Exception) { try { c.close() } catch (_: Exception) {} } } }.start()
            if (screenRx == null) { val rx = object : BroadcastReceiver() { override fun onReceive(c: Context?, i: Intent?) { stop() } }
                try { app!!.registerReceiver(rx, IntentFilter(Intent.ACTION_SCREEN_OFF)); screenRx = rx } catch (_: Exception) {} }
            Thread { gConnect(g) }.start()
            true
        } catch (e: Exception) { log("sunucu açılamadı " + e.javaClass.simpleName); false }
    }
    @Synchronized fun stop() {
        gen++; token = ""
        try { server?.close() } catch (_: Exception) {}; server = null
        try { pool?.shutdownNow() } catch (_: Exception) {}; pool = null
        try { rSock?.close() } catch (_: Exception) {}; rSock = null
        try { pSock?.close() } catch (_: Exception) {}; pSock = null
        gState = "off"; gMsg = ""
    }

    // ---------- 1. yol: Google kumanda servisi ----------
    private fun sslCtx(): SSLContext {
        ssl?.let { return it }
        val dir = app!!.filesDir; val kf = File(dir, "remote_key2.p8"); val cf = File(dir, "remote_cert2.der")
        try { File(dir, "remote_key.p8").delete(); File(dir, "remote_cert.der").delete() } catch (_: Exception) {}   // ilk denemenin kimliği
        if (!kf.exists() || !cf.exists()) { val (k, c) = RemoteCert.generate(); kf.writeBytes(k); cf.writeBytes(c) }
        val (ctx, cert) = RemoteCert.context(kf.readBytes(), cf.readBytes()); ssl = ctx; myCert = cert; return ctx
    }
    private fun open(host: String, port: Int, proto: String? = null): SSLSocket {
        val raw = Socket(); raw.connect(InetSocketAddress(host, port), 3000)
        val s = sslCtx().socketFactory.createSocket(raw, host, port, true) as SSLSocket
        if (proto != null) s.enabledProtocols = arrayOf(proto)
        s.soTimeout = 6000; s.startHandshake(); return s
    }
    private fun gConnect(g: Int) {
        if (g != gen) return
        gState = "connecting"; gMsg = ""
        var reach: String? = null; var needPair = false; var why = ""
        // Sırayla denenir: TV'nin kendi iç adresi ve ağ adresi; her biri önce olağan şifreleme sürümüyle, sonra TLS 1.2 ile.
        // Her denemenin sonucu telefondaki sayfada görünür (deneme sürümü tanılaması).
        val tries = ArrayList<Pair<String, String?>>()
        for (host in listOf("127.0.0.1", ip).filter { it.isNotEmpty() }.distinct()) { tries.add(Pair(host, null)); tries.add(Pair(host, "TLSv1.2")) }
        for ((host, proto) in tries) {
            if (g != gen) return
            val tag = (if (host == "127.0.0.1") "iç" else "ağ") + (if (proto != null) "/1.2" else "")
            try {
                val s = open(host, 6466, proto); reach = host
                val first = PB.read(s.inputStream)
                if (first == null) { try { s.close() } catch (_: Exception) {}; needPair = true; why += "$tag: kapatıldı · "; continue }
                rSock = s; rOut = s.outputStream; s.soTimeout = 0
                onRemoteMsg(first); gState = "ok"; gMsg = tag; log("Google servisine bağlandı ($tag)")
                try { while (g == gen) { val m = PB.read(s.inputStream) ?: break; onRemoteMsg(m) } } catch (e: Exception) { log("okuma bitti " + e.javaClass.simpleName) }
                try { s.close() } catch (_: Exception) {}
                if (rSock === s) rSock = null
                if (g == gen) { gState = "off"; gMsg = "bağlantı koptu"; Thread.sleep(1500); gConnect(g) }
                return
            } catch (e: java.net.ConnectException) { log("$host:6466 kapalı"); why += "$tag: port kapalı · "
            } catch (e: Exception) { if (e !is java.net.SocketTimeoutException || reach == host) { reach = reach ?: host; needPair = true }
                why += "$tag: " + e.javaClass.simpleName.removeSuffix("Exception") + " " + (e.message ?: "").take(40) + " · "; log("$tag: " + e.javaClass.simpleName + " " + (e.message ?: "")) }
        }
        if (g != gen) return
        // Eşleştirme kodu TV'de tam ekran çıkar ve QR'ı kapatır; bu yüzden eşleştirme ancak telefon bağlandıktan sonra, telefondan başlatılır
        if (needPair && reach != null) { pHost = reach; gMsg = why.removeSuffix(" · "); gState = "need" } else { gState = "err"; gMsg = "servis bulunamadı " + why.removeSuffix(" · ") }
    }
    private fun onRemoteMsg(b: ByteArray) {
        val m = PB.parse(b)
        when {
            m.containsKey(1) -> send(PB().msg(1, PB().int(1, 622).msg(2, PB().int(3, 1).str(4, "1").str(5, "atvremote").str(6, "1.0.0"))))
            m.containsKey(2) -> send(PB().msg(2, PB().int(1, 622)))
            m.containsKey(8) -> { val v = (PB.parse(m[8] as? ByteArray ?: ByteArray(0))[1] as? Long ?: 0L).toInt(); send(PB().msg(9, PB().int(1, v))) }
        }
    }
    private fun send(p: PB): Boolean = synchronized(wLock) {
        val o = rOut ?: return false
        try { o.write(p.framed()); o.flush(); true } catch (e: Exception) { log("gönderilemedi " + e.javaClass.simpleName); try { rSock?.close() } catch (_: Exception) {}; false } }
    private fun outer(field: Int, inner: PB) = PB().int(1, 2).int(2, 200).msg(field, inner)
    private fun pairRead(s: SSLSocket): Map<Int, Any> { val m = PB.parse(PB.read(s.inputStream) ?: throw java.io.IOException("kapandı"))
        if ((m[2] as? Long ?: 0L) != 200L) throw java.io.IOException("durum " + m[2]); return m }
    private fun startPairing(g: Int, host: String) {
        gState = "pair"; gMsg = ""
        try {
            try { pSock?.close() } catch (_: Exception) {}
            val s = open(host, 6467); s.soTimeout = 8000; pSock = s; pHost = host; val o = s.outputStream
            o.write(outer(10, PB().str(1, "atvremote").str(2, "PiLauncher")).framed()); o.flush(); pairRead(s)
            val enc = PB().int(1, 3).int(2, 6)
            o.write(outer(20, PB().msg(1, enc).int(3, 1)).framed()); o.flush(); pairRead(s)
            o.write(outer(30, PB().msg(1, enc).int(2, 1)).framed()); o.flush(); pairRead(s)
            s.soTimeout = 0
            if (g == gen) { gState = "code"; log("eşleştirme kodu TV'de gösteriliyor") }
        } catch (e: Exception) { log("eşleştirme başlatılamadı " + e.javaClass.simpleName + " " + (e.message ?: "")); if (g == gen) { gState = "err"; gMsg = "eşleştirme başlatılamadı" } }
    }
    /** Telefondan girilen kod. Dönen: ok / bad (yanlış kod, TV'de yeni kod çıkar) / err */
    private fun submitCode(codeIn: String): String {
        val g = gen; val s = pSock ?: return "err"
        val code = codeIn.trim().uppercase(); if (!Regex("[0-9A-F]{6}").matches(code)) return "bad"
        return try {
            val srv = s.session.peerCertificates[0].publicKey as RSAPublicKey
            val h = RemoteCert.secret(myCert!!.publicKey as RSAPublicKey, srv, code)
            if (h == null) { Thread { startPairing(g, pHost) }.start(); return "bad" }
            s.soTimeout = 8000; s.outputStream.write(outer(40, PB().bytes(1, h)).framed()); s.outputStream.flush(); pairRead(s)
            try { s.close() } catch (_: Exception) {}; pSock = null
            log("eşleşti"); Thread { gConnect(g) }.start(); "ok"
        } catch (e: Exception) { log("kod kabul edilmedi " + e.javaClass.simpleName); Thread { startPairing(g, pHost) }.start(); "bad" }
    }

    // ---------- Tuşlar ----------
    private val keyCodes = mapOf("up" to 19, "down" to 20, "left" to 21, "right" to 22, "ok" to 23, "back" to 4, "home" to 3,
        "volup" to 24, "voldown" to 25, "mute" to 164, "chup" to 166, "chdown" to 167, "voice" to 84)
    // Erişilebilirlik genel eylemleri (yön tuşları Android 13+)
    private val accActions = mapOf("back" to 1, "home" to 2, "up" to 16, "down" to 17, "left" to 18, "right" to 19, "ok" to 20)
    /** Dönen: hangi yoldan gitti (g = Google servisi, a = erişilebilirlik, s = ses ayarı, none = gönderilemedi) */
    private fun key(name: String): String {
        val code = keyCodes[name] ?: return "none"
        if (gState == "ok" && send(PB().msg(10, PB().int(1, code).int(2, 3)))) return "g"
        val acc = PiAccess.inst; val act = accActions[name]
        if (acc != null && act != null && (act < 16 || Build.VERSION.SDK_INT >= 33)) { main.post { try { acc.performGlobalAction(act) } catch (_: Exception) {} }; return "a" }
        if (name == "volup" || name == "voldown" || name == "mute") { try {
            val am = app!!.getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager
            am.adjustStreamVolume(android.media.AudioManager.STREAM_MUSIC, when (name) { "volup" -> android.media.AudioManager.ADJUST_RAISE; "voldown" -> android.media.AudioManager.ADJUST_LOWER
                else -> if (Build.VERSION.SDK_INT >= 23) android.media.AudioManager.ADJUST_TOGGLE_MUTE else android.media.AudioManager.ADJUST_SAME }, android.media.AudioManager.FLAG_SHOW_UI)
            return "s" } catch (_: Exception) {} }
        return "none"
    }

    // ---------- Uygulamalar (ana ekranın açılış önbelleğinden: liste ve afişler) ----------
    private fun cacheDir() = File(app!!.filesDir, "appcache")
    private fun appList(): List<Array<String>> = try {
        val prefs = app!!.getSharedPreferences("launcher", Context.MODE_PRIVATE)
        val hidden = prefs.getStringSet("hidden", emptySet()) ?: emptySet()
        val order = (prefs.getString("order", "") ?: "").split("|").filter { it.isNotEmpty() }
        File(cacheDir(), "list.txt").readLines().map { it.split("\t") }.filter { it.size >= 4 && it[0] !in hidden }
            .sortedWith(compareBy({ val i = order.indexOf(it[0]); if (i >= 0) i else 100000 }, { it[2].lowercase() })).map { arrayOf(it[0], it[1], it[2], it[3]) }
    } catch (_: Exception) { emptyList() }
    private fun openApp(pkg: String): String {
        val a = appList().firstOrNull { it[0] == pkg } ?: return "none"
        // Başka bir uygulama açıkken Android arka plandan uygulama açtırmaz; o durumda Google servisi üzerinden açılır
        if (!foreground && PiAccess.inst == null && gState == "ok" && send(PB().msg(90, PB().str(1, "market://launch?id=$pkg")))) return "g"
        return try { app!!.startActivity(Intent(Intent.ACTION_MAIN).setClassName(a[0], a[1]).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); "d" } catch (_: Exception) { "none" }
    }

    // ---------- Telefonun bağlandığı küçük web sunucusu (yalnız ev ağı, yalnız geçerli anahtarla) ----------
    private fun readLine(i: InputStream): String? { val sb = StringBuilder()
        while (true) { val b = i.read(); if (b < 0) return if (sb.isEmpty()) null else sb.toString(); if (b == '\n'.code) break; if (b != '\r'.code) sb.append(b.toChar()); if (sb.length > 8192) return null }
        return sb.toString() }
    private fun respond(o: OutputStream, code: Int, type: String, body: ByteArray, cache: Boolean = false) {
        o.write(("HTTP/1.1 $code " + (if (code == 200) "OK" else "Error") + "\r\nContent-Type: $type\r\nContent-Length: ${body.size}\r\nCache-Control: " + (if (cache) "max-age=3600" else "no-store") + "\r\nConnection: close\r\n\r\n").toByteArray())
        o.write(body); o.flush() }
    private fun handle(sock: Socket) { try { sock.use { c ->
        c.soTimeout = 15000
        val a = c.inetAddress; val out = c.getOutputStream()
        if (!(a.isSiteLocalAddress || a.isLinkLocalAddress || a.isLoopbackAddress)) { respond(out, 403, "text/plain", "forbidden".toByteArray()); return }
        val inp = java.io.BufferedInputStream(c.getInputStream())
        val first = readLine(inp) ?: return; val parts = first.split(" "); if (parts.size < 2) return
        while (true) { val h = readLine(inp) ?: return; if (h.isEmpty()) break }
        val path = parts[1].substringBefore("?")
        val q = parts[1].substringAfter("?", "").split("&").mapNotNull { val kv = it.split("=", limit = 2); if (kv.size == 2) kv[0] to (try { java.net.URLDecoder.decode(kv[1], "UTF-8") } catch (_: Exception) { "" }) else null }.toMap()
        val tk = token
        if (tk.isEmpty() || !MessageDigest.isEqual((q["k"] ?: "").toByteArray(), tk.toByteArray())) {
            respond(out, 403, "text/html; charset=utf-8", "<meta name=viewport content='width=device-width'><p style='font:18px sans-serif;padding:24px'>Bu bağlantının süresi doldu. TV'de Ayarlar › Telefon İle Yönet'ten yeni QR kodu okut.</p>".toByteArray()); return }
        when (path) {
            "/" -> respond(out, 200, "text/html; charset=utf-8", PAGE.toByteArray())
            "/state" -> respond(out, 200, "application/json", JSONObject().put("g", gState).put("m", gMsg).put("a", PiAccess.inst != null).put("sdk", Build.VERSION.SDK_INT).put("v", lastVia).toString().toByteArray())
            "/apps" -> { val arr = JSONArray(); for (x in appList()) arr.put(JSONObject().put("p", x[0]).put("n", x[2]).put("b", x[3] == "1")); respond(out, 200, "application/json; charset=utf-8", arr.toString().toByteArray()) }
            "/icon" -> { val p = (q["p"] ?: "").replace(Regex("[^A-Za-z0-9._]"), ""); val f = File(cacheDir(), "$p.png")
                if (p.isNotEmpty() && f.exists()) respond(out, 200, "image/png", f.readBytes(), true) else respond(out, 404, "text/plain", "yok".toByteArray()) }
            "/key" -> { val v = key(q["c"] ?: ""); lastVia = v; respond(out, 200, "text/plain", v.toByteArray()) }
            "/open" -> { val v = openApp(q["p"] ?: ""); respond(out, 200, "text/plain", v.toByteArray()) }
            "/pairstart" -> { val g = gen; if ((gState == "need" || gState == "code" || gState == "err") && pHost.isNotEmpty()) Thread { startPairing(g, pHost) }.start(); respond(out, 200, "text/plain", "ok".toByteArray()) }
            "/pair" -> respond(out, 200, "text/plain", submitCode(q["code"] ?: "").toByteArray())
            else -> respond(out, 404, "text/plain", "not found".toByteArray())
        }
    } } catch (_: Exception) {} }

    private val PAGE = """<!doctype html><html lang="tr"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no,viewport-fit=cover">
<meta name="apple-mobile-web-app-capable" content="yes"><meta name="theme-color" content="#1c1c1e"><title>PiLauncher Kumanda</title>
<style>
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent;-webkit-user-select:none;user-select:none;-webkit-touch-callout:none}
html,body{margin:0;background:#1c1c1e;color:#fff;font:15px -apple-system,system-ui,Roboto,sans-serif;overscroll-behavior:none}
body{padding:14px 18px calc(18px + env(safe-area-inset-bottom));max-width:460px;margin:0 auto}
.top{display:flex;align-items:center;justify-content:center;gap:8px;font-size:19px;font-weight:600;padding:6px 0 12px}
.dot{width:10px;height:10px;border-radius:50%;background:#8e8e93}.dot.on{background:#30d158}.dot.wait{background:#ffd60a}
#pair{display:none;background:#2c2c2e;border-radius:16px;padding:14px;margin-bottom:14px;text-align:center}
#pair p{margin:0 0 10px;color:#d1d1d6;font-size:14px}
#code{width:150px;font:600 24px ui-monospace,monospace;letter-spacing:4px;text-align:center;text-transform:uppercase;background:#1c1c1e;color:#fff;border:1px solid #48484a;border-radius:10px;padding:8px;-webkit-user-select:text;user-select:text}
#pair button{margin-left:8px;font:600 16px inherit;color:#fff;background:#0a84ff;border:0;border-radius:10px;padding:11px 16px}
#apps{display:flex;gap:12px;overflow-x:auto;padding:2px 0 14px;scrollbar-width:none}#apps::-webkit-scrollbar{display:none}
.app{flex:0 0 auto;width:104px;text-align:center;font-size:12px;color:#e5e5ea}
.app div{width:104px;height:59px;border-radius:12px;background:#2c2c2e center/cover no-repeat;margin-bottom:5px;overflow:hidden;display:flex;align-items:center;justify-content:center}
.app img{width:100%;height:100%;object-fit:cover}.app img.ic{object-fit:contain;padding:8px}
.app span{display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.pad{position:relative;width:min(78vw,320px);height:min(78vw,320px);margin:4px auto 18px;border-radius:50%;background:linear-gradient(#333336,#242426);
 border:2px solid transparent;background-clip:padding-box;box-shadow:0 0 0 2px #5e5ce6 inset}
.pad button{position:absolute;background:none;border:0;color:#fff;font-size:34px;width:34%;height:34%;display:flex;align-items:center;justify-content:center;border-radius:50%}
.pad button:active,.b:active,.pill button:active{background:rgba(255,255,255,.14)}
#up{top:0;left:33%}#down{bottom:0;left:33%}#left{left:0;top:33%}#right{right:0;top:33%}
#ok{top:35%;left:35%;width:30%;height:30%;background:#333336;box-shadow:0 0 0 2px #5e5ce6 inset,0 4px 10px rgba(0,0,0,.4)}
.row{display:flex;gap:14px;align-items:stretch;justify-content:center}
.pill{width:70px;border-radius:35px;background:#2f2f31;display:flex;flex-direction:column;justify-content:space-between;align-items:center;overflow:hidden}
.pill button{width:100%;height:74px;background:none;border:0;color:#fff;font-size:30px}
.pill span{font-size:13px;letter-spacing:1px;color:#d1d1d6}
.mid{display:grid;grid-template-columns:70px 70px;gap:14px}
.b{width:70px;height:70px;border-radius:50%;background:#2f2f31;border:0;color:#fff;display:flex;align-items:center;justify-content:center}
svg{width:30px;height:30px;fill:none;stroke:#fff;stroke-width:2;stroke-linecap:round;stroke-linejoin:round;pointer-events:none}
#diag{margin-top:16px;text-align:center;font-size:12px;color:#8e8e93;line-height:1.5}
</style></head><body>
<div class="top"><span id="dot" class="dot"></span><span>PiLauncher Kumanda</span></div>
<div id="need" style="display:none;background:#2c2c2e;border-radius:16px;padding:14px;margin-bottom:14px;text-align:center"><p style="margin:0 0 10px;color:#d1d1d6;font-size:14px">İlk kullanım: TV ile bir kez eşleştir. TV'de bir kod çıkacak.</p><button id="nb" style="font:600 16px inherit;color:#fff;background:#0a84ff;border:0;border-radius:10px;padding:11px 18px">TV ile eşleştir</button></div>
<div id="pair"><p>TV ekranında çıkan 6 haneli kodu yaz</p><input id="code" maxlength="6" autocomplete="off" autocapitalize="characters" spellcheck="false"><button id="pb">Eşleştir</button></div>
<div id="apps"></div>
<div class="pad"><button id="up" data-k="up" data-r="1">&#8963;</button><button id="left" data-k="left" data-r="1">&#8249;</button><button id="ok" data-k="ok"></button><button id="right" data-k="right" data-r="1">&#8250;</button><button id="down" data-k="down" data-r="1">&#8964;</button></div>
<div class="row">
 <div class="pill"><button data-k="volup" data-r="1">+</button><span>SES</span><button data-k="voldown" data-r="1">&minus;</button></div>
 <div class="mid">
  <button class="b" data-k="home"><svg viewBox="0 0 24 24"><path d="M4 11l8-7 8 7v8a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1z"/><path d="M12 16v1"/></svg></button>
  <button class="b" data-k="back"><svg viewBox="0 0 24 24"><path d="M8 5L4 9l4 4"/><path d="M4 9h11a5 5 0 0 1 0 10H9"/></svg></button>
  <button class="b" data-k="voice"><svg viewBox="0 0 24 24"><rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/></svg></button>
  <button class="b" data-k="mute"><svg viewBox="0 0 24 24"><path d="M4 9v6h4l5 4V5L8 9z"/><path d="M17 9l4 6M21 9l-4 6"/></svg></button>
 </div>
 <div class="pill"><button data-k="chup" data-r="1">&#8963;</button><span>KANAL</span><button data-k="chdown" data-r="1">&#8964;</button></div>
</div>
<div id="diag">Bağlanıyor…</div>
<script>
var K=new URLSearchParams(location.search).get('k')||'';
function u(p){return p+(p.indexOf('?')<0?'?':'&')+'k='+K}
function post(p){return fetch(u(p),{method:'POST'}).then(function(r){return r.text()})}
var via={g:'Google kumanda servisi',a:'Erişilebilirlik',s:'Ses ayarı',d:'Doğrudan',none:'GÖNDERİLEMEDİ'},last='',lastKey='',st={};
function send(k){lastKey=k;post('/key?c='+k).then(function(t){last=t;draw()}).catch(function(){last='x';draw()});if(navigator.vibrate)navigator.vibrate(8)}
var names={up:'Yukarı',down:'Aşağı',left:'Sol',right:'Sağ',ok:'OK',back:'Geri',home:'Ana ekran',volup:'Ses +',voldown:'Ses −',mute:'Sessiz',chup:'Kanal +',chdown:'Kanal −',voice:'Sesli arama'};
function draw(){var g=st.g||'',d=document.getElementById('dot');
 d.className='dot'+(g=='ok'||st.a?' on':(g=='code'||g=='pair'||g=='connecting'?' wait':''));
 document.getElementById('pair').style.display=g=='code'?'block':'none';document.getElementById('need').style.display=g=='need'?'block':'none';
 var gs={ok:'bağlı',need:'eşleştirme gerekli ('+(st.m||'')+')',code:'kod bekleniyor',pair:'eşleştirme başlatılıyor',connecting:'bağlanıyor',err:'kullanılamıyor ('+(st.m||'')+')',off:'kapalı '+(st.m||'')}[g]||g;
 var t='Deneme sürümü<br>1. yol · Google kumanda servisi: <b>'+gs+'</b><br>2. yol · Erişilebilirlik izni: <b>'+(st.a?'var':'yok')+'</b>';
 if(lastKey)t+='<br>Son tuş: '+(names[lastKey]||lastKey)+' → <b>'+(last=='x'?'TV\'ye ulaşılamadı':(via[last]||last))+'</b>';
 document.getElementById('diag').innerHTML=t}
function poll(){fetch(u('/state')).then(function(r){return r.json()}).then(function(j){st=j;draw()}).catch(function(){st={g:'off',m:'· TV\'ye ulaşılamıyor'};draw()})}
setInterval(poll,2000);poll();
var tm=null,iv=null;
function stop(){clearTimeout(tm);clearInterval(iv);tm=iv=null}
Array.prototype.forEach.call(document.querySelectorAll('[data-k]'),function(b){
 b.addEventListener('pointerdown',function(e){e.preventDefault();stop();var k=b.getAttribute('data-k');send(k);
  if(b.getAttribute('data-r'))tm=setTimeout(function(){iv=setInterval(function(){send(k)},140)},420)});
 ['pointerup','pointercancel','pointerleave'].forEach(function(n){b.addEventListener(n,stop)});
 b.addEventListener('contextmenu',function(e){e.preventDefault()})});
document.getElementById('nb').onclick=function(){post('/pairstart').then(function(){setTimeout(poll,600)})};
document.getElementById('pb').onclick=function(){var c=document.getElementById('code');post('/pair?code='+encodeURIComponent(c.value)).then(function(t){
 if(t!='ok'){c.value='';alert('Kod kabul edilmedi. TV\'de yeni bir kod çıkacak, onu yaz.')}poll()})};
fetch(u('/apps')).then(function(r){return r.json()}).then(function(l){var h=document.getElementById('apps');
 l.forEach(function(a){var e=document.createElement('div');e.className='app';var bx=document.createElement('div'),im=document.createElement('img');
  im.src=u('/icon?p='+encodeURIComponent(a.p));if(!a.b)im.className='ic';bx.appendChild(im);var s=document.createElement('span');s.textContent=a.n;
  e.appendChild(bx);e.appendChild(s);e.onclick=function(){post('/open?p='+encodeURIComponent(a.p))};h.appendChild(e)})});
</script></body></html>"""
}
