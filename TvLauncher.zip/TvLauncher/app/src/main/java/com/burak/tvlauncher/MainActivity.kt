package com.burak.tvlauncher

import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.PorterDuff
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.ConnectivityManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// Hafif, Apple TV'den esinlenen ana ekran. Tek satır, tüm kutular aynı boyutta.
// Uygulamaya uzun basınca (Tamam tuşuna basılı tut): Taşı / Gizle / Kaldır / Uygulama bilgisi.
// Alttaki "Düzenle": kutu boyutu, arka plan, hava durumu konumu.
class MainActivity : Activity() {

    private data class AppItem(
        val pkg: String,
        val cls: String,
        val label: String,
        val image: Drawable,
        val isBanner: Boolean
    )

    private class City(val name: String, val lat: String, val lon: String)

    // İlk açılışta bu sırayla görünür. Sonra taşıdığın sıra kaydedilir.
    private val pinned = listOf(
        "com.netflix.ninja",
        "com.google.android.youtube.tv",
        "com.amazon.amazonvideo.livingroom",
        "com.disney.disneyplus",
        "com.wbd.stream",
        "com.apple.atve.androidtv.appletv",
        "com.ttnet.tivibutv",
        "com.beonetv.tod"
    )

    private val cities = listOf(
        City("İstanbul", "41.01", "28.98"),
        City("Ankara", "39.93", "32.86"),
        City("İzmir", "38.42", "27.14"),
        City("Bursa", "40.19", "29.06"),
        City("Antalya", "36.90", "30.69"),
        City("Adana", "37.00", "35.32"),
        City("Konya", "37.87", "32.48"),
        City("Gaziantep", "37.07", "37.38"),
        City("Şanlıurfa", "37.16", "38.80"),
        City("Kocaeli", "40.77", "29.94"),
        City("Mersin", "36.80", "34.64"),
        City("Diyarbakır", "37.91", "40.24"),
        City("Hatay", "36.20", "36.16"),
        City("Manisa", "38.61", "27.43"),
        City("Kayseri", "38.72", "35.49"),
        City("Samsun", "41.29", "36.33"),
        City("Balıkesir", "39.65", "27.89"),
        City("Trabzon", "41.00", "39.72"),
        City("Eskişehir", "39.77", "30.52"),
        City("Denizli", "37.78", "29.09")
    )

    // Düzenle menüsünden değiştirilebilir ayarlar
    private val tileGap = 20          // Kutular arası boşluk (dp)
    private val gridPad = 64          // Sağ/sol kenar boşluğu (dp)
    private val rowGap = 18           // Satırlar arası boşluk (dp)

    private val cols: Int get() = prefs.getInt("cols", 5)   // Sütun sayısı

    // Kutu boyutu sütun sayısına göre otomatik hesaplanır (az sütun = büyük kutu)
    private val tileW: Int
        get() {
            val sw = (resources.displayMetrics.widthPixels / resources.displayMetrics.density).toInt()
            return (sw - 2 * gridPad) / cols - tileGap
        }
    private val tileH: Int get() = tileW * 84 / 150

    // Arka plan seçenekleri: yumuşak tonlar (5 renkli dikey degrade)
    private fun c(vararg h: String): IntArray = IntArray(h.size) { Color.parseColor(h[it]) }

    private val bgPresets: List<Pair<String, IntArray?>> = listOf(
        Pair("Klasik (fotoğraf)", null),
        Pair("Gece mavisi", c("#0F1624", "#141D2E", "#55627A", "#2E3E58", "#3C5272")),
        Pair("Orman yeşili", c("#121714", "#19211C", "#66756B", "#34463C", "#455A4C")),
        Pair("Gül kurusu", c("#1A1214", "#211619", "#7A6468", "#4A2E36", "#5C3A44")),
        Pair("Kum", c("#1C1A18", "#23201D", "#8A8379", "#5A5248", "#6E6458")),
        Pair("Mor alacakaranlık", c("#15131C", "#1C1A26", "#70697F", "#433C58", "#544B6B")),
        Pair("Antrasit (düz)", c("#17181C", "#1B1C21", "#202228", "#23252B", "#272A31"))
    )

    private val matchP = ViewGroup.LayoutParams.MATCH_PARENT
    private val wrap = ViewGroup.LayoutParams.WRAP_CONTENT

    private lateinit var prefs: SharedPreferences
    private lateinit var clock: TextView
    private lateinit var date: TextView
    private lateinit var weatherText: TextView
    private lateinit var wifiIcon: ImageView
    private lateinit var label: TextView
    private lateinit var grid: LinearLayout
    private lateinit var gridScroll: ScrollView
    private lateinit var bgView: ImageView
    private val handler = Handler(Looper.getMainLooper())

    private var shown = mutableListOf<AppItem>()
    private var hiddenApps = listOf<AppItem>()
    private var movingPkg: String? = null
    private var lastPkg: String? = null
    private var lastWeather = 0L

    private val tick = object : Runnable {
        override fun run() {
            val now = Date()
            clock.text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(now)
            date.text = SimpleDateFormat("d MMMM, EEEE", Locale("tr", "TR")).format(now)
            updateWifi()
            if (System.currentTimeMillis() - lastWeather > 30 * 60 * 1000L) {
                lastWeather = System.currentTimeMillis()
                fetchWeather()
            }
            handler.postDelayed(this, 15000)
        }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun iconImage(res: Int): ImageView = ImageView(this).apply {
        setImageResource(res)
        setColorFilter(Color.WHITE, PorterDuff.Mode.SRC_IN)
        scaleType = ImageView.ScaleType.FIT_CENTER
        setPadding(dp(10), dp(10), dp(10), dp(10))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("launcher", Context.MODE_PRIVATE)

        val root = FrameLayout(this)
        root.setBackgroundColor(Color.parseColor("#1A1A1A"))
        root.clipChildren = false

        // Arka plan
        bgView = ImageView(this).apply { scaleType = ImageView.ScaleType.FIT_XY }
        root.addView(bgView, FrameLayout.LayoutParams(matchP, matchP))
        applyBg()

        // Saat, tarih, hava durumu (sağ üst)
        val timeBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.END
            clipChildren = false
        }
        clock = TextView(this).apply {
            textSize = 22f
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
            setTextColor(Color.WHITE)
            gravity = Gravity.END
        }
        date = TextView(this).apply {
            textSize = 13f
            setTextColor(Color.parseColor("#D0D0D8"))
            gravity = Gravity.END
        }
        weatherText = TextView(this).apply {
            textSize = 13f
            setTextColor(Color.parseColor("#D0D0D8"))
            gravity = Gravity.END
            setPadding(dp(8), dp(3), dp(8), dp(3))
        }
        val wxBg = GradientDrawable().apply {
            cornerRadius = dp(10).toFloat()
            setColor(Color.TRANSPARENT)
        }
        val weatherBox = FrameLayout(this).apply {
            background = wxBg
            isFocusable = true
            addView(weatherText)
        }
        weatherBox.setOnFocusChangeListener { _, has ->
            wxBg.setColor(if (has) Color.argb(70, 255, 255, 255) else Color.TRANSPARENT)
        }
        weatherBox.setOnClickListener { showCityPanel(null) }
        timeBox.addView(clock)
        timeBox.addView(date)
        timeBox.addView(
            weatherBox,
            LinearLayout.LayoutParams(wrap, wrap).apply { setMargins(0, dp(2), 0, 0) }
        )
        updateWeatherText()

        // Wi-Fi ve ayarlar simgeleri
        wifiIcon = iconImage(R.drawable.ic_wifi)
        val topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.TOP
            clipChildren = false
        }
        topBar.addView(iconButton(wifiIcon) { openSettings(Settings.ACTION_WIFI_SETTINGS) })
        topBar.addView(
            iconButton(iconImage(R.drawable.ic_settings)) { openSettings(Settings.ACTION_SETTINGS) }
        )
        topBar.addView(
            timeBox,
            LinearLayout.LayoutParams(wrap, wrap).apply { setMargins(dp(20), dp(2), 0, 0) }
        )
        root.addView(
            topBar,
            FrameLayout.LayoutParams(wrap, wrap, Gravity.TOP or Gravity.END).apply {
                setMargins(0, dp(24), dp(48), 0)
            }
        )

        // Alt kısım: uygulama adı + tek satır + Düzenle butonu
        val shelf = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            clipChildren = false
            setPadding(0, 0, 0, dp(14))
        }
        label = TextView(this).apply {
            textSize = 28f
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
            setTextColor(Color.WHITE)
            setShadowLayer(10f, 0f, 2f, Color.argb(170, 0, 0, 0))
        }
        shelf.addView(
            label,
            LinearLayout.LayoutParams(wrap, wrap).apply { setMargins(dp(68), 0, 0, 0) }
        )
        grid = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(gridPad), dp(16), dp(gridPad), dp(16))
            clipChildren = false
            clipToPadding = false
        }
        gridScroll = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            clipChildren = false
            clipToPadding = false
            addView(grid)
        }
        shelf.addView(gridScroll, LinearLayout.LayoutParams(matchP, wrap))

        // Düzenle: ortada, koyu saydam hap şeklinde
        val pill = GradientDrawable().apply {
            cornerRadius = dp(40).toFloat()
            setColor(Color.argb(150, 24, 24, 28))
            setStroke(dp(1), Color.argb(50, 255, 255, 255))
        }
        val editBtn = TextView(this).apply {
            text = "Düzenle"
            textSize = 14f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(dp(28), dp(8), dp(28), dp(8))
            background = pill
            isFocusable = true
        }
        editBtn.setOnFocusChangeListener { v, hasFocus ->
            if (hasFocus) {
                v.animate().scaleX(1.1f).scaleY(1.1f).setDuration(120).start()
                pill.setColor(Color.argb(200, 40, 40, 46))
                pill.setStroke(dp(2), Color.WHITE)
                label.text = "Ana ekran ayarları"
            } else {
                v.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
                pill.setColor(Color.argb(150, 24, 24, 28))
                pill.setStroke(dp(1), Color.argb(50, 255, 255, 255))
            }
        }
        editBtn.setOnClickListener { showSettings() }
        shelf.addView(
            editBtn,
            LinearLayout.LayoutParams(wrap, wrap).apply {
                gravity = Gravity.CENTER_HORIZONTAL
                setMargins(0, dp(12), 0, 0)
            }
        )

        root.addView(shelf, FrameLayout.LayoutParams(matchP, wrap, Gravity.BOTTOM))
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        refreshApps(lastPkg)
        handler.post(tick)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(tick)
    }

    // Taşıma modunda yön tuşları kutuyu kaydırır, Tamam/Geri bitirir.
    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        if (movingPkg != null) {
            if (e.action == KeyEvent.ACTION_DOWN) {
                when (e.keyCode) {
                    KeyEvent.KEYCODE_DPAD_LEFT -> moveBy(-1)
                    KeyEvent.KEYCODE_DPAD_RIGHT -> moveBy(1)
                    KeyEvent.KEYCODE_DPAD_UP -> moveBy(-cols)
                    KeyEvent.KEYCODE_DPAD_DOWN -> moveBy(cols)
                    KeyEvent.KEYCODE_DPAD_CENTER,
                    KeyEvent.KEYCODE_ENTER,
                    KeyEvent.KEYCODE_BACK -> endMove()
                    else -> {}
                }
            }
            return true
        }
        return super.dispatchKeyEvent(e)
    }

    // Ana ekranda Geri tuşu bir şey yapmasın.
    @Suppress("OVERRIDE_DEPRECATION")
    override fun onBackPressed() {}

    // ---------- Uygulama listesi, sıra, gizleme ----------

    private fun loadAll(): List<AppItem> {
        val pm = packageManager
        val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER)
        val order = (prefs.getString("order", "") ?: "").split("|").filter { it.isNotEmpty() }
        return pm.queryIntentActivities(query, 0)
            .filter { it.activityInfo.packageName != packageName }
            .map {
                val banner = it.activityInfo.loadBanner(pm)
                AppItem(
                    it.activityInfo.packageName,
                    it.activityInfo.name,
                    it.loadLabel(pm).toString(),
                    banner ?: it.loadIcon(pm),
                    banner != null
                )
            }
            .sortedWith(compareBy({
                val o = order.indexOf(it.pkg)
                if (o >= 0) {
                    o
                } else {
                    val p = pinned.indexOf(it.pkg)
                    10000 + (if (p >= 0) p else 1000)
                }
            }, { it.label.lowercase() }))
    }

    private fun refreshApps(focusPkg: String?) {
        val all = loadAll()
        val hidden = prefs.getStringSet("hidden", emptySet()) ?: emptySet()
        shown = all.filter { !hidden.contains(it.pkg) }.toMutableList()
        hiddenApps = all.filter { hidden.contains(it.pkg) }
        rebuildRows(focusPkg)
    }

    private fun rebuildRows(focusPkg: String?) {
        grid.removeAllViews()
        val n = cols
        val views = mutableListOf<View>()
        for (app in shown) views.add(tile(app))
        if (hiddenApps.isNotEmpty()) views.add(hiddenTile())

        var target: View? = null
        var cur: LinearLayout? = null
        views.forEachIndexed { i, v ->
            if (i % n == 0) {
                val r = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    clipChildren = false
                }
                cur = r
                grid.addView(
                    r,
                    LinearLayout.LayoutParams(wrap, wrap).apply { setMargins(0, 0, 0, dp(rowGap)) }
                )
            }
            cur?.addView(v)
            if (focusPkg != null && v.tag == focusPkg) target = v
        }

        // Ekrana sığan satır kadarını göster, fazlası dikey kayar
        val rows = (views.size + n - 1) / n
        val rowSpace = tileH + rowGap
        val screenH = (resources.displayMetrics.heightPixels / resources.displayMetrics.density).toInt()
        val maxRows = maxOf(1, (screenH - 240 - 32) / rowSpace)
        val lp = gridScroll.layoutParams
        lp.height = dp(minOf(rows, maxRows) * rowSpace + 32)
        gridScroll.layoutParams = lp

        (target ?: views.firstOrNull())?.requestFocus()
    }

    private fun saveOrder() {
        val list = shown.map { it.pkg } + hiddenApps.map { it.pkg }
        prefs.edit().putString("order", list.joinToString("|")).apply()
    }

    private fun startMove(app: AppItem) {
        movingPkg = app.pkg
        rebuildRows(app.pkg)
    }

    private fun moveBy(d: Int) {
        val mp = movingPkg ?: return
        val i = shown.indexOfFirst { it.pkg == mp }
        val j = i + d
        if (i < 0 || j < 0 || j >= shown.size) return
        val tmp = shown[i]
        shown[i] = shown[j]
        shown[j] = tmp
        saveOrder()
        rebuildRows(mp)
    }

    private fun endMove() {
        val mp = movingPkg
        movingPkg = null
        rebuildRows(mp)
    }

    private fun hide(app: AppItem) {
        val h = (prefs.getStringSet("hidden", emptySet()) ?: emptySet()).toMutableSet()
        h.add(app.pkg)
        prefs.edit().putStringSet("hidden", h).apply()
        refreshApps(null)
    }

    private fun unhide(app: AppItem) {
        val h = (prefs.getStringSet("hidden", emptySet()) ?: emptySet()).toMutableSet()
        h.remove(app.pkg)
        prefs.edit().putStringSet("hidden", h).apply()
        refreshApps(app.pkg)
    }

    private fun uninstall(app: AppItem) {
        try {
            startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:" + app.pkg)))
        } catch (_: Exception) {}
    }

    private fun appInfo(app: AppItem) {
        try {
            startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + app.pkg))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (_: Exception) {}
    }

    // ---------- Koyu saydam paneller (tüm menüler bu formda) ----------

    private fun panelBox(): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(10))
            background = GradientDrawable().apply {
                cornerRadius = dp(18).toFloat()
                setColor(Color.argb(228, 28, 28, 32))
                setStroke(dp(1), Color.argb(45, 255, 255, 255))
            }
        }
    }

    private fun styleWindow(dlg: Dialog, widthDp: Int) {
        val w = dlg.window ?: return
        w.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        w.setLayout(dp(widthDp), ViewGroup.LayoutParams.WRAP_CONTENT)
        w.setGravity(Gravity.TOP or Gravity.CENTER_HORIZONTAL)
        w.setDimAmount(0.12f)
        val lp = w.attributes
        lp.y = dp(40)
        w.attributes = lp
    }

    private fun smallText(text: String, size: Float): TextView = TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(Color.parseColor("#A0A0AC"))
    }

    // parent: Geri tuşuna basınca dönülecek menü (null ise tamamen kapanır)
    // stayOpen: seçince panel kapanmasın (boyut, arka plan gibi canlı önizleme için)
    private fun showPanel(
        title: String,
        items: List<String>,
        checked: Int,
        parent: (() -> Unit)?,
        stayOpen: Boolean,
        onPick: (Int) -> Unit
    ) {
        val dlg = Dialog(this)
        dlg.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val box = panelBox()
        val titleView = smallText(title, 13f)
        titleView.setPadding(dp(8), 0, dp(8), dp(8))
        box.addView(titleView)

        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val checks = mutableListOf<TextView>()
        var focusTarget: View? = null
        items.forEachIndexed { i, item ->
            val rowBg = GradientDrawable().apply {
                cornerRadius = dp(10).toFloat()
                setColor(Color.TRANSPARENT)
            }
            val r = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                isFocusable = true
                background = rowBg
                setPadding(dp(10), dp(9), dp(10), dp(9))
            }
            val tv = TextView(this).apply {
                this.text = item
                textSize = 15f
                setTextColor(Color.WHITE)
            }
            val ck = TextView(this).apply {
                this.text = "✓"
                textSize = 15f
                setTextColor(Color.WHITE)
                visibility = if (i == checked) View.VISIBLE else View.INVISIBLE
            }
            r.addView(tv, LinearLayout.LayoutParams(0, wrap, 1f))
            r.addView(ck)
            checks.add(ck)
            r.setOnFocusChangeListener { _, has ->
                rowBg.setColor(if (has) Color.argb(70, 255, 255, 255) else Color.TRANSPARENT)
            }
            r.setOnClickListener {
                if (stayOpen) {
                    checks.forEachIndexed { k, v ->
                        v.visibility = if (k == i) View.VISIBLE else View.INVISIBLE
                    }
                    onPick(i)
                } else {
                    dlg.dismiss()
                    onPick(i)
                }
            }
            list.addView(r, LinearLayout.LayoutParams(matchP, wrap))
            if (i == (if (checked >= 0) checked else 0)) focusTarget = r
        }
        val sv = ScrollView(this).apply { addView(list) }
        box.addView(
            sv,
            LinearLayout.LayoutParams(matchP, dp(minOf(items.size * 40, 300)))
        )
        val foot = smallText(if (parent != null) "Geri: önceki menü" else "Geri: kapat", 11f)
        foot.setPadding(dp(8), dp(8), dp(8), 0)
        box.addView(foot)

        dlg.setContentView(box)
        styleWindow(dlg, 300)
        dlg.setOnCancelListener { parent?.invoke() }
        dlg.setOnShowListener { focusTarget?.requestFocus() }
        dlg.show()
    }

    private fun showMenu(app: AppItem) {
        showPanel(
            app.label,
            listOf("Taşı", "Gizle", "Kaldır", "Uygulama bilgisi"),
            -1, null, false
        ) { which ->
            when (which) {
                0 -> startMove(app)
                1 -> hide(app)
                2 -> uninstall(app)
                3 -> appInfo(app)
                else -> {}
            }
        }
    }

    private fun showHidden() {
        showPanel(
            "Gizlenenler: göstermek için seç",
            hiddenApps.map { it.label },
            -1, null, false
        ) { which -> unhide(hiddenApps[which]) }
    }

    // ---------- Ana ekran ayarları ----------

    private fun applyBg() {
        val idx = prefs.getInt("bg", 0).coerceIn(0, bgPresets.size - 1)
        val colors = bgPresets[idx].second
        if (colors == null) {
            bgView.setImageResource(R.drawable.bg)
        } else {
            bgView.setImageDrawable(
                GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, colors)
            )
        }
    }

    private fun showSettings() {
        showPanel(
            "Ana ekran ayarları",
            listOf("Sütun sayısı", "Arka plan", "Hava durumu konumu", "Varsayılana sıfırla"),
            -1, null, false
        ) { which ->
            when (which) {
                0 -> showColsPanel()
                1 -> showBgPanel()
                2 -> showCityPanel { showSettings() }
                3 -> resetSettings()
                else -> {}
            }
        }
    }

    private fun showColsPanel() {
        val opts = intArrayOf(4, 5, 6, 7, 8, 9)
        val labels = opts.map { "$it sütun" }
        val cur = opts.indexOf(cols).let { if (it >= 0) it else 1 }
        showPanel("Sütun sayısı (kutu boyutu buna göre ayarlanır)", labels, cur, { showSettings() }, true) { i ->
            prefs.edit().putInt("cols", opts[i]).apply()
            rebuildRows(lastPkg)
        }
    }

    private fun showBgPanel() {
        val labels = bgPresets.map { it.first }
        val cur = prefs.getInt("bg", 0).coerceIn(0, bgPresets.size - 1)
        showPanel("Arka plan", labels, cur, { showSettings() }, true) { i ->
            prefs.edit().putInt("bg", i).apply()
            applyBg()
        }
    }

    private fun resetSettings() {
        prefs.edit().remove("cols").remove("bg").apply()
        applyBg()
        rebuildRows(lastPkg)
    }

    // ---------- Hava durumu (Open-Meteo, anahtar gerekmez) ----------

    private fun saveCity(name: String, lat: String, lon: String) {
        prefs.edit().putString("city", name).putString("lat", lat).putString("lon", lon)
            .remove("wx").apply()
        updateWeatherText()
        lastWeather = System.currentTimeMillis()
        fetchWeather()
    }

    private fun showCityPanel(parent: (() -> Unit)?) {
        val names = cities.map { it.name } + "Başka şehir ara…"
        val cur = cities.indexOfFirst { it.name == prefs.getString("city", "") }
        showPanel("Hava durumu konumu", names, cur, parent, false) { i ->
            if (i < cities.size) {
                saveCity(cities[i].name, cities[i].lat, cities[i].lon)
            } else {
                showCitySearch(parent)
            }
        }
    }

    private fun showCitySearch(parent: (() -> Unit)?) {
        val dlg = Dialog(this)
        dlg.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val box = panelBox()
        val titleView = smallText("Şehir ara", 13f)
        titleView.setPadding(dp(8), 0, dp(8), dp(8))
        box.addView(titleView)
        val et = EditText(this).apply {
            hint = "Şehir adını yaz, sonra Enter"
            setHintTextColor(Color.parseColor("#7C7C88"))
            setTextColor(Color.WHITE)
            textSize = 15f
            setSingleLine()
            imeOptions = EditorInfo.IME_ACTION_SEARCH
        }
        et.setOnEditorActionListener { v, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH || actionId == EditorInfo.IME_ACTION_DONE) {
                val q = v.text.toString().trim()
                if (q.isNotEmpty()) {
                    dlg.dismiss()
                    searchCity(q, parent)
                }
                true
            } else {
                false
            }
        }
        box.addView(et, LinearLayout.LayoutParams(matchP, wrap))
        val foot = smallText("Geri: önceki menü", 11f)
        foot.setPadding(dp(8), dp(8), dp(8), 0)
        box.addView(foot)
        dlg.setContentView(box)
        styleWindow(dlg, 300)
        dlg.setOnCancelListener { parent?.invoke() }
        dlg.show()
    }

    private fun searchCity(q: String, parent: (() -> Unit)?) {
        Thread {
            var found: List<City> = emptyList()
            var labels: List<String> = emptyList()
            try {
                val url = "https://geocoding-api.open-meteo.com/v1/search?name=" +
                    URLEncoder.encode(q, "UTF-8") + "&count=6&language=tr&format=json"
                val conn = URL(url).openConnection() as HttpURLConnection
                conn.connectTimeout = 8000
                conn.readTimeout = 8000
                val txt = conn.inputStream.bufferedReader().use { it.readText() }
                val arr = JSONObject(txt).optJSONArray("results")
                if (arr != null) {
                    val cs = mutableListOf<City>()
                    val ls = mutableListOf<String>()
                    for (k in 0 until arr.length()) {
                        val o = arr.getJSONObject(k)
                        val name = o.optString("name")
                        val admin = o.optString("admin1")
                        val country = o.optString("country")
                        cs.add(City(name, o.getDouble("latitude").toString(), o.getDouble("longitude").toString()))
                        ls.add(listOf(name, admin, country).filter { it.isNotEmpty() }.joinToString(", "))
                    }
                    found = cs
                    labels = ls
                }
            } catch (_: Exception) {}
            handler.post {
                if (found.isEmpty()) {
                    Toast.makeText(this, "Şehir bulunamadı ya da internet yok", Toast.LENGTH_LONG).show()
                    showCitySearch(parent)
                } else {
                    showPanel("Sonuçlar", labels, -1, { showCitySearch(parent) }, false) { i ->
                        saveCity(found[i].name, found[i].lat, found[i].lon)
                    }
                }
            }
        }.start()
    }

    private fun wxText(code: Int): String = when (code) {
        0 -> "Açık"
        1 -> "Çoğunlukla açık"
        2 -> "Parçalı bulutlu"
        3 -> "Kapalı"
        45, 48 -> "Sisli"
        51, 53, 55, 56, 57 -> "Çiseleme"
        61, 63, 65, 66, 67 -> "Yağmurlu"
        71, 73, 75, 77 -> "Karlı"
        80, 81, 82 -> "Sağanak"
        85, 86 -> "Kar sağanağı"
        95, 96, 99 -> "Fırtına"
        else -> ""
    }

    private fun fetchWeather() {
        val lat = prefs.getString("lat", null) ?: return
        val lon = prefs.getString("lon", null) ?: return
        Thread {
            try {
                val url = "https://api.open-meteo.com/v1/forecast?latitude=" + lat +
                    "&longitude=" + lon + "&current=temperature_2m,weather_code&timezone=auto"
                val conn = URL(url).openConnection() as HttpURLConnection
                conn.connectTimeout = 8000
                conn.readTimeout = 8000
                val txt = conn.inputStream.bufferedReader().use { it.readText() }
                val cur = JSONObject(txt).getJSONObject("current")
                val temp = Math.round(cur.getDouble("temperature_2m")).toInt()
                val code = cur.getInt("weather_code")
                prefs.edit().putString("wx", temp.toString() + "°|" + wxText(code)).apply()
                handler.post { updateWeatherText() }
            } catch (_: Exception) {}
        }.start()
    }

    private fun updateWeatherText() {
        val city = prefs.getString("city", null)
        if (city == null) {
            weatherText.text = "Hava durumu için konum seç"
            return
        }
        val wx = prefs.getString("wx", null)
        weatherText.text = if (wx == null) {
            city
        } else {
            val p = wx.split("|")
            city + " · " + p[0] + " " + (if (p.size > 1) p[1] else "")
        }
    }

    // ---------- Ayarlar, Wi-Fi ----------

    private fun openSettings(action: String) {
        try {
            startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            try {
                startActivity(
                    Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            } catch (_: Exception) {}
        }
    }

    @Suppress("DEPRECATION")
    private fun updateWifi() {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val ok = cm.activeNetworkInfo?.isConnected == true
        wifiIcon.setColorFilter(
            if (ok) Color.WHITE else Color.parseColor("#7A8594"),
            PorterDuff.Mode.SRC_IN
        )
    }

    private fun iconButton(icon: View, action: () -> Unit): View {
        val bg = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.TRANSPARENT)
        }
        val f = FrameLayout(this).apply {
            background = bg
            isFocusable = true
            addView(icon, FrameLayout.LayoutParams(matchP, matchP))
        }
        f.setOnFocusChangeListener { v, has ->
            if (has) {
                bg.setColor(Color.argb(70, 255, 255, 255))
                v.animate().scaleX(1.15f).scaleY(1.15f).setDuration(120).start()
            } else {
                bg.setColor(Color.TRANSPARENT)
                v.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
            }
        }
        f.setOnClickListener { action() }
        f.layoutParams = LinearLayout.LayoutParams(dp(48), dp(48)).apply {
            setMargins(dp(6), 0, dp(6), 0)
        }
        return f
    }

    // ---------- Kutular ----------

    // Satırın sonunda sağ, başında sol tuş başka yere atlamasın
    private fun stopEdges(v: View) {
        v.setOnKeyListener { view, keyCode, event ->
            var consume = false
            if (event.action == KeyEvent.ACTION_DOWN) {
                val p = view.parent as? ViewGroup
                if (p != null) {
                    if (keyCode == KeyEvent.KEYCODE_DPAD_RIGHT &&
                        p.indexOfChild(view) == p.childCount - 1
                    ) consume = true
                    if (keyCode == KeyEvent.KEYCODE_DPAD_LEFT && p.indexOfChild(view) == 0) {
                        consume = true
                    }
                }
            }
            consume
        }
    }

    private fun tile(app: AppItem): View {
        val bg = GradientDrawable().apply {
            cornerRadius = dp(14).toFloat()
            setColor(Color.parseColor("#2B2B40"))
        }
        val frame = FrameLayout(this).apply {
            background = bg
            isFocusable = true
            clipToOutline = true
            elevation = dp(3).toFloat()
            tag = app.pkg
        }
        val img = ImageView(this).apply {
            setImageDrawable(app.image)
            if (app.isBanner) {
                scaleType = ImageView.ScaleType.CENTER_CROP
            } else {
                scaleType = ImageView.ScaleType.FIT_CENTER
                setPadding(dp(tileW / 7), dp(tileH / 6), dp(tileW / 7), dp(tileH / 6))
            }
        }
        frame.addView(img, FrameLayout.LayoutParams(matchP, matchP))

        frame.setOnFocusChangeListener { v, hasFocus ->
            if (hasFocus) {
                lastPkg = app.pkg
                v.animate().scaleX(1.15f).scaleY(1.15f)
                    .translationZ(dp(14).toFloat()).setDuration(130).start()
                val moving = movingPkg == app.pkg
                bg.setStroke(dp(3), if (moving) Color.parseColor("#FF9F0A") else Color.WHITE)
                label.text = if (moving) {
                    app.label + "   (← → ile kaydır, Tamam ile bitir)"
                } else {
                    app.label
                }
            } else {
                v.animate().scaleX(1f).scaleY(1f).translationZ(0f).setDuration(130).start()
                bg.setStroke(0, Color.TRANSPARENT)
            }
        }
        frame.setOnClickListener {
            val i = Intent(Intent.ACTION_MAIN)
                .setClassName(app.pkg, app.cls)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            try { startActivity(i) } catch (_: Exception) {}
        }
        frame.setOnLongClickListener {
            showMenu(app)
            true
        }
        stopEdges(frame)

        frame.layoutParams = LinearLayout.LayoutParams(dp(tileW), dp(tileH)).apply {
            setMargins(0, 0, dp(tileGap), 0)
        }
        return frame
    }

    // Gizlenen uygulama varsa satırın sonunda çıkan kutu
    private fun hiddenTile(): View {
        val bg = GradientDrawable().apply {
            cornerRadius = dp(14).toFloat()
            setColor(Color.argb(90, 0, 0, 0))
        }
        val frame = FrameLayout(this).apply {
            background = bg
            isFocusable = true
        }
        val tv = TextView(this).apply {
            text = "Gizlenenler (" + hiddenApps.size + ")"
            textSize = 15f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        frame.addView(tv, FrameLayout.LayoutParams(matchP, matchP))
        frame.setOnFocusChangeListener { v, hasFocus ->
            if (hasFocus) {
                v.animate().scaleX(1.15f).scaleY(1.15f).setDuration(130).start()
                bg.setStroke(dp(3), Color.WHITE)
                label.text = "Gizlenen uygulamalar"
            } else {
                v.animate().scaleX(1f).scaleY(1f).setDuration(130).start()
                bg.setStroke(0, Color.TRANSPARENT)
            }
        }
        frame.setOnClickListener { showHidden() }
        stopEdges(frame)
        frame.layoutParams = LinearLayout.LayoutParams(dp(tileW), dp(tileH)).apply {
            setMargins(0, 0, dp(tileGap), 0)
        }
        return frame
    }
}
