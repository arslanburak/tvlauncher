package com.burak.tvlauncher

import android.app.Activity
import android.app.ActivityManager
import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.ConnectivityManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

// PiLauncher — hafif, Apple TV'den esinlenen Android TV ana ekranı.
// Üst sağ: RAM, Wi-Fi, Ayarlar (dişli) ve saat/hava. Tüm ayarlar dişlide.
// Uygulamaya uzun basınca (Tamam'a basılı tut): Taşı / Gizle / Kaldır / Bilgi.
class MainActivity : Activity() {

    companion object {
        const val GH_OWNER = "arslanburak"
        const val GH_REPO = "tvlauncher"
        const val VERSION = "1.1"       // yeni sürümde artır
        const val REQ_PHOTO = 4201
    }

    private data class AppItem(
        val pkg: String, val cls: String, val label: String, val image: Drawable, val isBanner: Boolean
    )
    private class City(val name: String, val lat: String, val lon: String)
    private class PItem(
        val label: String, val glyph: Int = -1, val tint: String = "#5B6B8C",
        val swatch: IntArray? = null, val photo: Boolean = false, val sub: String? = null,
        val arrow: Boolean = false, val image: Drawable? = null
    )

    private val pinned = listOf(
        "com.netflix.ninja", "com.google.android.youtube.tv", "com.amazon.amazonvideo.livingroom",
        "com.disney.disneyplus", "com.wbd.stream", "com.apple.atve.androidtv.appletv",
        "com.ttnet.tivibutv", "com.beonetv.tod"
    )
    private val cities = listOf(
        City("İstanbul", "41.01", "28.98"), City("Ankara", "39.93", "32.86"),
        City("İzmir", "38.42", "27.14"), City("Bursa", "40.19", "29.06"),
        City("Antalya", "36.90", "30.69"), City("Adana", "37.00", "35.32"),
        City("Konya", "37.87", "32.48"), City("Gaziantep", "37.07", "37.38"),
        City("Şanlıurfa", "37.16", "38.80"), City("Kocaeli", "40.77", "29.94"),
        City("Mersin", "36.80", "34.64"), City("Diyarbakır", "37.91", "40.24"),
        City("Hatay", "36.20", "36.16"), City("Manisa", "38.61", "27.43"),
        City("Kayseri", "38.72", "35.49"), City("Samsun", "41.29", "36.33"),
        City("Balıkesir", "39.65", "27.89"), City("Trabzon", "41.00", "39.72"),
        City("Eskişehir", "39.77", "30.52"), City("Denizli", "37.78", "29.09")
    )

    private val tileGap = 24
    private val gridPad = 64
    private val rowGap = 24
    private val focusScale = 1.22f

    private val cols: Int get() = prefs.getInt("cols", 5)
    private val tileW: Int
        get() {
            val sw = (resources.displayMetrics.widthPixels / resources.displayMetrics.density).toInt()
            return (sw - 2 * gridPad) / cols - tileGap
        }
    private val tileH: Int get() = tileW * 84 / 150

    private fun c(vararg h: String): IntArray = IntArray(h.size) { Color.parseColor(h[it]) }
    private val bgPresets: List<Pair<String, IntArray?>> = listOf(
        Pair("Klasik (fotoğraf)", null),
        Pair("Gece mavisi", c("#0C1220", "#101A2E", "#2B3C5A", "#1A2740", "#223256")),
        Pair("Okyanus", c("#0A1518", "#0E2026", "#1C4A52", "#123138", "#174249")),
        Pair("Orman", c("#0D1410", "#121D16", "#2B4536", "#1B3023", "#24402F")),
        Pair("Gün batımı", c("#160E12", "#241219", "#5A2E3C", "#3C1E28", "#4E2734")),
        Pair("Mor sis", c("#100D18", "#171426", "#3C3658", "#2A2440", "#352E52")),
        Pair("Kömür", c("#141518", "#191A1E", "#303238", "#232428", "#2A2C31")),
        Pair("Gece yarısı (düz)", c("#0B0D12", "#0E1016", "#13161D", "#15181F", "#181C24"))
    )

    private val matchP = ViewGroup.LayoutParams.MATCH_PARENT
    private val wrap = ViewGroup.LayoutParams.WRAP_CONTENT

    private lateinit var prefs: SharedPreferences
    private lateinit var root: FrameLayout
    private lateinit var greeting: TextView
    private lateinit var clock: TextView
    private lateinit var date: TextView
    private lateinit var weatherText: TextView
    private lateinit var wxIcon: WxIconView
    private lateinit var wifiIcon: ImageView
    private lateinit var ramLabel: TextView
    private lateinit var hintView: TextView
    private lateinit var topPill: LinearLayout
    private lateinit var grid: LinearLayout
    private lateinit var gridScroll: ScrollView
    private lateinit var bgView: ImageView
    private val topControls = mutableListOf<View>()
    private var gearView: View? = null

    private val handler = Handler(Looper.getMainLooper())
    private var shown = mutableListOf<AppItem>()
    private var hiddenApps = listOf<AppItem>()
    private var movingPkg: String? = null
    private var lastPkg: String? = null
    private var lastWeather = 0L
    private var saverView: View? = null
    private var saverClock: TextView? = null
    private val openDialogs = mutableListOf<Dialog>()

    private val tick = object : Runnable {
        override fun run() {
            val now = Date()
            clock.text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(now)
            date.text = SimpleDateFormat("d MMMM, EEEE", Locale("tr", "TR")).format(now)
            greeting.text = greetingText()
            updateWifi()
            saverClock?.text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(now)
            if (System.currentTimeMillis() - lastWeather > 30 * 60 * 1000L) {
                lastWeather = System.currentTimeMillis(); fetchWeather()
            }
            handler.postDelayed(this, 15000)
        }
    }
    private val saverRunnable = Runnable { showSaver() }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun greetingText(): String {
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val g = when { h < 5 -> "İyi geceler"; h < 12 -> "Günaydın"; h < 18 -> "İyi günler"; else -> "İyi akşamlar" }
        val n = prefs.getString("name", "") ?: ""
        return if (n.isEmpty()) g else "$g, $n"
    }

    private fun glass(radiusDp: Int, alpha: Int): GradientDrawable = GradientDrawable().apply {
        cornerRadius = dp(radiusDp).toFloat(); setColor(Color.argb(alpha, 20, 22, 28)); setStroke(dp(1), Color.argb(55, 255, 255, 255))
    }
    private fun iconImage(res: Int): ImageView = ImageView(this).apply {
        setImageResource(res); setColorFilter(Color.WHITE, PorterDuff.Mode.SRC_IN)
        scaleType = ImageView.ScaleType.FIT_CENTER; setPadding(dp(10), dp(10), dp(10), dp(10))
    }
    private fun glyphBtn(kind: Int, action: () -> Unit): View {
        val bg = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.TRANSPARENT) }
        val g = GlyphView(this, kind)
        val f = FrameLayout(this).apply { background = bg; isFocusable = true; setPadding(dp(11), dp(11), dp(11), dp(11)); addView(g, FrameLayout.LayoutParams(matchP, matchP)) }
        f.setOnFocusChangeListener { v, has ->
            if (has) { bg.setColor(Color.argb(90, 255, 255, 255)); v.animate().scaleX(1.15f).scaleY(1.15f).setDuration(120).start() }
            else { bg.setColor(Color.TRANSPARENT); v.animate().scaleX(1f).scaleY(1f).setDuration(120).start() }
        }
        f.setOnClickListener { action() }
        f.setOnKeyListener { _, k, e -> if (e.action == KeyEvent.ACTION_DOWN && k == KeyEvent.KEYCODE_DPAD_DOWN) { focusGrid(); true } else false }
        f.layoutParams = LinearLayout.LayoutParams(dp(42), dp(42)).apply { setMargins(dp(2), 0, dp(2), 0) }
        return f
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("launcher", Context.MODE_PRIVATE)

        root = FrameLayout(this)
        root.setBackgroundColor(Color.parseColor("#141414"))
        root.clipChildren = false

        bgView = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
        root.addView(bgView, FrameLayout.LayoutParams(matchP, matchP))
        applyBg()
        val scrim = View(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.argb(0, 0, 0, 0), Color.argb(150, 0, 0, 0)))
        }
        root.addView(scrim, FrameLayout.LayoutParams(matchP, (resources.displayMetrics.heightPixels * 0.55f).toInt(), Gravity.BOTTOM))

        // Izgara (üst/alt çubuğun ALTINDA kalması için önce ekleniyor)
        grid = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(gridPad), 0, dp(gridPad), 0); clipChildren = false; clipToPadding = false
        }
        gridScroll = ScrollView(this).apply { isVerticalScrollBarEnabled = false; clipChildren = false; clipToPadding = false; addView(grid) }
        root.addView(gridScroll, FrameLayout.LayoutParams(matchP, wrap, Gravity.BOTTOM).apply { setMargins(0, 0, 0, dp(44)) })

        greeting = TextView(this).apply {
            textSize = 26f; typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
            setTextColor(Color.WHITE); setShadowLayer(10f, 0f, 2f, Color.argb(140, 0, 0, 0))
        }
        root.addView(greeting, FrameLayout.LayoutParams(wrap, wrap, Gravity.TOP or Gravity.START).apply { setMargins(dp(gridPad + 4), dp(40), 0, 0) })

        buildTopBar()

        hintView = TextView(this).apply {
            text = "← → ↑ ↓ ile taşı   ·   Tamam ile bitir"; textSize = 14f; setTextColor(Color.WHITE)
            background = glass(30, 205); setPadding(dp(22), dp(10), dp(22), dp(10)); visibility = View.GONE
        }
        root.addView(hintView, FrameLayout.LayoutParams(wrap, wrap, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { setMargins(0, dp(96), 0, 0) })

        setContentView(root)
        greeting.text = greetingText()
    }

    private fun buildTopBar() {
        topControls.clear()
        val timeBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.END }
        clock = TextView(this).apply { textSize = 24f; typeface = Typeface.create("sans-serif-light", Typeface.NORMAL); setTextColor(Color.WHITE); gravity = Gravity.END }
        date = TextView(this).apply { textSize = 12.5f; setTextColor(Color.parseColor("#C9C9D3")); gravity = Gravity.END }
        wxIcon = WxIconView(this, WxIconView.CLOUD)
        weatherText = TextView(this).apply { textSize = 12.5f; setTextColor(Color.parseColor("#C9C9D3")) }
        val wxRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(8), dp(3), dp(8), dp(3)) }
        wxRow.addView(wxIcon, LinearLayout.LayoutParams(dp(18), dp(18)).apply { setMargins(0, 0, dp(6), 0) })
        wxRow.addView(weatherText)
        val wxBg = GradientDrawable().apply { cornerRadius = dp(10).toFloat(); setColor(Color.TRANSPARENT) }
        val weatherBox = FrameLayout(this).apply { background = wxBg; isFocusable = true; addView(wxRow) }
        weatherBox.setOnFocusChangeListener { _, has -> wxBg.setColor(if (has) Color.argb(70, 255, 255, 255) else Color.TRANSPARENT) }
        weatherBox.setOnClickListener { if (prefs.getString("city", null) == null) showCityPanel(null) else showWeatherDetail() }
        weatherBox.setOnKeyListener { _, k, e -> if (e.action == KeyEvent.ACTION_DOWN && k == KeyEvent.KEYCODE_DPAD_DOWN) { focusGrid(); true } else false }
        timeBox.addView(clock); timeBox.addView(date)
        timeBox.addView(weatherBox, LinearLayout.LayoutParams(wrap, wrap).apply { setMargins(0, dp(2), 0, 0) })

        // RAM geçici etiketi (basınca solda görünür)
        ramLabel = TextView(this).apply {
            textSize = 12.5f; setTextColor(Color.parseColor("#9FE0B0")); visibility = View.GONE
            setPadding(dp(4), 0, dp(8), 0)
        }
        val ramBtn = glyphBtn(GlyphView.BROOM) { cleanRam() }
        wifiIcon = iconImage(R.drawable.ic_wifi)
        val wifiBtn = FrameLayout(this).apply {
            isFocusable = true
            val bg = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.TRANSPARENT) }
            background = bg; addView(wifiIcon, FrameLayout.LayoutParams(matchP, matchP))
            setOnFocusChangeListener { v, has -> if (has) { bg.setColor(Color.argb(90, 255, 255, 255)); v.animate().scaleX(1.15f).scaleY(1.15f).setDuration(120).start() } else { bg.setColor(Color.TRANSPARENT); v.animate().scaleX(1f).scaleY(1f).setDuration(120).start() } }
            setOnClickListener { openSystem(Settings.ACTION_WIFI_SETTINGS) }
            setOnKeyListener { _, k, e -> if (e.action == KeyEvent.ACTION_DOWN && k == KeyEvent.KEYCODE_DPAD_DOWN) { focusGrid(); true } else false }
            layoutParams = LinearLayout.LayoutParams(dp(42), dp(42)).apply { setMargins(dp(2), 0, dp(2), 0) }
        }
        val gearBtn = glyphBtn(GlyphView.GEAR) { showSettings() }
        gearView = gearBtn

        topPill = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            background = glass(32, 110); setPadding(dp(12), dp(6), dp(18), dp(6)); clipChildren = false
        }
        topPill.addView(ramLabel)
        topPill.addView(ramBtn); topPill.addView(wifiBtn); topPill.addView(gearBtn)
        val divider = View(this).apply { setBackgroundColor(Color.argb(60, 255, 255, 255)) }
        topPill.addView(divider, LinearLayout.LayoutParams(dp(1), dp(40)).apply { setMargins(dp(12), 0, dp(16), 0) })
        topPill.addView(timeBox)
        topControls.addAll(listOf(ramBtn, wifiBtn, gearBtn, weatherBox))
        topPill.addOnLayoutChangeListener { v, l, _, r, _, _, _, _, _ -> v.pivotX = (r - l).toFloat(); v.pivotY = 0f }
        root.addView(topPill, FrameLayout.LayoutParams(wrap, wrap, Gravity.TOP or Gravity.END).apply { setMargins(0, dp(28), dp(48), 0) })
        applyTopScale(); updateWeatherText()
    }

    private fun focusGrid() { (grid.findFocus() ?: firstTile())?.let { } ; (lastTileView() ?: firstTile())?.requestFocus() }
    private fun firstTile(): View? = (grid.getChildAt(0) as? ViewGroup)?.getChildAt(0)
    private fun lastTileView(): View? {
        for (r in 0 until grid.childCount) { val row = grid.getChildAt(r) as ViewGroup
            for (ccc in 0 until row.childCount) if (row.getChildAt(ccc).tag == lastPkg) return row.getChildAt(ccc) }
        return firstTile()
    }

    override fun onResume() { super.onResume(); refreshApps(lastPkg); handler.post(tick); resetSaverTimer() }
    override fun onPause() { super.onPause(); handler.removeCallbacks(tick); handler.removeCallbacks(saverRunnable) }
    override fun onUserInteraction() { super.onUserInteraction(); resetSaverTimer() }

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        if (saverView != null) { if (e.action == KeyEvent.ACTION_DOWN) hideSaver(); return true }
        resetSaverTimer()
        if (movingPkg != null) {
            if (e.action == KeyEvent.ACTION_DOWN) when (e.keyCode) {
                KeyEvent.KEYCODE_DPAD_LEFT -> moveBy(-1); KeyEvent.KEYCODE_DPAD_RIGHT -> moveBy(1)
                KeyEvent.KEYCODE_DPAD_UP -> moveBy(-cols); KeyEvent.KEYCODE_DPAD_DOWN -> moveBy(cols)
                KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_BACK -> endMove()
                else -> {}
            }
            return true
        }
        return super.dispatchKeyEvent(e)
    }

    @Suppress("OVERRIDE_DEPRECATION")
    override fun onBackPressed() {}

    // ---------- Uygulama listesi ----------

    private fun loadAll(): List<AppItem> {
        val pm = packageManager
        val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER)
        val order = (prefs.getString("order", "") ?: "").split("|").filter { it.isNotEmpty() }
        return pm.queryIntentActivities(query, 0).filter { it.activityInfo.packageName != packageName }.map {
            val banner = it.activityInfo.loadBanner(pm)
            AppItem(it.activityInfo.packageName, it.activityInfo.name, it.loadLabel(pm).toString(), banner ?: it.loadIcon(pm), banner != null)
        }.sortedWith(compareBy({
            val o = order.indexOf(it.pkg); if (o >= 0) o else { val p = pinned.indexOf(it.pkg); 10000 + (if (p >= 0) p else 1000) }
        }, { it.label.lowercase() }))
    }

    private fun refreshApps(focusPkg: String?) {
        val all = loadAll(); val hidden = prefs.getStringSet("hidden", emptySet()) ?: emptySet()
        shown = all.filter { !hidden.contains(it.pkg) }.toMutableList()
        hiddenApps = all.filter { hidden.contains(it.pkg) }
        rebuildRows(focusPkg)
    }

    private fun rebuildRows(focusPkg: String?) {
        grid.removeAllViews()
        val n = cols
        val views = mutableListOf<View>()
        for (app in shown) views.add(tile(app))
        if (hiddenApps.isNotEmpty()) views.add(hiddenTile())
        var target: View? = null
        var cur: LinearLayout? = null
        views.forEachIndexed { i, v ->
            if (i % n == 0) {
                val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; clipChildren = false }
                cur = r
                grid.addView(r, LinearLayout.LayoutParams(wrap, wrap).apply { setMargins(0, dp(rowGap / 2), 0, dp(rowGap / 2)) })
            }
            cur?.addView(v)
            if (focusPkg != null && v.tag == focusPkg) target = v
        }
        val rows = (views.size + n - 1) / n
        val rowSpace = tileH + rowGap
        val screenH = (resources.displayMetrics.heightPixels / resources.displayMetrics.density).toInt()
        val maxRows = maxOf(1, (screenH - 130 - 44) / rowSpace)
        val lp = gridScroll.layoutParams
        lp.height = dp(minOf(rows, maxRows) * rowSpace + 12)
        gridScroll.layoutParams = lp
        (target ?: firstTile())?.requestFocus()
    }

    private fun saveOrder() { prefs.edit().putString("order", (shown.map { it.pkg } + hiddenApps.map { it.pkg }).joinToString("|")).apply() }
    private fun startMove(app: AppItem) { movingPkg = app.pkg; hintView.visibility = View.VISIBLE; rebuildRows(app.pkg) }
    private fun moveBy(d: Int) {
        val mp = movingPkg ?: return; val i = shown.indexOfFirst { it.pkg == mp }; val j = i + d
        if (i < 0 || j < 0 || j >= shown.size) return
        val t = shown[i]; shown[i] = shown[j]; shown[j] = t; saveOrder(); rebuildRows(mp)
    }
    private fun endMove() { val mp = movingPkg; movingPkg = null; hintView.visibility = View.GONE; rebuildRows(mp) }
    private fun hide(app: AppItem) { val h = (prefs.getStringSet("hidden", emptySet()) ?: emptySet()).toMutableSet(); h.add(app.pkg); prefs.edit().putStringSet("hidden", h).apply(); refreshApps(null) }
    private fun unhide(app: AppItem) { val h = (prefs.getStringSet("hidden", emptySet()) ?: emptySet()).toMutableSet(); h.remove(app.pkg); prefs.edit().putStringSet("hidden", h).apply(); refreshApps(app.pkg) }
    private fun uninstall(app: AppItem) { try { startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:" + app.pkg))) } catch (_: Exception) {} }
    private fun appInfo(app: AppItem) { try { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + app.pkg)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {} }

    // ---------- RAM ----------

    @Suppress("DEPRECATION")
    private fun freeRamMb(): Long {
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo(); am.getMemoryInfo(mi); return mi.availMem / (1024 * 1024)
    }
    private fun cleanRam() {
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val before = freeRamMb()
        Thread {
            try {
                val pm = packageManager
                val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER)
                val pkgs = pm.queryIntentActivities(q, 0).map { it.activityInfo.packageName }.toMutableSet()
                pkgs.addAll(listOf("com.google.android.katniss", "com.android.vending", "com.google.android.youtube.tv", "com.netflix.ninja", "com.wbd.stream"))
                pkgs.remove(packageName)
                for (p in pkgs) { try { am.killBackgroundProcesses(p) } catch (_: Exception) {} }
            } catch (_: Exception) {}
            handler.postDelayed({
                val freed = (freeRamMb() - before).coerceAtLeast(0)
                ramLabel.text = if (freed > 0) "$freed MB temizlendi" else "Zaten temiz"
                ramLabel.visibility = View.VISIBLE
                handler.postDelayed({ ramLabel.visibility = View.GONE }, 3000)
            }, 800)
        }.start()
    }

    // ---------- Ekran koruyucu ----------

    private val saverMins = intArrayOf(1, 3, 5, 10, 15)
    private fun resetSaverTimer() {
        handler.removeCallbacks(saverRunnable)
        if (saverView != null || openDialogs.isNotEmpty()) return
        if (!prefs.getBoolean("saver", true)) return
        val idx = prefs.getInt("saverMin", 2).coerceIn(0, saverMins.size - 1)
        handler.postDelayed(saverRunnable, saverMins[idx] * 60_000L)
    }
    private fun showSaver() {
        if (saverView != null) return
        if (openDialogs.isNotEmpty()) { while (openDialogs.isNotEmpty()) openDialogs.removeAt(0).dismiss() }
        val ov = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        saverClock = TextView(this).apply { text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date()); textSize = 92f; typeface = Typeface.create("sans-serif-thin", Typeface.NORMAL); setTextColor(Color.WHITE); gravity = Gravity.CENTER }
        val d = TextView(this).apply { text = SimpleDateFormat("d MMMM, EEEE", Locale("tr", "TR")).format(Date()); textSize = 20f; setTextColor(Color.parseColor("#B8B8C4")); gravity = Gravity.CENTER }
        col.addView(saverClock); col.addView(d)
        val wx = prefs.getString("wx", null); val city = prefs.getString("city", null)
        if (wx != null && city != null) { val p = wx.split("|"); col.addView(TextView(this).apply { text = city + " · " + p[0] + " " + (if (p.size > 1) p[1] else ""); textSize = 18f; setTextColor(Color.parseColor("#9AA0AC")); gravity = Gravity.CENTER; setPadding(0, dp(12), 0, 0) }) }
        ov.addView(col, FrameLayout.LayoutParams(wrap, wrap, Gravity.CENTER))
        root.addView(ov, FrameLayout.LayoutParams(matchP, matchP)); saverView = ov
    }
    private fun hideSaver() { saverView?.let { root.removeView(it) }; saverView = null; saverClock = null; resetSaverTimer() }

    // ---------- Paneller ----------

    private fun panelBox(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(16), dp(14), dp(12))
        background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(Color.argb(242, 44, 46, 52), Color.argb(242, 24, 25, 29))).apply { cornerRadius = dp(24).toFloat(); setStroke(dp(1), Color.argb(55, 255, 255, 255)) }
    }
    private fun registerDialog(dlg: Dialog) {
        openDialogs.add(dlg); handler.removeCallbacks(saverRunnable)
        dlg.setOnDismissListener { openDialogs.remove(dlg); resetSaverTimer() }
    }
    private fun styleWindow(dlg: Dialog, widthDp: Int, toRight: Boolean = true) {
        val w = dlg.window ?: return
        w.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT)); w.setLayout(dp(widthDp), ViewGroup.LayoutParams.WRAP_CONTENT)
        w.setGravity(Gravity.TOP or (if (toRight) Gravity.END else Gravity.CENTER_HORIZONTAL))
        w.setDimAmount(0.12f); val lp = w.attributes; lp.y = dp(84); if (toRight) lp.x = dp(48); w.attributes = lp
    }
    private fun titleView(t: String): TextView = TextView(this).apply { text = t; textSize = 17f; typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL); setTextColor(Color.WHITE); setPadding(dp(10), dp(2), dp(10), dp(12)) }
    private fun footView(t: String): TextView = TextView(this).apply { text = t; textSize = 11.5f; setTextColor(Color.parseColor("#8E8E99")); setPadding(dp(10), dp(10), dp(10), 0) }

    private fun showPanel(title: String, items: List<PItem>, checked: Int, parent: (() -> Unit)?, stayOpen: Boolean, onPick: (Int) -> Unit) {
        val dlg = Dialog(this); dlg.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val box = panelBox(); box.addView(titleView(title))
        box.addView(View(this).apply { setBackgroundColor(Color.argb(35, 255, 255, 255)) }, LinearLayout.LayoutParams(matchP, dp(1)).apply { setMargins(0, 0, 0, dp(6)) })
        val selectable = stayOpen || checked >= 0
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val checks = mutableListOf<GlyphView>(); var focusTarget: View? = null
        items.forEachIndexed { i, item ->
            val rowBg = GradientDrawable().apply { cornerRadius = dp(14).toFloat(); setColor(Color.TRANSPARENT) }
            val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; isFocusable = true; background = rowBg; setPadding(dp(10), dp(8), dp(12), dp(8)) }
            if (item.glyph >= 0) {
                val ic = FrameLayout(this).apply { background = GradientDrawable().apply { cornerRadius = dp(9).toFloat(); setColor(Color.parseColor(item.tint)) } }
                ic.addView(GlyphView(this, item.glyph), FrameLayout.LayoutParams(matchP, matchP))
                r.addView(ic, LinearLayout.LayoutParams(dp(34), dp(34)).apply { setMargins(0, 0, dp(12), 0) })
            } else if (item.photo || item.swatch != null) {
                val sw: View = if (item.photo) ImageView(this).apply { setImageDrawable(currentBgThumb()); scaleType = ImageView.ScaleType.CENTER_CROP; background = GradientDrawable().apply { cornerRadius = dp(9).toFloat(); setColor(Color.DKGRAY) }; clipToOutline = true }
                else View(this).apply { background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, item.swatch).apply { cornerRadius = dp(9).toFloat() } }
                r.addView(sw, LinearLayout.LayoutParams(dp(34), dp(34)).apply { setMargins(0, 0, dp(12), 0) })
            } else if (item.image != null) {
                val iv = ImageView(this).apply { setImageDrawable(item.image); scaleType = ImageView.ScaleType.FIT_CENTER; background = GradientDrawable().apply { cornerRadius = dp(9).toFloat(); setColor(Color.parseColor("#20222A")) }; clipToOutline = true; setPadding(dp(7), dp(5), dp(7), dp(5)) }
                r.addView(iv, LinearLayout.LayoutParams(dp(52), dp(40)).apply { setMargins(0, 0, dp(12), 0) })
            }
            val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            if (item.label.isNotEmpty()) col.addView(TextView(this).apply { text = item.label; textSize = 15.5f; setTextColor(Color.WHITE) })
            item.sub?.let { col.addView(TextView(this).apply { text = it; textSize = 12f; setTextColor(Color.parseColor("#9A9AA6")) }) }
            r.addView(col, LinearLayout.LayoutParams(0, wrap, 1f))
            if (selectable) { val ck = GlyphView(this, GlyphView.CHECK); ck.visibility = if (i == checked) View.VISIBLE else View.INVISIBLE; r.addView(ck, LinearLayout.LayoutParams(dp(22), dp(22))); checks.add(ck) }
            else if (item.arrow) { val ch = GlyphView(this, GlyphView.CHEVRON); ch.setTint(Color.parseColor("#8E8E99")); r.addView(ch, LinearLayout.LayoutParams(dp(20), dp(20))) }
            r.setOnFocusChangeListener { _, has -> rowBg.setColor(if (has) Color.argb(60, 255, 255, 255) else Color.TRANSPARENT); rowBg.setStroke(if (has) dp(1) else 0, Color.argb(90, 255, 255, 255)) }
            r.setOnClickListener { if (stayOpen) { checks.forEachIndexed { k, v -> v.visibility = if (k == i) View.VISIBLE else View.INVISIBLE }; onPick(i) } else { dlg.dismiss(); onPick(i) } }
            list.addView(r, LinearLayout.LayoutParams(matchP, wrap).apply { setMargins(0, dp(1), 0, dp(1)) })
            if (i == (if (checked >= 0) checked else 0)) focusTarget = r
        }
        box.addView(ScrollView(this).apply { isVerticalScrollBarEnabled = false; addView(list) }, LinearLayout.LayoutParams(matchP, dp(minOf(items.size * 56, 384))))
        box.addView(footView(if (parent != null) "‹  Geri: önceki menü" else "Geri: kapat"))
        dlg.setContentView(box); styleWindow(dlg, 360); registerDialog(dlg)
        dlg.setOnCancelListener { parent?.invoke() }
        dlg.setOnShowListener { focusTarget?.requestFocus() }
        dlg.show()
    }

    private fun showInput(title: String, hint: String, initial: String, parent: (() -> Unit)?, onDone: (String) -> Unit) {
        val dlg = Dialog(this); dlg.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val box = panelBox(); box.addView(titleView(title))
        val et = EditText(this).apply { setText(initial); this.hint = hint; setHintTextColor(Color.parseColor("#7C7C88")); setTextColor(Color.WHITE); textSize = 16f; setSingleLine(); imeOptions = EditorInfo.IME_ACTION_DONE
            background = GradientDrawable().apply { cornerRadius = dp(12).toFloat(); setColor(Color.argb(60, 255, 255, 255)) }; setPadding(dp(14), dp(10), dp(14), dp(10)) }
        et.setOnEditorActionListener { v, a, _ -> if (a == EditorInfo.IME_ACTION_DONE || a == EditorInfo.IME_ACTION_SEARCH) { dlg.dismiss(); onDone(v.text.toString().trim()); true } else false }
        box.addView(et, LinearLayout.LayoutParams(matchP, wrap))
        box.addView(footView(if (parent != null) "‹  Geri: önceki menü" else "Geri: kapat"))
        dlg.setContentView(box); styleWindow(dlg, 360); registerDialog(dlg)
        dlg.setOnCancelListener { parent?.invoke() }; dlg.show()
    }

    private fun showMenu(app: AppItem) {
        showPanel("Seçenekler", listOf(
            PItem("Taşı", GlyphView.MOVE, "#4C7DF0"), PItem("Gizle", GlyphView.EYE_OFF, "#8A6BD6"),
            PItem("Kaldır", GlyphView.TRASH, "#C25A5A"), PItem("Uygulama bilgisi", GlyphView.INFO, "#6F7684")
        ), -1, null, false) { w -> when (w) { 0 -> startMove(app); 1 -> hide(app); 2 -> uninstall(app); 3 -> appInfo(app); else -> {} } }
    }
    private fun showHidden() {
        showPanel("Gizlenenler · göstermek için seç", hiddenApps.map { PItem("", image = it.image) }, -1, null, false) { w -> unhide(hiddenApps[w]) }
    }

    // ---------- Ayarlar ----------

    private val topScales = floatArrayOf(0.7f, 0.85f, 1.0f, 1.15f)
    private val topLabels = listOf("Çok küçük", "Küçük", "Orta", "Büyük")
    private fun applyTopScale() { val i = prefs.getInt("topScale", 1).coerceIn(0, topScales.size - 1); topPill.scaleX = topScales[i]; topPill.scaleY = topScales[i] }

    private fun customBgFile() = File(filesDir, "custom_bg.jpg")
    private fun decodeBg(maxW: Int): android.graphics.Bitmap? {
        val f = customBgFile(); if (!f.exists()) return null
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }; BitmapFactory.decodeFile(f.path, o)
        var s = 1; while (o.outWidth / s > maxW) s *= 2
        return BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = s })
    }
    private fun currentBgThumb(): Drawable {
        if (prefs.getBoolean("bgCustom", false)) { decodeBg(240)?.let { return android.graphics.drawable.BitmapDrawable(resources, it) } }
        return resources.getDrawable(R.drawable.bg, theme)
    }
    private fun applyBg() {
        if (prefs.getBoolean("bgCustom", false)) {
            val bmp = decodeBg(1920); if (bmp != null) { bgView.setImageBitmap(bmp); return }
        }
        val idx = prefs.getInt("bg", 0).coerceIn(0, bgPresets.size - 1); val colors = bgPresets[idx].second
        if (colors == null) bgView.setImageResource(R.drawable.bg) else bgView.setImageDrawable(GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, colors))
    }

    private fun showSettings() {
        val bgName = if (prefs.getBoolean("bgCustom", false)) "Kendi fotoğrafın" else bgPresets[prefs.getInt("bg", 0).coerceIn(0, bgPresets.size - 1)].first
        val city = prefs.getString("city", null); val name = prefs.getString("name", "") ?: ""
        val ti = prefs.getInt("topScale", 1).coerceIn(0, topScales.size - 1)
        val saverOn = prefs.getBoolean("saver", true); val sm = prefs.getInt("saverMin", 2).coerceIn(0, saverMins.size - 1)
        showPanel("PiLauncher ayarları", listOf(
            PItem("Sütun sayısı", GlyphView.GRID, "#4C7DF0", sub = "$cols sütun", arrow = true),
            PItem("Üst panel boyutu", GlyphView.SLIDERS, "#3FA27A", sub = topLabels[ti], arrow = true),
            PItem("Arka plan", GlyphView.PALETTE, "#8A6BD6", sub = bgName, arrow = true),
            PItem("Hava durumu konumu", GlyphView.CLOUD, "#3A9DB8", sub = city ?: "Seçilmedi", arrow = true),
            PItem("Karşılama adı", GlyphView.USER, "#D98A4E", sub = if (name.isEmpty()) "Yok" else name, arrow = true),
            PItem("Ekran koruyucu", GlyphView.MONITOR, "#5B8BD0", sub = if (saverOn) saverMins[sm].toString() + " dk sonra" else "Kapalı", arrow = true),
            PItem("Android ayarları", GlyphView.GEAR, "#6F7684", sub = "Sistem ayarlarını aç", arrow = true),
            PItem("Güncellemeleri denetle", GlyphView.DOWNLOAD, "#3FA27A", sub = "Sürüm $VERSION", arrow = true),
            PItem("Varsayılana sıfırla", GlyphView.RESET, "#6F7684")
        ), -1, null, false) { w ->
            when (w) {
                0 -> showColsPanel(); 1 -> showTopPanel(); 2 -> showBgPanel(); 3 -> showCityPanel { showSettings() }
                4 -> showNameInput(); 5 -> showSaverPanel(); 6 -> openSystem(Settings.ACTION_SETTINGS)
                7 -> checkUpdate(); 8 -> resetSettings(); else -> {}
            }
        }
    }
    private fun showColsPanel() {
        val opts = intArrayOf(4, 5, 6, 7, 8, 9)
        val labels = opts.map { PItem("$it sütun", sub = if (it <= 4) "Büyük kutular" else if (it >= 8) "Küçük kutular" else null) }
        val cur = opts.indexOf(cols).let { if (it >= 0) it else 1 }
        showPanel("Sütun sayısı", labels, cur, { showSettings() }, true) { i -> prefs.edit().putInt("cols", opts[i]).apply(); rebuildRows(lastPkg) }
    }
    private fun showTopPanel() {
        val cur = prefs.getInt("topScale", 1).coerceIn(0, topScales.size - 1)
        showPanel("Üst panel boyutu", topLabels.map { PItem(it) }, cur, { showSettings() }, true) { i -> prefs.edit().putInt("topScale", i).apply(); applyTopScale() }
    }
    private fun showBgPanel() {
        val items = mutableListOf(PItem("Kendi fotoğrafın…", GlyphView.IMAGE, "#D98A4E", arrow = true))
        bgPresets.forEachIndexed { idx, p -> items.add(PItem(p.first, swatch = p.second, photo = (idx == 0))) }
        val cur = if (prefs.getBoolean("bgCustom", false)) 0 else 1 + prefs.getInt("bg", 0).coerceIn(0, bgPresets.size - 1)
        showPanel("Arka plan", items, cur, { showSettings() }, true) { i ->
            if (i == 0) pickPhoto() else { prefs.edit().putBoolean("bgCustom", false).putInt("bg", i - 1).apply(); applyBg() }
        }
    }
    private fun showNameInput() {
        showInput("Karşılama adı", "Adını yaz (boş = sadece selam)", prefs.getString("name", "") ?: "", { showSettings() }) { q -> prefs.edit().putString("name", q).apply(); greeting.text = greetingText() }
    }
    private fun showSaverPanel() {
        val on = prefs.getBoolean("saver", true)
        val items = mutableListOf(PItem(if (on) "Açık" else "Kapalı", GlyphView.MONITOR, "#5B8BD0", sub = "Dokununca değişir"))
        saverMins.forEach { items.add(PItem("$it dakika sonra")) }
        val cur = if (!on) 0 else 1 + prefs.getInt("saverMin", 2).coerceIn(0, saverMins.size - 1)
        showPanel("Ekran koruyucu", items, cur, { showSettings() }, true) { i ->
            if (i == 0) prefs.edit().putBoolean("saver", !prefs.getBoolean("saver", true)).apply()
            else prefs.edit().putBoolean("saver", true).putInt("saverMin", i - 1).apply()
            resetSaverTimer(); showSaverPanel()
        }
    }
    private fun resetSettings() {
        prefs.edit().remove("cols").remove("bg").remove("bgCustom").remove("topScale").remove("saver").remove("saverMin").apply()
        applyBg(); applyTopScale(); rebuildRows(lastPkg); resetSaverTimer()
    }

    // ---------- Fotoğraf seç ----------
    private fun pickPhoto() {
        try {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "image/*" }
            startActivityForResult(i, REQ_PHOTO)
        } catch (e: Exception) {
            try { startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).apply { type = "image/*" }, REQ_PHOTO) }
            catch (_: Exception) { Toast.makeText(this, "Dosya seçici bulunamadı", Toast.LENGTH_LONG).show() }
        }
    }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_PHOTO && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            Thread {
                try {
                    contentResolver.openInputStream(uri)?.use { input -> FileOutputStream(customBgFile()).use { input.copyTo(it) } }
                    handler.post { prefs.edit().putBoolean("bgCustom", true).apply(); applyBg(); Toast.makeText(this, "Arka plan güncellendi", Toast.LENGTH_SHORT).show() }
                } catch (e: Exception) { handler.post { Toast.makeText(this, "Fotoğraf okunamadı", Toast.LENGTH_LONG).show() } }
            }.start()
        }
    }

    // ---------- Hava durumu ----------
    private fun saveCity(name: String, lat: String, lon: String) {
        prefs.edit().putString("city", name).putString("lat", lat).putString("lon", lon).remove("wx").remove("wxfull").apply()
        updateWeatherText(); lastWeather = System.currentTimeMillis(); fetchWeather()
    }
    private fun showCityPanel(parent: (() -> Unit)?) {
        val items = cities.map { PItem(it.name) } + PItem("Başka şehir ara…", arrow = true)
        val cur = cities.indexOfFirst { it.name == prefs.getString("city", "") }
        showPanel("Hava durumu konumu", items, cur, parent, false) { i -> if (i < cities.size) saveCity(cities[i].name, cities[i].lat, cities[i].lon) else showCitySearch(parent) }
    }
    private fun showCitySearch(parent: (() -> Unit)?) { showInput("Şehir ara", "Şehir adını yaz, sonra Enter", "", parent) { q -> if (q.isNotEmpty()) searchCity(q, parent) else showCitySearch(parent) } }
    private fun searchCity(q: String, parent: (() -> Unit)?) {
        Thread {
            var found: List<City> = emptyList(); var labels: List<String> = emptyList()
            try {
                val url = "https://geocoding-api.open-meteo.com/v1/search?name=" + URLEncoder.encode(q, "UTF-8") + "&count=6&language=tr&format=json"
                val conn = URL(url).openConnection() as HttpURLConnection; conn.connectTimeout = 8000; conn.readTimeout = 8000
                val txt = conn.inputStream.bufferedReader().use { it.readText() }
                val arr = JSONObject(txt).optJSONArray("results")
                if (arr != null) { val cs = mutableListOf<City>(); val ls = mutableListOf<String>()
                    for (k in 0 until arr.length()) { val o = arr.getJSONObject(k)
                        cs.add(City(o.optString("name"), o.getDouble("latitude").toString(), o.getDouble("longitude").toString()))
                        ls.add(listOf(o.optString("name"), o.optString("admin1"), o.optString("country")).filter { it.isNotEmpty() }.joinToString(", ")) }
                    found = cs; labels = ls }
            } catch (_: Exception) {}
            handler.post {
                if (found.isEmpty()) { Toast.makeText(this, "Şehir bulunamadı ya da internet yok", Toast.LENGTH_LONG).show(); showCitySearch(parent) }
                else showPanel("Sonuçlar", labels.map { PItem(it) }, -1, { showCitySearch(parent) }, false) { i -> saveCity(found[i].name, found[i].lat, found[i].lon) }
            }
        }.start()
    }
    private fun wxText(code: Int): String = when (code) {
        0 -> "Açık"; 1 -> "Çoğunlukla açık"; 2 -> "Parçalı bulutlu"; 3 -> "Kapalı"; 45, 48 -> "Sisli"
        51, 53, 55, 56, 57 -> "Çiseleme"; 61, 63, 65, 66, 67 -> "Yağmurlu"; 71, 73, 75, 77 -> "Karlı"
        80, 81, 82 -> "Sağanak"; 85, 86 -> "Kar sağanağı"; 95, 96, 99 -> "Fırtına"; else -> ""
    }
    private fun wxKind(code: Int): Int {
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY); val night = h < 6 || h >= 20
        return when (code) { 0, 1 -> if (night) WxIconView.MOON else WxIconView.SUN; 2 -> WxIconView.PARTLY; 3 -> WxIconView.CLOUD
            45, 48 -> WxIconView.FOG; 51, 53, 55, 56, 57, 61, 63, 65, 66, 67, 80, 81, 82 -> WxIconView.RAIN
            71, 73, 75, 77, 85, 86 -> WxIconView.SNOW; 95, 96, 99 -> WxIconView.STORM; else -> WxIconView.CLOUD }
    }
    private fun fetchWeather() {
        val lat = prefs.getString("lat", null) ?: return; val lon = prefs.getString("lon", null) ?: return
        Thread {
            try {
                val url = "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current=temperature_2m,apparent_temperature,relative_humidity_2m,weather_code,wind_speed_10m,precipitation&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max&timezone=auto&forecast_days=5"
                val conn = URL(url).openConnection() as HttpURLConnection; conn.connectTimeout = 8000; conn.readTimeout = 8000
                val txt = conn.inputStream.bufferedReader().use { it.readText() }
                val cur = JSONObject(txt).getJSONObject("current")
                val temp = Math.round(cur.getDouble("temperature_2m")).toInt(); val code = cur.getInt("weather_code")
                prefs.edit().putString("wx", "$temp°|" + wxText(code) + "|" + code).putString("wxfull", txt).apply()
                handler.post { updateWeatherText() }
            } catch (_: Exception) {}
        }.start()
    }
    private fun updateWeatherText() {
        val city = prefs.getString("city", null)
        if (city == null) { wxIcon.visibility = View.GONE; weatherText.text = "Konum seç"; return }
        val wx = prefs.getString("wx", null)
        if (wx == null) { wxIcon.visibility = View.GONE; weatherText.text = city }
        else { val p = wx.split("|"); val code = if (p.size > 2) (p[2].toIntOrNull() ?: 3) else 3; wxIcon.setKind(wxKind(code)); wxIcon.visibility = View.VISIBLE; weatherText.text = city + " · " + p[0] + " " + (if (p.size > 1) p[1] else "") }
    }
    private fun showWeatherDetail() {
        val full = prefs.getString("wxfull", null); val city = prefs.getString("city", null) ?: return
        if (full == null) { fetchWeather(); Toast.makeText(this, "Hava durumu yükleniyor…", Toast.LENGTH_SHORT).show(); return }
        val dlg = Dialog(this); dlg.requestWindowFeature(Window.FEATURE_NO_TITLE); val box = panelBox()
        try {
            val o = JSONObject(full); val cur = o.getJSONObject("current")
            val temp = Math.round(cur.getDouble("temperature_2m")).toInt(); val feels = Math.round(cur.getDouble("apparent_temperature")).toInt()
            val hum = cur.optInt("relative_humidity_2m", 0); val wind = Math.round(cur.optDouble("wind_speed_10m", 0.0)).toInt(); val code = cur.getInt("weather_code")
            val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            head.addView(WxIconView(this, wxKind(code)), LinearLayout.LayoutParams(dp(46), dp(46)).apply { setMargins(0, 0, dp(14), 0) })
            val hc = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            hc.addView(TextView(this).apply { text = city; textSize = 15f; setTextColor(Color.parseColor("#C9C9D3")) })
            hc.addView(TextView(this).apply { text = "$temp°  ·  " + wxText(code); textSize = 26f; typeface = Typeface.create("sans-serif-light", Typeface.NORMAL); setTextColor(Color.WHITE) })
            head.addView(hc); box.addView(head, LinearLayout.LayoutParams(matchP, wrap).apply { setMargins(dp(8), dp(2), dp(8), dp(10)) })
            val stats = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            fun stat(t: String, v: String): View { val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
                col.addView(TextView(this).apply { text = v; textSize = 16f; setTextColor(Color.WHITE); gravity = Gravity.CENTER })
                col.addView(TextView(this).apply { text = t; textSize = 11f; setTextColor(Color.parseColor("#9A9AA6")); gravity = Gravity.CENTER }); return col }
            stats.addView(stat("Hissedilen", "$feels°"), LinearLayout.LayoutParams(0, wrap, 1f))
            stats.addView(stat("Nem", "%$hum"), LinearLayout.LayoutParams(0, wrap, 1f))
            stats.addView(stat("Rüzgar", "$wind km/s"), LinearLayout.LayoutParams(0, wrap, 1f))
            box.addView(stats, LinearLayout.LayoutParams(matchP, wrap).apply { setMargins(0, dp(4), 0, dp(12)) })
            box.addView(View(this).apply { setBackgroundColor(Color.argb(35, 255, 255, 255)) }, LinearLayout.LayoutParams(matchP, dp(1)).apply { setMargins(0, 0, 0, dp(8)) })
            val daily = o.getJSONObject("daily"); val days = daily.getJSONArray("time"); val wc = daily.getJSONArray("weather_code")
            val tmax = daily.getJSONArray("temperature_2m_max"); val tmin = daily.getJSONArray("temperature_2m_min"); val pprob = daily.getJSONArray("precipitation_probability_max")
            val dayFmt = SimpleDateFormat("EEE", Locale("tr", "TR")); val parse = SimpleDateFormat("yyyy-MM-dd", Locale.US)
            for (i in 0 until days.length()) {
                val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(8), dp(7), dp(8), dp(7)) }
                val dayName = if (i == 0) "Bugün" else try { dayFmt.format(parse.parse(days.getString(i))!!) } catch (_: Exception) { days.getString(i) }
                row.addView(TextView(this).apply { text = dayName; textSize = 14f; setTextColor(Color.WHITE) }, LinearLayout.LayoutParams(0, wrap, 1.1f))
                row.addView(WxIconView(this, wxKind(wc.getInt(i))), LinearLayout.LayoutParams(dp(22), dp(22)))
                val rain = pprob.optInt(i, 0)
                row.addView(TextView(this).apply { text = if (rain > 0) "  %$rain" else "   "; textSize = 12.5f; setTextColor(Color.parseColor("#8FC1FF")) }, LinearLayout.LayoutParams(0, wrap, 0.7f))
                row.addView(TextView(this).apply { text = Math.round(tmax.getDouble(i)).toInt().toString() + "°  " + Math.round(tmin.getDouble(i)).toInt() + "°"; textSize = 14f; setTextColor(Color.parseColor("#D0D0DA")); gravity = Gravity.END }, LinearLayout.LayoutParams(0, wrap, 1f))
                box.addView(row)
            }
        } catch (_: Exception) { box.addView(TextView(this).apply { text = "Hava durumu okunamadı"; setTextColor(Color.WHITE); textSize = 15f }) }
        box.addView(footView("Geri: kapat")); dlg.setContentView(box); styleWindow(dlg, 330); registerDialog(dlg); dlg.show()
    }

    // ---------- Güncelleme ----------
    private fun verGreater(remote: String, local: String): Boolean {
        val a = remote.removePrefix("v").split(".").map { it.toIntOrNull() ?: 0 }; val b = local.removePrefix("v").split(".").map { it.toIntOrNull() ?: 0 }
        for (i in 0 until maxOf(a.size, b.size)) { val x = a.getOrElse(i) { 0 }; val y = b.getOrElse(i) { 0 }; if (x != y) return x > y }; return false
    }
    private fun checkUpdate() {
        Toast.makeText(this, "Güncelleme denetleniyor…", Toast.LENGTH_SHORT).show()
        Thread {
            try {
                val url = "https://api.github.com/repos/$GH_OWNER/$GH_REPO/releases/latest"
                val conn = URL(url).openConnection() as HttpURLConnection; conn.connectTimeout = 9000; conn.readTimeout = 9000
                conn.setRequestProperty("Accept", "application/vnd.github+json")
                val txt = conn.inputStream.bufferedReader().use { it.readText() }; val o = JSONObject(txt)
                val tag = o.optString("tag_name", ""); var apk: String? = null
                val assets = o.optJSONArray("assets"); if (assets != null) for (i in 0 until assets.length()) { val a = assets.getJSONObject(i); if (a.optString("name").endsWith(".apk")) { apk = a.optString("browser_download_url"); break } }
                handler.post {
                    if (tag.isEmpty() || apk == null) Toast.makeText(this, "Yayınlanmış sürüm bulunamadı", Toast.LENGTH_LONG).show()
                    else if (!verGreater(tag, VERSION)) Toast.makeText(this, "Zaten güncel (sürüm $VERSION)", Toast.LENGTH_LONG).show()
                    else confirmUpdate(tag, apk!!)
                }
            } catch (e: Exception) { handler.post { Toast.makeText(this, "Güncelleme denetlenemedi (internet?)", Toast.LENGTH_LONG).show() } }
        }.start()
    }
    private fun confirmUpdate(tag: String, apkUrl: String) {
        showPanel("Yeni sürüm: $tag", listOf(PItem("İndir ve kur", GlyphView.DOWNLOAD, "#3FA27A"), PItem("Vazgeç", GlyphView.INFO, "#6F7684")), -1, null, false) { w -> if (w == 0) downloadAndInstall(apkUrl) }
    }
    private fun downloadAndInstall(apkUrl: String) {
        Toast.makeText(this, "İndiriliyor…", Toast.LENGTH_SHORT).show()
        Thread {
            try {
                val out = File(getExternalFilesDir(null) ?: filesDir, "update.apk")
                val conn = URL(apkUrl).openConnection() as HttpURLConnection; conn.connectTimeout = 15000; conn.readTimeout = 30000; conn.instanceFollowRedirects = true
                conn.inputStream.use { input -> FileOutputStream(out).use { input.copyTo(it) } }
                handler.post { installApk(out) }
            } catch (e: Exception) { handler.post { Toast.makeText(this, "İndirme başarısız", Toast.LENGTH_LONG).show() } }
        }.start()
    }
    private fun installApk(file: File) {
        try {
            if (android.os.Build.VERSION.SDK_INT >= 26 && !packageManager.canRequestPackageInstalls()) {
                Toast.makeText(this, "Kurulum için izin verin, sonra tekrar deneyin", Toast.LENGTH_LONG).show()
                try { startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
                return
            }
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
            startActivity(Intent(Intent.ACTION_VIEW).apply { setDataAndType(uri, "application/vnd.android.package-archive"); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK) })
        } catch (e: Exception) { Toast.makeText(this, "Kurulum açılamadı", Toast.LENGTH_LONG).show() }
    }

    // ---------- Sistem ----------
    private fun openSystem(action: String) {
        try { startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        catch (e: Exception) { try { startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {} }
    }
    @Suppress("DEPRECATION")
    private fun updateWifi() {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        wifiIcon.setColorFilter(if (cm.activeNetworkInfo?.isConnected == true) Color.WHITE else Color.parseColor("#7A8594"), PorterDuff.Mode.SRC_IN)
    }

    // ---------- Kutular ----------
    private fun tile(app: AppItem): View {
        val bg = GradientDrawable().apply { cornerRadius = dp(16).toFloat(); setColor(Color.parseColor("#2B2B40")) }
        val frame = FrameLayout(this).apply { background = bg; isFocusable = true; clipToOutline = true; elevation = dp(3).toFloat(); alpha = 0.9f; tag = app.pkg }
        val img = ImageView(this).apply {
            setImageDrawable(app.image)
            if (app.isBanner) scaleType = ImageView.ScaleType.CENTER_CROP
            else { scaleType = ImageView.ScaleType.FIT_CENTER; setPadding(dp(tileW / 7), dp(tileH / 6), dp(tileW / 7), dp(tileH / 6)) }
        }
        frame.addView(img, FrameLayout.LayoutParams(matchP, matchP))
        frame.setOnFocusChangeListener { v, hasFocus ->
            if (hasFocus) {
                lastPkg = app.pkg
                v.animate().scaleX(focusScale).scaleY(focusScale).alpha(1f).translationZ(dp(18).toFloat()).setDuration(140).start()
                bg.setStroke(dp(3), if (movingPkg == app.pkg) Color.parseColor("#FF9F0A") else Color.WHITE)
            } else { v.animate().scaleX(1f).scaleY(1f).alpha(0.9f).translationZ(0f).setDuration(140).start(); bg.setStroke(0, Color.TRANSPARENT) }
        }
        frame.setOnClickListener { try { startActivity(Intent(Intent.ACTION_MAIN).setClassName(app.pkg, app.cls).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {} }
        frame.setOnLongClickListener { showMenu(app); true }
        frame.setOnKeyListener { view, k, e -> edgeKeys(view, k, e) }
        frame.layoutParams = LinearLayout.LayoutParams(dp(tileW), dp(tileH)).apply { setMargins(0, 0, dp(tileGap), 0) }
        return frame
    }
    private fun hiddenTile(): View {
        val bg = glass(16, 90)
        val frame = FrameLayout(this).apply { background = bg; isFocusable = true; tag = "__hidden__" }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        box.addView(GlyphView(this, GlyphView.EYE_OFF), LinearLayout.LayoutParams(dp(24), dp(24)))
        box.addView(TextView(this).apply { text = "Gizlenenler (" + hiddenApps.size + ")"; textSize = 12f; setTextColor(Color.WHITE); gravity = Gravity.CENTER })
        frame.addView(box, FrameLayout.LayoutParams(matchP, matchP))
        frame.setOnFocusChangeListener { v, hasFocus ->
            if (hasFocus) { v.animate().scaleX(focusScale).scaleY(focusScale).setDuration(140).start(); bg.setStroke(dp(3), Color.WHITE) }
            else { v.animate().scaleX(1f).scaleY(1f).setDuration(140).start(); bg.setStroke(dp(1), Color.argb(55, 255, 255, 255)) }
        }
        frame.setOnClickListener { showHidden() }
        frame.setOnKeyListener { view, k, e -> edgeKeys(view, k, e) }
        frame.layoutParams = LinearLayout.LayoutParams(dp(tileW), dp(tileH)).apply { setMargins(0, 0, dp(tileGap), 0) }
        return frame
    }

    // Satır kenarlarında atlamayı engelle; ilk satırda yukarı → dişli
    private fun edgeKeys(view: View, keyCode: Int, event: KeyEvent): Boolean {
        if (event.action != KeyEvent.ACTION_DOWN) return false
        val row = view.parent as? ViewGroup ?: return false
        val idx = row.indexOfChild(view)
        if (keyCode == KeyEvent.KEYCODE_DPAD_RIGHT && idx == row.childCount - 1) return true
        if (keyCode == KeyEvent.KEYCODE_DPAD_LEFT && idx == 0) return true
        if (keyCode == KeyEvent.KEYCODE_DPAD_UP && grid.indexOfChild(row) == 0) { gearView?.requestFocus(); return true }
        return false
    }
}

// Küçük çizim simgeleri
class GlyphView(context: Context, private val kind: Int) : View(context) {
    companion object {
        const val GRID = 0; const val PALETTE = 1; const val CLOUD = 2; const val RESET = 3; const val MOVE = 4
        const val EYE_OFF = 5; const val TRASH = 6; const val INFO = 7; const val CHECK = 8; const val CHEVRON = 9
        const val SLIDERS = 10; const val USER = 11; const val BROOM = 12; const val MONITOR = 13; const val DOWNLOAD = 14
        const val GEAR = 15; const val IMAGE = 16
    }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }
    fun setTint(c: Int) { p.color = c; invalidate() }
    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat(); val cx = w / 2f; val cy = height / 2f; p.strokeWidth = w * 0.085f; p.style = Paint.Style.STROKE
        when (kind) {
            GRID -> { p.style = Paint.Style.FILL; val s = w * 0.2f; val g = w * 0.07f
                for (i in 0..1) for (j in 0..1) { val l = cx - g / 2 - s + i * (s + g); val t = cy - g / 2 - s + j * (s + g); canvas.drawRoundRect(RectF(l, t, l + s, t + s), w * 0.04f, w * 0.04f, p) } }
            PALETTE -> { canvas.drawCircle(cx, cy, w * 0.29f, p); p.style = Paint.Style.FILL
                canvas.drawCircle(cx - w * 0.10f, cy - w * 0.07f, w * 0.045f, p); canvas.drawCircle(cx + w * 0.07f, cy - w * 0.12f, w * 0.045f, p); canvas.drawCircle(cx + w * 0.14f, cy + w * 0.05f, w * 0.045f, p); canvas.drawCircle(cx - w * 0.04f, cy + w * 0.10f, w * 0.045f, p) }
            CLOUD -> { p.style = Paint.Style.FILL; canvas.drawCircle(cx - w * 0.13f, cy + w * 0.04f, w * 0.13f, p); canvas.drawCircle(cx + w * 0.02f, cy - w * 0.05f, w * 0.17f, p); canvas.drawCircle(cx + w * 0.16f, cy + w * 0.05f, w * 0.12f, p); canvas.drawRoundRect(RectF(cx - w * 0.24f, cy + w * 0.04f, cx + w * 0.27f, cy + w * 0.17f), w * 0.06f, w * 0.06f, p) }
            RESET -> { val r = w * 0.26f; canvas.drawArc(RectF(cx - r, cy - r, cx + r, cy + r), -40f, 270f, false, p)
                val ang = Math.toRadians(230.0); val px = cx + (r * Math.cos(ang)).toFloat(); val py = cy + (r * Math.sin(ang)).toFloat(); val nx = Math.cos(ang).toFloat(); val ny = Math.sin(ang).toFloat()
                val path = Path(); path.moveTo(px - ny * w * 0.13f, py + nx * w * 0.13f); path.lineTo(px + nx * w * 0.10f, py + ny * w * 0.10f); path.lineTo(px - nx * w * 0.10f, py - ny * w * 0.10f); path.close(); p.style = Paint.Style.FILL; canvas.drawPath(path, p) }
            MOVE -> { val a = w * 0.28f; val h = w * 0.12f; canvas.drawLine(cx - a, cy, cx + a, cy, p); canvas.drawLine(cx, cy - a, cx, cy + a, p)
                canvas.drawLine(cx - a, cy, cx - a + h, cy - h, p); canvas.drawLine(cx - a, cy, cx - a + h, cy + h, p); canvas.drawLine(cx + a, cy, cx + a - h, cy - h, p); canvas.drawLine(cx + a, cy, cx + a - h, cy + h, p)
                canvas.drawLine(cx, cy - a, cx - h, cy - a + h, p); canvas.drawLine(cx, cy - a, cx + h, cy - a + h, p); canvas.drawLine(cx, cy + a, cx - h, cy + a - h, p); canvas.drawLine(cx, cy + a, cx + h, cy + a - h, p) }
            EYE_OFF -> { canvas.drawOval(RectF(cx - w * 0.3f, cy - w * 0.17f, cx + w * 0.3f, cy + w * 0.17f), p); p.style = Paint.Style.FILL; canvas.drawCircle(cx, cy, w * 0.07f, p); p.style = Paint.Style.STROKE; canvas.drawLine(cx - w * 0.27f, cy + w * 0.27f, cx + w * 0.27f, cy - w * 0.27f, p) }
            TRASH -> { canvas.drawLine(cx - w * 0.25f, cy - w * 0.16f, cx + w * 0.25f, cy - w * 0.16f, p); canvas.drawLine(cx - w * 0.08f, cy - w * 0.25f, cx + w * 0.08f, cy - w * 0.25f, p)
                canvas.drawRoundRect(RectF(cx - w * 0.18f, cy - w * 0.16f, cx + w * 0.18f, cy + w * 0.28f), w * 0.05f, w * 0.05f, p); canvas.drawLine(cx - w * 0.05f, cy - w * 0.06f, cx - w * 0.05f, cy + w * 0.18f, p); canvas.drawLine(cx + w * 0.05f, cy - w * 0.06f, cx + w * 0.05f, cy + w * 0.18f, p) }
            INFO -> { canvas.drawCircle(cx, cy, w * 0.3f, p); p.style = Paint.Style.FILL; canvas.drawCircle(cx, cy - w * 0.11f, w * 0.04f, p); p.style = Paint.Style.STROKE; canvas.drawLine(cx, cy - w * 0.03f, cx, cy + w * 0.15f, p) }
            CHECK -> { val path = Path(); path.moveTo(cx - w * 0.2f, cy); path.lineTo(cx - w * 0.05f, cy + w * 0.15f); path.lineTo(cx + w * 0.22f, cy - w * 0.14f); canvas.drawPath(path, p) }
            CHEVRON -> { val path = Path(); path.moveTo(cx - w * 0.08f, cy - w * 0.2f); path.lineTo(cx + w * 0.1f, cy); path.lineTo(cx - w * 0.08f, cy + w * 0.2f); canvas.drawPath(path, p) }
            SLIDERS -> { canvas.drawLine(cx - w * 0.3f, cy - w * 0.14f, cx + w * 0.3f, cy - w * 0.14f, p); canvas.drawLine(cx - w * 0.3f, cy + w * 0.14f, cx + w * 0.3f, cy + w * 0.14f, p); p.style = Paint.Style.FILL; canvas.drawCircle(cx - w * 0.1f, cy - w * 0.14f, w * 0.085f, p); canvas.drawCircle(cx + w * 0.12f, cy + w * 0.14f, w * 0.085f, p) }
            USER -> { p.style = Paint.Style.FILL; canvas.drawCircle(cx, cy - w * 0.1f, w * 0.11f, p); p.style = Paint.Style.STROKE; canvas.drawArc(RectF(cx - w * 0.22f, cy + w * 0.04f, cx + w * 0.22f, cy + w * 0.46f), 180f, 180f, false, p) }
            BROOM -> { canvas.drawLine(cx + w * 0.22f, cy - w * 0.28f, cx - w * 0.04f, cy + w * 0.06f, p)
                val path = Path(); path.moveTo(cx - w * 0.16f, cy - w * 0.02f); path.lineTo(cx + w * 0.08f, cy + w * 0.16f); path.lineTo(cx - w * 0.06f, cy + w * 0.3f); path.lineTo(cx - w * 0.28f, cy + w * 0.12f); path.close(); p.style = Paint.Style.FILL; canvas.drawPath(path, p); p.style = Paint.Style.STROKE; canvas.drawLine(cx - w * 0.18f, cy + w * 0.14f, cx - w * 0.1f, cy + w * 0.22f, p) }
            MONITOR -> { canvas.drawRoundRect(RectF(cx - w * 0.3f, cy - w * 0.24f, cx + w * 0.3f, cy + w * 0.12f), w * 0.04f, w * 0.04f, p); canvas.drawLine(cx - w * 0.12f, cy + w * 0.26f, cx + w * 0.12f, cy + w * 0.26f, p); canvas.drawLine(cx, cy + w * 0.12f, cx, cy + w * 0.26f, p) }
            DOWNLOAD -> { canvas.drawLine(cx, cy - w * 0.26f, cx, cy + w * 0.12f, p); val path = Path(); path.moveTo(cx - w * 0.14f, cy - w * 0.04f); path.lineTo(cx, cy + w * 0.14f); path.lineTo(cx + w * 0.14f, cy - w * 0.04f); canvas.drawPath(path, p); canvas.drawLine(cx - w * 0.22f, cy + w * 0.26f, cx + w * 0.22f, cy + w * 0.26f, p) }
            GEAR -> { canvas.drawCircle(cx, cy, w * 0.12f, p); val rr = w * 0.26f
                for (i in 0 until 8) { val a = Math.toRadians(i * 45.0); val cs = Math.cos(a).toFloat(); val sn = Math.sin(a).toFloat(); canvas.drawLine(cx + cs * w * 0.19f, cy + sn * w * 0.19f, cx + cs * rr, cy + sn * rr, p) } }
            IMAGE -> { canvas.drawRoundRect(RectF(cx - w * 0.3f, cy - w * 0.24f, cx + w * 0.3f, cy + w * 0.24f), w * 0.05f, w * 0.05f, p); p.style = Paint.Style.FILL; canvas.drawCircle(cx - w * 0.12f, cy - w * 0.08f, w * 0.05f, p); p.style = Paint.Style.STROKE
                val path = Path(); path.moveTo(cx - w * 0.26f, cy + w * 0.16f); path.lineTo(cx - w * 0.06f, cy - w * 0.04f); path.lineTo(cx + w * 0.1f, cy + w * 0.12f); path.lineTo(cx + w * 0.18f, cy + w * 0.04f); path.lineTo(cx + w * 0.28f, cy + w * 0.16f); canvas.drawPath(path, p) }
            else -> {}
        }
    }
}

// Hava durumu simgeleri
class WxIconView(context: Context, private var kind: Int) : View(context) {
    companion object { const val SUN = 0; const val MOON = 1; const val PARTLY = 2; const val CLOUD = 3; const val RAIN = 4; const val SNOW = 5; const val STORM = 6; const val FOG = 7 }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }
    fun setKind(k: Int) { kind = k; invalidate() }
    private fun cloud(c: Canvas, cx: Float, cy: Float, s: Float, color: Int) { p.style = Paint.Style.FILL; p.color = color
        c.drawCircle(cx - 0.22f * s, cy + 0.06f * s, 0.2f * s, p); c.drawCircle(cx + 0.02f * s, cy - 0.06f * s, 0.26f * s, p); c.drawCircle(cx + 0.26f * s, cy + 0.07f * s, 0.18f * s, p); c.drawRoundRect(RectF(cx - 0.42f * s, cy + 0.06f * s, cx + 0.44f * s, cy + 0.26f * s), 0.1f * s, 0.1f * s, p) }
    private fun sun(c: Canvas, cx: Float, cy: Float, r: Float) { p.color = Color.parseColor("#FFD27A"); p.style = Paint.Style.FILL; c.drawCircle(cx, cy, r, p); p.style = Paint.Style.STROKE; p.strokeWidth = r * 0.35f
        for (i in 0 until 8) { val a = Math.toRadians(i * 45.0); val cs = Math.cos(a).toFloat(); val sn = Math.sin(a).toFloat(); c.drawLine(cx + cs * r * 1.5f, cy + sn * r * 1.5f, cx + cs * r * 1.95f, cy + sn * r * 1.95f, p) } }
    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat(); val cx = w / 2f; val cy = height / 2f; val white = Color.parseColor("#E8EBF2")
        when (kind) {
            SUN -> sun(canvas, cx, cy, w * 0.2f)
            MOON -> { val a = Path(); a.addCircle(cx, cy, w * 0.3f, Path.Direction.CW); val b = Path(); b.addCircle(cx + w * 0.15f, cy - w * 0.1f, w * 0.26f, Path.Direction.CW); a.op(b, Path.Op.DIFFERENCE); p.style = Paint.Style.FILL; p.color = white; canvas.drawPath(a, p) }
            PARTLY -> { sun(canvas, cx + w * 0.16f, cy - w * 0.16f, w * 0.12f); cloud(canvas, cx - w * 0.04f, cy + w * 0.08f, w * 0.85f, white) }
            CLOUD -> cloud(canvas, cx, cy, w * 0.95f, white)
            RAIN -> { cloud(canvas, cx, cy - w * 0.12f, w * 0.9f, white); p.style = Paint.Style.STROKE; p.color = Color.parseColor("#8FC1FF"); p.strokeWidth = w * 0.07f; for (i in 0..2) { val x = cx - w * 0.2f + i * w * 0.2f; canvas.drawLine(x, cy + w * 0.22f, x - w * 0.05f, cy + w * 0.36f, p) } }
            SNOW -> { cloud(canvas, cx, cy - w * 0.12f, w * 0.9f, white); p.style = Paint.Style.FILL; p.color = Color.WHITE; for (i in 0..2) canvas.drawCircle(cx - w * 0.2f + i * w * 0.2f, cy + w * 0.3f, w * 0.045f, p) }
            STORM -> { cloud(canvas, cx, cy - w * 0.14f, w * 0.9f, Color.parseColor("#B4BCC9")); val b = Path(); b.moveTo(cx + w * 0.06f, cy + w * 0.1f); b.lineTo(cx - w * 0.08f, cy + w * 0.3f); b.lineTo(cx, cy + w * 0.3f); b.lineTo(cx - w * 0.06f, cy + w * 0.46f); b.lineTo(cx + w * 0.14f, cy + w * 0.2f); b.lineTo(cx + w * 0.05f, cy + w * 0.2f); b.close(); p.style = Paint.Style.FILL; p.color = Color.parseColor("#FFD27A"); canvas.drawPath(b, p) }
            FOG -> { p.style = Paint.Style.STROKE; p.color = Color.parseColor("#C5CAD6"); p.strokeWidth = w * 0.08f; canvas.drawLine(cx - w * 0.3f, cy - w * 0.16f, cx + w * 0.3f, cy - w * 0.16f, p); canvas.drawLine(cx - w * 0.22f, cy, cx + w * 0.34f, cy, p); canvas.drawLine(cx - w * 0.3f, cy + w * 0.16f, cx + w * 0.22f, cy + w * 0.16f, p) }
            else -> {}
        }
    }
}
