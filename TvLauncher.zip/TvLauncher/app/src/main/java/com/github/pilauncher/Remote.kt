package com.github.pilauncher

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import java.io.DataInputStream
import java.io.File
import java.io.InputStream
import java.io.OutputStream
import java.math.BigInteger
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.KeyFactory
import java.security.KeyPairGenerator
import java.security.MessageDigest
import java.security.SecureRandom
import java.security.Signature
import java.security.interfaces.RSAPrivateCrtKey
import java.security.spec.PKCS8EncodedKeySpec

// ---------- Telefon İle Yönet ----------
// Telefon, TV'deki QR kodu okutunca açılan sayfadan TV'yi kumanda eder. Tuşların gittiği yollar:
// - Erişilebilirlik servisi (PiAccess): yön/OK/Geri/Home — anında.
// - ADB (AdbLink): kanal ve sesli arama tuşları. Android bu tuşları başka hiçbir yoldan göndertmiyor; uygulama TV'nin
//   ağ üzerinden hata ayıklama bağlantısına (5555) TV'nin içinden bağlanıp "input keyevent" çalıştırır (yaklaşık yarım saniye).
// - Ses: doğrudan ses ayarı.
// Not: Google'ın TV'deki kumanda servisi (6466) denendi; eşleştirme başarılı olsa da servis, TV'nin kendi içinden gelen
// bağlantıları hiç cevap vermeden kapatıyor (dışarıdan gelen aynı bağlantıyı kabul ediyor). Bu yüzden kullanılamıyor.
// Oturum: her QR yeni bir anahtar üretir; TV kapanana (ekran kapanana) ya da yeni QR açılana kadar geçerlidir.

/** Erişilebilirlik servisi: sistemin hazır "genel eylem"lerini (yön tuşları, Geri, Home) tetikler ve telefondan yazılan
 *  metni ekranda seçili olan yazı kutusuna koyar. Ekrandaki başka hiçbir içerik okunmaz, saklanmaz. */
class PiAccess : android.accessibilityservice.AccessibilityService() {
    companion object { @Volatile var inst: PiAccess? = null }
    override fun onServiceConnected() { inst = this }
    override fun onUnbind(intent: Intent?): Boolean { inst = null; return super.onUnbind(intent) }
    override fun onDestroy() { inst = null; super.onDestroy() }
    override fun onAccessibilityEvent(event: android.view.accessibility.AccessibilityEvent?) {}
    private fun field(): android.view.accessibility.AccessibilityNodeInfo? = try {
        (findFocus(android.view.accessibility.AccessibilityNodeInfo.FOCUS_INPUT) ?: rootInActiveWindow?.findFocus(android.view.accessibility.AccessibilityNodeInfo.FOCUS_INPUT))?.takeIf { it.isEditable } } catch (_: Exception) { null }
    /** Seçili yazı kutusunun içeriğini değiştirir (Türkçe harfler dahil her yazı). Seçili bir yazı kutusu yoksa false. */
    fun setText(t: String): Boolean { val n = field() ?: return false
        return try {
            val ok = n.performAction(android.view.accessibility.AccessibilityNodeInfo.ACTION_SET_TEXT, android.os.Bundle().apply { putCharSequence(android.view.accessibility.AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, t) })
            if (ok) n.performAction(android.view.accessibility.AccessibilityNodeInfo.ACTION_SET_SELECTION, android.os.Bundle().apply {
                putInt(android.view.accessibility.AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_START_INT, t.length); putInt(android.view.accessibility.AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_END_INT, t.length) })
            ok } catch (_: Exception) { false } }
    /** Seçili yazı kutusunda klavyenin "Ara / Bitti" eylemini yapar (Android 11+). */
    fun imeEnter(): Boolean { if (Build.VERSION.SDK_INT < 30) return false; val n = field() ?: return false
        return try { n.performAction(android.R.id.accessibilityActionImeEnter) } catch (_: Exception) { false } }
    override fun onInterrupt() {}
}

/** ADB kimliği: imza ve açık anahtarın ADB'nin beklediği biçimi (Android'e bağlı değildir, ayrıca sınanabilir). */
object AdbKey {
    private val SHA1_PREFIX = byteArrayOf(0x30, 0x21, 0x30, 0x09, 0x06, 0x05, 0x2b, 0x0e, 0x03, 0x02, 0x1a, 0x05, 0x00, 0x04, 0x14)
    fun generate(): ByteArray = KeyPairGenerator.getInstance("RSA").apply { initialize(2048) }.generateKeyPair().private.encoded
    fun load(pkcs8: ByteArray): RSAPrivateCrtKey = KeyFactory.getInstance("RSA").generatePrivate(PKCS8EncodedKeySpec(pkcs8)) as RSAPrivateCrtKey
    /** TV'nin gönderdiği 20 baytlık jetonun imzası (jeton, SHA-1 özeti yerine konur) */
    fun sign(k: RSAPrivateCrtKey, token: ByteArray): ByteArray = Signature.getInstance("NONEwithRSA").apply { initSign(k); update(SHA1_PREFIX + token) }.sign()
    private fun le(n: BigInteger, len: Int): ByteArray { val be = n.toByteArray(); val o = ByteArray(len)
        for (i in 0 until minOf(len, be.size)) o[i] = be[be.size - 1 - i]; return o }
    /** Açık anahtar: [kelime sayısı][-1/n mod 2^32][n, küçük uçlu][R^2 mod n, küçük uçlu][üs] -> base64 + " ad" */
    fun publicKey(k: RSAPrivateCrtKey): ByteArray {
        val n = k.modulus; val r32 = BigInteger.ONE.shiftLeft(32)
        val n0inv = r32.subtract(n.mod(r32).modInverse(r32))
        val rr = BigInteger.ONE.shiftLeft(2048).modPow(BigInteger.valueOf(2), n)
        val b = ByteBuffer.allocate(524).order(ByteOrder.LITTLE_ENDIAN)
        b.putInt(64); b.putInt(n0inv.toInt()); b.put(le(n, 256)); b.put(le(rr, 256)); b.putInt(k.publicExponent.toInt())
        return (java.util.Base64.getEncoder().encodeToString(b.array()) + " PiLauncher@tv").toByteArray() + byteArrayOf(0)
    }
}

/** TV'nin kendi ADB servisine (127.0.0.1:5555) bağlanıp kabuk komutu çalıştırır. */
object AdbLink {
    private const val CNXN = 0x4e584e43; private const val AUTH = 0x48545541; private const val OPEN = 0x4e45504f
    private const val OKAY = 0x59414b4f; private const val CLSE = 0x45534c43; private const val WRTE = 0x45545257
    /** off, connecting, need (TV'de izin gerekli), auth (izin penceresi açık), ok, err */
    @Volatile var state = "off"; private set
    @Volatile var msg = ""; private set
    @Volatile private var sock: Socket? = null
    private var out: OutputStream? = null
    private val wLock = Any()
    @Volatile private var gen = 0
    private var nextId = 1
    private var key: RSAPrivateCrtKey? = null
    private fun log(t: String) = android.util.Log.w("PiLauncher", "adb: $t")
    private fun send(cmd: Int, a0: Int, a1: Int, data: ByteArray = ByteArray(0)) = synchronized(wLock) {
        val o = out ?: throw java.io.IOException("kapalı")
        var sum = 0; for (x in data) sum += x.toInt() and 255
        val h = ByteBuffer.allocate(24).order(ByteOrder.LITTLE_ENDIAN)
        h.putInt(cmd); h.putInt(a0); h.putInt(a1); h.putInt(data.size); h.putInt(sum); h.putInt(cmd.inv())
        o.write(h.array()); if (data.isNotEmpty()) o.write(data); o.flush() }
    fun close() { gen++; try { sock?.close() } catch (_: Exception) {}; sock = null; out = null; state = "off"; msg = "" }
    /** prompt = false: TV'de izin penceresi açtırmaz (izin yoksa "need" durumuna geçer). prompt = true: izin penceresini açtırır. */
    @Synchronized fun connect(ctx: Context, prompt: Boolean) {
        if (state == "ok" || state == "connecting" || (state == "auth" && prompt)) return
        try { sock?.close() } catch (_: Exception) {}
        val g = ++gen; state = "connecting"; msg = ""
        Thread {
            try {
                val k = key ?: run { val f = File(ctx.filesDir, "adb_key.p8"); if (!f.exists()) f.writeBytes(AdbKey.generate()); AdbKey.load(f.readBytes()).also { key = it } }
                val s = Socket(); s.connect(InetSocketAddress("127.0.0.1", 5555), 3000); s.tcpNoDelay = true
                sock = s; out = s.getOutputStream(); val inp = DataInputStream(s.getInputStream())
                send(CNXN, 0x01000000, 4096, "host::\u0000".toByteArray())
                var signed = false; val hb = ByteArray(24)
                while (g == gen) {
                    inp.readFully(hb); val h = ByteBuffer.wrap(hb).order(ByteOrder.LITTLE_ENDIAN)
                    val cmd = h.int; val a0 = h.int; val a1 = h.int; val len = h.int
                    if (len < 0 || len > 1 shl 20) throw java.io.IOException("uzunluk")
                    val data = ByteArray(len); inp.readFully(data)
                    when (cmd) {
                        AUTH -> if (a0 == 1) {
                            if (!signed) { signed = true; send(AUTH, 2, 0, AdbKey.sign(k, data)) }
                            else if (prompt) { state = "auth"; send(AUTH, 3, 0, AdbKey.publicKey(k)); log("TV'de izin bekleniyor") }
                            else { state = "need"; log("izin gerekli"); try { s.close() } catch (_: Exception) {}; return@Thread } }
                        CNXN -> { state = "ok"; log("bağlandı") }
                        WRTE -> send(OKAY, a1, a0)
                        CLSE -> if (a0 != 0) send(CLSE, a1, a0)
                        else -> {}
                    }
                }
            } catch (e: java.net.ConnectException) { if (g == gen) { state = "err"; msg = "ADB kapalı" }; log("5555 kapalı")
            } catch (e: Exception) { log("koptu " + e.javaClass.simpleName + " " + (e.message ?: ""))
                if (g == gen) { if (state == "auth") { state = "need"; msg = "izin verilmedi" } else if (state != "need") { state = if (state == "ok") "off" else "err"; msg = e.javaClass.simpleName } } }
        }.start()
    }
    /** Kabuk komutu çalıştırır (çıktısı okunmaz). Bağlı değilse false. */
    fun shell(cmd: String): Boolean {
        if (state != "ok") return false
        return try { val id = synchronized(wLock) { nextId = if (nextId >= 1 shl 30) 1 else nextId + 1; nextId }
            send(OPEN, id, 0, ("shell:$cmd\u0000").toByteArray()); true } catch (e: Exception) { log("gönderilemedi " + e.javaClass.simpleName); try { sock?.close() } catch (_: Exception) {}; false }
    }
}

object RemoteHub {
    @Volatile var token = ""; private set
    @Volatile var port = 0; private set
    @Volatile var lastVia = ""; private set
    /** PiLauncher ekranda mı (başka uygulamadayken arka plandan uygulama açma kısıtı için) */
    @Volatile var foreground = false
    /** PiLauncher'ın kendi yazı kutusu açıksa (Konum Ara, Fotoğraf Ara) telefondan yazılan doğrudan ona gider.
     *  mode: 0 = yazıyı koy, 1 = onayla (Enter) */
    @Volatile var textSink: ((String?, Int) -> Unit)? = null
    /** OK tuşuna uzun basış, PiLauncher ekrandayken: seçili öğenin uzun basma işlemi (kutuda Seçenekler, galeride favori). */
    @Volatile var longOk: (() -> Unit)? = null
    @Volatile private var gen = 0
    private var app: Context? = null
    private var server: ServerSocket? = null
    private var pool: java.util.concurrent.ExecutorService? = null
    private var screenRx: BroadcastReceiver? = null
    private val main = Handler(Looper.getMainLooper())
    private fun log(t: String) = android.util.Log.w("PiLauncher", "kumanda: $t")

    /** Yeni oturum (yeni anahtar). Önceki oturum kapanır. */
    @Synchronized fun start(ctx: Context): Boolean {
        stop(); app = ctx.applicationContext
        return try {
            token = ByteArray(16).also { SecureRandom().nextBytes(it) }.joinToString("") { "%02x".format(it) }
            val s = ServerSocket(0); server = s; port = s.localPort; val g = ++gen
            val p = java.util.concurrent.Executors.newFixedThreadPool(4); pool = p
            Thread { while (g == gen) { val c = try { s.accept() } catch (_: Exception) { break }
                try { p.execute { handle(c) } } catch (_: Exception) { try { c.close() } catch (_: Exception) {} } } }.start()
            if (screenRx == null) { val rx = object : BroadcastReceiver() { override fun onReceive(c: Context?, i: Intent?) { stop() } }
                try { app!!.registerReceiver(rx, IntentFilter(Intent.ACTION_SCREEN_OFF)); screenRx = rx } catch (_: Exception) {} }
            // Önceki denemelerden kalan dosyalar
            try { for (n in listOf("remote_key.p8", "remote_cert.der", "remote_key2.p8", "remote_cert2.der")) File(app!!.filesDir, n).delete() } catch (_: Exception) {}
            // ADB: izin daha önce verildiyse sessizce bağlanır; verilmediyse pencere açtırmaz (QR'ın üstünü kapatmasın), telefondan istenir
            AdbLink.connect(app!!, false)
            true
        } catch (e: Exception) { log("sunucu açılamadı " + e.javaClass.simpleName); false }
    }
    @Synchronized fun stop() {
        gen++; token = ""
        try { server?.close() } catch (_: Exception) {}; server = null
        try { pool?.shutdownNow() } catch (_: Exception) {}; pool = null
        AdbLink.close()
    }

    // ---------- Tuşlar ----------
    private val keyCodes = mapOf("up" to 19, "down" to 20, "left" to 21, "right" to 22, "ok" to 23, "back" to 4, "home" to 3,
        "volup" to 24, "voldown" to 25, "mute" to 164, "chup" to 166, "chdown" to 167, "voice" to 84, "enter" to 66, "oklong" to 23,
        "n0" to 7, "n1" to 8, "n2" to 9, "n3" to 10, "n4" to 11, "n5" to 12, "n6" to 13, "n7" to 14, "n8" to 15, "n9" to 16)
    // Erişilebilirlik genel eylemleri (yön tuşları Android 13+)
    private val accActions = mapOf("back" to 1, "home" to 2, "up" to 16, "down" to 17, "left" to 18, "right" to 19, "ok" to 20)
    private fun adbReady(): Boolean {
        if (AdbLink.state == "ok") return true
        if (AdbLink.state == "off" || AdbLink.state == "err") { AdbLink.connect(app!!, false)   // kopmuşsa sessizce yeniden bağlan, kısa süre bekle
            val t = android.os.SystemClock.uptimeMillis(); while (android.os.SystemClock.uptimeMillis() - t < 1500 && AdbLink.state == "connecting") Thread.sleep(40) }
        return AdbLink.state == "ok"
    }
    /** Dönen: hangi yoldan gitti (a = erişilebilirlik, s = ses ayarı, d = ADB, none = gönderilemedi) */
    private fun key(name: String): String {
        val code = keyCodes[name] ?: return "none"
        val sink = textSink
        if (sink != null && name == "enter") { sink(null, 1); return "a" }
        if (name == "oklong") {   // uzun basış: PiLauncher'da doğrudan; başka uygulamalarda ADB ile (erişilebilirlikte uzun basış yok)
            val h = longOk; if (foreground && h != null) { main.post { try { h() } catch (_: Exception) {} }; return "a" }
            return if (adbReady() && AdbLink.shell("input keyevent --longpress 23")) "d" else key("ok") }
        if (name == "enter") { adbTyped = ""; if (PiAccess.inst?.imeEnter() == true) return "a" }
        val acc = PiAccess.inst; val act = accActions[name]
        if (acc != null && act != null && (act < 16 || Build.VERSION.SDK_INT >= 33)) { main.post { try { acc.performGlobalAction(act) } catch (_: Exception) {} }; return "a" }
        if (name == "volup" || name == "voldown" || name == "mute") { try {
            val am = app!!.getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager
            am.adjustStreamVolume(android.media.AudioManager.STREAM_MUSIC, when (name) { "volup" -> android.media.AudioManager.ADJUST_RAISE; "voldown" -> android.media.AudioManager.ADJUST_LOWER
                else -> if (Build.VERSION.SDK_INT >= 23) android.media.AudioManager.ADJUST_TOGGLE_MUTE else android.media.AudioManager.ADJUST_SAME }, android.media.AudioManager.FLAG_SHOW_UI)
            return "s" } catch (_: Exception) {} }
        if (adbReady() && AdbLink.shell("input keyevent $code")) return "d"
        return "none"
    }

    // ---------- Klavye ----------
    // Telefondaki kutuya yazılan her şey anında TV'ye yansır (kutunun tamamı gönderilir). Sırayla denenir:
    // 1) PiLauncher'ın kendi yazı kutusu açıksa doğrudan ona.
    // 2) Ekranda seçili bir yazı kutusu varsa erişilebilirlik servisiyle içeriği değiştirilir: Türkçe harfler dahil, anında.
    // 3) Yazı kutusu olmayan, kendi klavyesini çizen uygulamalarda (ör. YouTube) ADB ile tuş olarak yazılır: yalnızca temel
    //    Latin harfleri yazılabildiği için Türkçe harfler karşılıklarına çevrilir; önceki gönderime göre yalnız fark yazılır/silinir.
    private var adbTyped = ""
    private val typeQ by lazy { java.util.concurrent.Executors.newSingleThreadExecutor() }
    private fun plain(t: String): String { val sb = StringBuilder()
        for (ch in t) { val c = when (ch) { 'ç' -> 'c'; 'Ç' -> 'C'; 'ğ' -> 'g'; 'Ğ' -> 'G'; 'ı' -> 'i'; 'İ' -> 'I'; 'ö' -> 'o'; 'Ö' -> 'O'; 'ş' -> 's'; 'Ş' -> 'S'; 'ü' -> 'u'; 'Ü' -> 'U'; else -> ch }
            if (c.code in 32..126) sb.append(c) }
        return sb.toString() }
    @Synchronized private fun text(t: String): String {
        val sink = textSink
        if (sink != null) { sink(t, 0); return "a" }
        if (PiAccess.inst?.setText(t) == true) { adbTyped = ""; return "a" }
        val p = plain(t); val prev = adbTyped
        var c = 0; while (c < prev.length && c < p.length && prev[c] == p[c]) c++
        val dels = minOf(prev.length - c, 80); val add = p.substring(c)
        if (dels == 0 && add.isEmpty()) return "d"
        if (!adbReady()) return "none"
        adbTyped = p
        // "input text": boşluk %s ile yazılır; kabuk için tek tırnak içine alınır
        val cmd = (if (dels > 0) "input keyevent" + " 67".repeat(dels) else "") + (if (dels > 0 && add.isNotEmpty()) "; " else "") +
            (if (add.isNotEmpty()) "input text '" + add.replace(" ", "%s").replace("'", "'\\''") + "'" else "")
        typeQ.execute { AdbLink.shell(cmd); try { Thread.sleep(350) } catch (_: Exception) {} }   // komutlar sırayla çalışsın
        return "d"
    }

    // ---------- Uygulamalar (ana ekranın açılış önbelleğinden: liste ve afişler) ----------
    private fun cacheDir() = File(app!!.filesDir, "appcache")
    private fun appList(): List<Array<String>> = try {
        val prefs = app!!.getSharedPreferences("launcher", Context.MODE_PRIVATE)
        val hidden = prefs.getStringSet("hidden", emptySet()) ?: emptySet()
        val order = (prefs.getString("order", "") ?: "").split("|").filter { it.isNotEmpty() }
        File(cacheDir(), "list.txt").readLines().map { it.split("\t") }.filter { it.size >= 4 && it[0] !in hidden }
            .sortedWith(compareBy({ val i = order.indexOf(it[0]); if (i >= 0) i else 100000 }, { it[2].lowercase() })).map { arrayOf(it[0], it[1], it[2], it[3]) }
    } catch (_: Exception) { emptyList() }
    private val safeName = Regex("[A-Za-z0-9._$]+")
    private fun openApp(pkg: String): String {
        val a = appList().firstOrNull { it[0] == pkg } ?: return "none"
        // Başka bir uygulama açıkken Android arka plandan uygulama açtırmaz (erişilebilirlik servisi açıksa açtırır); o durumda ADB ile açılır
        if (!foreground && PiAccess.inst == null && safeName.matches(a[0]) && safeName.matches(a[1]) && adbReady() && AdbLink.shell("am start -n '" + a[0] + "/" + a[1] + "'")) return "d"
        return try { app!!.startActivity(Intent(Intent.ACTION_MAIN).setClassName(a[0], a[1]).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); "a" } catch (_: Exception) { "none" }
    }

    // ---------- Telefonun bağlandığı küçük web sunucusu (yalnız ev ağı, yalnız geçerli anahtarla) ----------
    private fun readLine(i: InputStream): String? { val sb = StringBuilder()
        while (true) { val b = i.read(); if (b < 0) return if (sb.isEmpty()) null else sb.toString(); if (b == '\n'.code) break; if (b != '\r'.code) sb.append(b.toChar()); if (sb.length > 8192) return null }
        return sb.toString() }
    private fun respond(o: OutputStream, code: Int, type: String, body: ByteArray, cache: Boolean = false) {
        o.write(("HTTP/1.1 $code " + (if (code == 200) "OK" else "Error") + "\r\nContent-Type: $type\r\nContent-Length: ${body.size}\r\nCache-Control: " + (if (cache) "max-age=3600" else "no-store") + "\r\nConnection: close\r\n\r\n").toByteArray())
        o.write(body); o.flush() }
    private fun handle(sock: Socket) { try { sock.use { c ->
        c.soTimeout = 15000
        val a = c.inetAddress; val out = c.getOutputStream()
        if (!(a.isSiteLocalAddress || a.isLinkLocalAddress || a.isLoopbackAddress)) { respond(out, 403, "text/plain", "forbidden".toByteArray()); return }
        val inp = java.io.BufferedInputStream(c.getInputStream())
        val first = readLine(inp) ?: return; val parts = first.split(" "); if (parts.size < 2) return
        while (true) { val h = readLine(inp) ?: return; if (h.isEmpty()) break }
        val path = parts[1].substringBefore("?")
        val q = parts[1].substringAfter("?", "").split("&").mapNotNull { val kv = it.split("=", limit = 2); if (kv.size == 2) kv[0] to (try { java.net.URLDecoder.decode(kv[1], "UTF-8") } catch (_: Exception) { "" }) else null }.toMap()
        val tk = token
        if (tk.isEmpty() || !MessageDigest.isEqual((q["k"] ?: "").toByteArray(), tk.toByteArray())) {
            respond(out, 403, "text/html; charset=utf-8", "<meta name=viewport content='width=device-width'><p style='font:18px sans-serif;padding:24px'>Bu bağlantının süresi doldu. TV'de Ayarlar › Telefon İle Yönet'ten yeni QR kodu okut.</p>".toByteArray()); return }
        when (path) {
            "/" -> respond(out, 200, "text/html; charset=utf-8", PAGE.toByteArray())
            "/state" -> respond(out, 200, "application/json", JSONObject().put("d", AdbLink.state).put("m", AdbLink.msg).put("a", PiAccess.inst != null).put("v", lastVia).toString().toByteArray())
            "/apps" -> { val arr = JSONArray(); for (x in appList()) arr.put(JSONObject().put("p", x[0]).put("n", x[2]).put("b", x[3] == "1")); respond(out, 200, "application/json; charset=utf-8", arr.toString().toByteArray()) }
            "/icon" -> { val p = (q["p"] ?: "").replace(Regex("[^A-Za-z0-9._]"), ""); val f = File(cacheDir(), "$p.png")
                if (p.isNotEmpty() && f.exists()) respond(out, 200, "image/png", f.readBytes(), true) else respond(out, 404, "text/plain", "yok".toByteArray()) }
            "/text" -> { val v = if (q["reset"] == "1") { adbTyped = ""; "a" } else text(q["t"] ?: ""); lastVia = v; respond(out, 200, "text/plain", v.toByteArray()) }
            "/key" -> { val v = key(q["c"] ?: ""); lastVia = v; respond(out, 200, "text/plain", v.toByteArray()) }
            "/open" -> { val v = openApp(q["p"] ?: ""); respond(out, 200, "text/plain", v.toByteArray()) }
            "/adbstart" -> { AdbLink.connect(app!!, true); respond(out, 200, "text/plain", "ok".toByteArray()) }
            else -> respond(out, 404, "text/plain", "not found".toByteArray())
        }
    } } catch (_: Exception) {} }

    private val PAGE = """<!doctype html><html lang="tr"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no,viewport-fit=cover">
<meta name="theme-color" content="#1c1c1e"><title>Kumanda</title>
<style>
*{box-sizing:border-box;touch-action:manipulation;-webkit-tap-highlight-color:transparent;-webkit-user-select:none;user-select:none;-webkit-touch-callout:none}
html,body{margin:0;background:#1c1c1e;color:#fff;font:15px -apple-system,system-ui,Roboto,sans-serif;overscroll-behavior:none}
body{padding:10px 18px calc(12px + env(safe-area-inset-bottom));max-width:460px;margin:0 auto}
button{font:inherit;color:#fff;border:0;background:none;padding:0;margin:0}
.box{display:none;background:#2c2c2e;border-radius:16px;padding:14px;margin-bottom:12px;text-align:center}
.box p{margin:0;color:#d1d1d6;font-size:14px;line-height:1.4}
.act{margin-top:10px;font-weight:600;font-size:16px;background:#0a84ff;border-radius:10px;padding:11px 18px}
#apps{display:flex;gap:10px;overflow-x:auto;padding:2px 0 10px;scrollbar-width:none}#apps::-webkit-scrollbar{display:none}
.app{flex:0 0 auto;width:96px;text-align:center;font-size:11.5px;color:#e5e5ea}
.app div{width:96px;height:54px;border-radius:11px;background:#2c2c2e;margin-bottom:4px;overflow:hidden}
.app:active div{opacity:.6}
.app img{width:100%;height:100%;object-fit:cover;display:block}.app img.ic{object-fit:contain;padding:7px}
.app span{display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.pad{position:relative;width:min(70vw,44vh,300px);height:min(70vw,44vh,300px);margin:4px auto 16px;border-radius:50%;background:linear-gradient(#333336,#242426);box-shadow:0 0 0 2px #5e5ce6 inset}
.pad button{position:absolute;width:34%;height:34%;display:flex;align-items:center;justify-content:center;border-radius:50%}
.on{background:rgba(255,255,255,.16)!important}
#up{top:0;left:33%}#down{bottom:0;left:33%}#left{left:0;top:33%}#right{right:0;top:33%}
#ok{top:35%;left:35%;width:30%;height:30%;background:#333336;box-shadow:0 0 0 2px #5e5ce6 inset,0 4px 10px rgba(0,0,0,.4)}
.row{display:grid;grid-template-columns:64px 1fr 64px;gap:12px}
.pill{border-radius:32px;background:#2f2f31;display:flex;flex-direction:column;align-items:center;overflow:hidden}
.pill button{width:100%;flex:1;font-size:28px;display:flex;align-items:center;justify-content:center}
.pill span{font-size:12px;letter-spacing:1px;color:#d1d1d6}
.mid{display:grid;grid-template-columns:repeat(3,1fr);gap:12px}
.b{aspect-ratio:1;border-radius:50%;background:#2f2f31;display:flex;align-items:center;justify-content:center}
svg{width:42%;height:42%;fill:none;stroke:#fff;stroke-width:2;stroke-linecap:round;stroke-linejoin:round;pointer-events:none}
.pad svg{width:30%;height:30%;stroke-width:2.4}.pill svg{width:26px;height:26px}
#kb{text-align:left}#kt{width:100%;font:17px inherit;background:#1c1c1e;color:#fff;border:1px solid #48484a;border-radius:10px;padding:10px 12px;-webkit-user-select:text;user-select:text}
.r{display:flex;gap:8px;margin-top:10px}.r button{flex:1;margin:0;padding:11px 4px;font-size:15px;font-weight:600;border-radius:10px;background:#48484a}.r .act{background:#0a84ff}
#np{padding:12px}.ng{display:grid;grid-template-columns:repeat(3,1fr);gap:8px}.ng button{height:46px;border-radius:12px;background:#48484a;font-size:20px}.ng .x{font-size:14px;background:none;color:#d1d1d6}
#diag{margin-top:12px;text-align:center;font-size:12px;color:#ff9f0a;line-height:1.5;min-height:18px}
#hl{position:fixed;left:-99px;top:0;opacity:0;pointer-events:none}
</style></head><body>
<label id="hl"><input type="checkbox" switch></label>
<div id="apps"></div>
<div id="need" class="box"><p>Kanal ve sesli arama tuşları için TV'de bir kez izin vermen gerekiyor.</p><button class="act" id="nb">İzin iste</button></div>
<div id="auth" class="box"><p>TV'de bir pencere açıldı: <b>"Bu bilgisayardan her zaman izin ver"</b> kutusunu işaretle, sonra <b>İzin ver</b>'e bas. Aşağıdaki yön tuşlarını kullanabilirsin.</p></div>
<div id="kb" class="box"><input id="kt" type="text" placeholder="Yaz, TV'de anında görünür" autocomplete="off" autocorrect="off" autocapitalize="none" spellcheck="false" enterkeyhint="search">
<div class="r"><button class="act" id="ke">Enter</button><button id="kx">Kapat</button></div></div>
<div id="np" class="box"><div class="ng"><button data-k="n1">1</button><button data-k="n2">2</button><button data-k="n3">3</button><button data-k="n4">4</button><button data-k="n5">5</button><button data-k="n6">6</button><button data-k="n7">7</button><button data-k="n8">8</button><button data-k="n9">9</button><button class="x" id="nx">Kapat</button><button data-k="n0">0</button><button class="x" data-k="ok">OK</button></div></div>
<div class="pad">
 <button id="up" data-k="up" data-r="1"><svg viewBox="0 0 24 24"><path d="M5 15l7-7 7 7"/></svg></button>
 <button id="left" data-k="left" data-r="1"><svg viewBox="0 0 24 24"><path d="M15 5l-7 7 7 7"/></svg></button>
 <button id="ok" data-k="ok" data-long="oklong"></button>
 <button id="right" data-k="right" data-r="1"><svg viewBox="0 0 24 24"><path d="M9 5l7 7-7 7"/></svg></button>
 <button id="down" data-k="down" data-r="1"><svg viewBox="0 0 24 24"><path d="M5 9l7 7 7-7"/></svg></button>
</div>
<div class="row">
 <div class="pill"><button data-k="volup" data-r="1"><svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg></button><span>SES</span><button data-k="voldown" data-r="1"><svg viewBox="0 0 24 24"><path d="M5 12h14"/></svg></button></div>
 <div class="mid">
  <button class="b" id="kbb"><svg viewBox="0 0 24 24"><rect x="2.5" y="6" width="19" height="12" rx="2"/><path d="M6 10h.01M10 10h.01M14 10h.01M18 10h.01M6 14h.01M18 14h.01M9.5 14h5"/></svg></button>
  <button class="b" data-k="home"><svg viewBox="0 0 24 24"><path d="M4 11l8-7 8 7v8a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1z"/><path d="M12 16v1"/></svg></button>
  <button class="b" id="npb"><svg viewBox="0 0 24 24" style="stroke-width:3"><path d="M6 5h.01M12 5h.01M18 5h.01M6 10h.01M12 10h.01M18 10h.01M6 15h.01M12 15h.01M18 15h.01M12 20h.01"/></svg></button>
  <button class="b" data-k="mute"><svg viewBox="0 0 24 24"><path d="M4 9v6h4l5 4V5L8 9z"/><path d="M17 9l4 6M21 9l-4 6"/></svg></button>
  <button class="b" data-k="voice"><svg viewBox="0 0 24 24"><rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/></svg></button>
  <button class="b" data-k="back"><svg viewBox="0 0 24 24"><path d="M8 5L4 9l4 4"/><path d="M4 9h11a5 5 0 0 1 0 10H9"/></svg></button>
 </div>
 <div class="pill"><button data-k="chup" data-r="1"><svg viewBox="0 0 24 24"><path d="M5 15l7-7 7 7"/></svg></button><span>KANAL</span><button data-k="chdown" data-r="1"><svg viewBox="0 0 24 24"><path d="M5 9l7 7 7-7"/></svg></button></div>
</div>
<div id="diag"></div>
<script>
var K=new URLSearchParams(location.search).get('k')||'';
function u(p){return p+(p.indexOf('?')<0?'?':'&')+'k='+K}
function post(p){return fetch(u(p),{method:'POST'}).then(function(r){return r.text()})}
function el(i){return document.getElementById(i)}
// Dokunma geri bildirimi: Android'de titreşim; iPhone'da (titreşim desteği yok) gizli bir anahtarın değişmesi sistemin kısa tıkını verir
var hl=el('hl');
function haptic(){try{if(navigator.vibrate)navigator.vibrate(10);else hl.click()}catch(e){}}
var st={},fail='',down=false;
function send(k){post('/key?c='+k).then(function(t){fail=t=='none'?'Bu tuş gönderilemedi':'';draw()}).catch(function(){down=true;draw()})}
function draw(){var s=st.d||'';
 el('need').style.display=s=='need'?'block':'none';el('auth').style.display=s=='auth'?'block':'none';
 var t='';
 if(down)t='TV\'ye ulaşılamıyor · TV\'de yeni QR kodu okut';
 else if(st.a===false)t='Yön tuşları için erişilebilirlik izni gerekli';
 else if(s=='err')t='Kanal ve sesli arama kullanılamıyor ('+(st.m||'ADB')+')';
 else if(fail)t=fail;
 el('diag').textContent=t}
function poll(){fetch(u('/state')).then(function(r){if(r.status!=200)throw 0;return r.json()}).then(function(j){st=j;down=false;draw()}).catch(function(){down=true;draw()})}
setInterval(poll,2500);poll();
// Tuşlar: dokununca hemen gider. data-r: basılı tutunca tekrarlar. data-long: basılı tutunca uzun basış, bırakınca kısa basış.
Array.prototype.forEach.call(document.querySelectorAll('[data-k]'),function(b){
 var tm=null,iv=null,held=false,act=false;
 function end(fire){if(!act)return;act=false;clearTimeout(tm);clearInterval(iv);b.classList.remove('on');if(fire&&b.getAttribute('data-long')&&!held)send(b.getAttribute('data-k'))}
 b.addEventListener('pointerdown',function(e){e.preventDefault();act=true;held=false;b.classList.add('on');haptic();var k=b.getAttribute('data-k'),lg=b.getAttribute('data-long');
  if(lg)tm=setTimeout(function(){held=true;haptic();send(lg)},450);
  else{send(k);if(b.getAttribute('data-r'))tm=setTimeout(function(){iv=setInterval(function(){send(k)},140)},420)}});
 b.addEventListener('pointerup',function(){end(true)});
 ['pointercancel','pointerleave'].forEach(function(n){b.addEventListener(n,function(){end(false)})});
 b.addEventListener('contextmenu',function(e){e.preventDefault()})});
el('nb').onclick=function(){haptic();post('/adbstart').then(function(){setTimeout(poll,500)})};
// Klavye: kutudaki yazı her değiştiğinde tamamı gönderilir; gönderimler sırayla yapılır, arada yazılanlar birikir
var kb=el('kb'),kt=el('kt'),np=el('np'),sentT='',busy=false;
el('kbb').onclick=function(){haptic();np.style.display='none';kt.value='';sentT='';post('/text?reset=1');kb.style.display='block';window.scrollTo(0,0);kt.focus()};
el('kx').onclick=function(){kb.style.display='none';kt.blur()};
function pump(){if(busy)return;var t=kt.value;if(t==sentT)return;busy=true;
 post('/text?t='+encodeURIComponent(t)).then(function(v){sentT=t;busy=false;fail=v=='none'?'Yazı gönderilemedi':'';draw();pump()}).catch(function(){busy=false;down=true;draw()})}
kt.addEventListener('input',pump);
function enter(){haptic();send('enter');kt.value='';sentT=''}
kt.addEventListener('keydown',function(e){if(e.key=='Enter'){e.preventDefault();enter()}});
el('ke').onclick=enter;
el('npb').onclick=function(){haptic();kb.style.display='none';kt.blur();np.style.display=np.style.display=='block'?'none':'block';window.scrollTo(0,0)};
el('nx').onclick=function(){np.style.display='none'};
// Safari'nin çift dokunmayla yakınlaştırmasını ve parmakla büyütmeyi engelle
var lt=0;document.addEventListener('touchend',function(e){var n=Date.now();if(n-lt<350&&e.target.tagName!='INPUT')e.preventDefault();lt=n},{passive:false});
document.addEventListener('dblclick',function(e){e.preventDefault()});
document.addEventListener('gesturestart',function(e){e.preventDefault()});
fetch(u('/apps')).then(function(r){return r.json()}).then(function(l){var h=el('apps');
 l.forEach(function(a){var e=document.createElement('div');e.className='app';var bx=document.createElement('div'),im=document.createElement('img');
  im.src=u('/icon?p='+encodeURIComponent(a.p));if(!a.b)im.className='ic';bx.appendChild(im);var s=document.createElement('span');s.textContent=a.n;
  e.appendChild(bx);e.appendChild(s);e.onclick=function(){haptic();post('/open?p='+encodeURIComponent(a.p))};h.appendChild(e)})});
</script></body></html>"""
}
