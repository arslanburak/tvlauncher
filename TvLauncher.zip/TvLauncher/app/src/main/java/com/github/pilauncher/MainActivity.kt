package com.github.pilauncher

import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.RenderEffect
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.ConnectivityManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

// PiLauncher — hafif, Apple TV'den esinlenen Android TV ana ekranı.
class MainActivity : Activity() {

    companion object {
        const val VERSION = "1.0.1"
    }

    private data class AppItem(val pkg: String, val cls: String, val label: String, val image: Drawable, val isBanner: Boolean, val upd: Long = 0L)
    private class City(val name: String, val lat: String, val lon: String, val il: String = "", val ilce: String = "")
    // adjust: satırdayken ◀ ▶ ile değeri yerinde bir adım değiştirir; yeni alt yazıyı döndürür (uçtaysa null)
    private class PItem(val label: String, val glyph: Int = -1, val tint: String = "#5B6B8C", val sub: String? = null,
                        val arrow: Boolean = false, val image: Drawable? = null, val toggle: Boolean? = null, val adjust: ((Int) -> String?)? = null)

    private val pinned = listOf(
        "com.netflix.ninja", "com.google.android.youtube.tv", "com.amazon.amazonvideo.livingroom",
        "com.disney.disneyplus", "com.wbd.stream", "com.apple.atve.androidtv.appletv", "com.ttnet.tivibutv", "com.beonetv.tod"
    )

    // ---- ayarlanabilir değerler ----
    private val gapValues = intArrayOf(16, 24, 34)
    private val tileGap: Int get() = gapValues[prefs.getInt("gap", 1).coerceIn(0, 2)]
    private val gridPad = 64
    // Panellerdeki kaydırıcı/odak vurgusu: sistem mavisi
    private fun accent() = Color.parseColor("#0A84FF")
    private val radiusDps = intArrayOf(8, 14, 20)
    private fun tileRadiusPx(): Float { val i = prefs.getInt("radius", 1).coerceIn(0, 3); return if (i == 3) dp(tileH / 2).toFloat() else dp(radiusDps[i]).toFloat() }
    // Kutu saydamlığı: seçili olmayan kutu (afişiyle birlikte) bu oranda saydamlaşır, arka plan içinden görünür.
    // Seçili kutu her zaman tam görünür. Simgeli (afişsiz) kutuların zemini de aynı oranda incelir.
    private val tileRestAlphas = floatArrayOf(0.92f, 0.7f, 0.48f)
    private fun tileRestAlpha() = tileRestAlphas[prefs.getInt("tileAlpha", 0).coerceIn(0, 2)]
    private val tileAlphas = intArrayOf(255, 190, 130)
    private fun tileBgAlpha() = tileAlphas[prefs.getInt("tileAlpha", 0).coerceIn(0, 2)]
    private val zooms = floatArrayOf(1.12f, 1.22f, 1.32f)
    private fun focusZoom() = zooms[prefs.getInt("zoom", 1).coerceIn(0, 2)]
    // Kutunun seçilince büyüme süresi (ms): Hızlı / Normal / Yavaş
    private val animDurs = longArrayOf(90, 170, 300)
    private fun animDur() = animDurs[prefs.getInt("anim", 1).coerceIn(0, 2)]
    private val blurValues = intArrayOf(0, 12, 25, 42)
    private val scrimFr = floatArrayOf(0f, 0.4f, 0.72f, 1f)

    // Kutu boyutu kaydırmalı: genişlik (dp) doğrudan ayarlanır, sütun sayısı ondan hesaplanır
    private val sizeMin = 100; private val sizeMax = 260; private val sizeStep = 8
    private fun screenWdp(): Int = (resources.displayMetrics.widthPixels / resources.displayMetrics.density).toInt()
    private val tileW: Int
        get() { val def = prefs.getInt("cols", 0).let { c -> if (c > 0) (screenWdp() - 2 * gridPad) / c - tileGap else 140 }
            return prefs.getInt("tileW", def).coerceIn(sizeMin, sizeMax) }
    private fun colsFor(w: Int): Int = maxOf(1, (screenWdp() - 2 * gridPad) / (w + tileGap))
    private val cols: Int get() = colsFor(tileW)
    private val tileH: Int get() = tileW * 84 / 150

    private fun cc(vararg h: String): IntArray = IntArray(h.size) { Color.parseColor(h[it]) }
    private val bgPresets: List<Pair<String, IntArray?>> = listOf(
        Pair("Gümüş Sis", null),
        Pair("Gece Mavisi", cc("#0C1220", "#101A2E", "#2B3C5A", "#1A2740", "#223256")),
        Pair("Okyanus", cc("#0A1518", "#0E2026", "#1C4A52", "#123138", "#174249")),
        Pair("Orman", cc("#0D1410", "#121D16", "#2B4536", "#1B3023", "#24402F")),
        Pair("Gün Batımı", cc("#160E12", "#241219", "#5A2E3C", "#3C1E28", "#4E2734")),
        Pair("Mor Sis", cc("#100D18", "#171426", "#3C3658", "#2A2440", "#352E52")),
        Pair("Kömür", cc("#141518", "#191A1E", "#303238", "#232428", "#2A2C31")),
        Pair("Gece Yarısı", cc("#0B0D12", "#0E1016", "#13161D", "#15181F", "#181C24"))
    )

    private val matchP = ViewGroup.LayoutParams.MATCH_PARENT
    private val wrap = ViewGroup.LayoutParams.WRAP_CONTENT

    private lateinit var prefs: SharedPreferences
    private lateinit var root: FrameLayout
    private lateinit var clock: TextView
    private lateinit var date: TextView
    private lateinit var weatherText: TextView
    private lateinit var wxIcon: WxIconView
    private lateinit var wifiIcon: NetView
    private lateinit var hintView: TextView
    private lateinit var topPill: LinearLayout
    private lateinit var grid: LinearLayout
    private lateinit var gridScroll: ScrollView
    private lateinit var gridBox: FrameLayout
    private lateinit var upHint: GlyphView
    private lateinit var downHint: GlyphView
    private var rowCount = 0
    private var visibleRows = 1
    private var firstRow = 0
    private lateinit var bgView: ImageView
    private lateinit var scrimView: View
    private lateinit var bgInfoView: TextView
    private lateinit var tintA: View
    private lateinit var tintB: View
    private var tintFront = false
    private var tintColor: Int? = null
    private var tintGen = 0
    private var wifiBtnView: View? = null
    private var gearView: View? = null
    private var weatherBoxView: View? = null
    private var barAlertDot: View? = null

    private val handler = Handler(Looper.getMainLooper())
    private var shown = mutableListOf<AppItem>()
    private var hiddenApps = listOf<AppItem>()
    private var movingPkg: String? = null
    private var lastPkg: String? = null
    private var lastWeather = 0L
    private var saverView: View? = null
    private var saverClock: TextView? = null
    private val openDialogs = mutableListOf<Dialog>()

    private val tick = object : Runnable {
        override fun run() {
            val now = Date()
            setClockText(clock, SimpleDateFormat("HH:mm", Locale.getDefault()).format(now))
            date.text = SimpleDateFormat("d MMMM, EEEE", Locale("tr", "TR")).format(now); fitText(date)
            updateWifi()
            if (saverView != null) updateSaverInfo()
            // Açılışın ilk 3 saniyesinde ağ işi yapılmaz: ekran önce çizilsin (hava durumu hemen ardından gelir)
            if (android.os.SystemClock.uptimeMillis() - createdAt > 3000) {
                if (prefs.getBoolean("saver", true) && prefs.getInt("saverBg", 0) == 0) fetchBing()
                if (System.currentTimeMillis() - lastWeather > wxEveryMs()) { lastWeather = System.currentTimeMillis(); fetchWeather() } }
            // Bir sonraki tetiklenme: dakikanın döndüğü an (+50 ms) ya da en geç 15 sn sonra -> saat hiçbir zaman geride kalmaz
            val toMinute = 60_000L - (System.currentTimeMillis() % 60_000L) + 50L
            handler.postDelayed(this, minOf(15_000L, toMinute))
        }
    }
    // Müzik çalarken (ör. YouTube Music arka planda) ekran koruyucu açılmaz; müzik bitince süre baştan işlemeye başlar
    private var musicHold = false
    private val createdAt = android.os.SystemClock.uptimeMillis()
    private val saverRunnable: Runnable = object : Runnable { override fun run() {
        val playing = try { (getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager).isMusicActive } catch (_: Exception) { false }
        if (playing) { musicHold = true; handler.postDelayed(this, 30_000); return }
        if (musicHold) { musicHold = false; resetSaverTimer(); return }
        showSaver() } }
    // Dakika değişince rakamlar bir anda değil, kısa bir solma geçişiyle değişir
    private fun setClockText(tv: TextView, t: String) {
        val old = tv.text?.toString() ?: ""
        if (old.isEmpty() || old == t || tv.tag == t) { if (old != t && tv.tag != t) tv.text = t; return }
        tv.tag = t
        animateFrames(160, { p -> tv.alpha = 1f - p }, { tv.text = t; tv.tag = null; animateFrames(240, { p -> tv.alpha = p }) })
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
    private fun glass(radiusDp: Int, alpha: Int): GradientDrawable = GradientDrawable().apply { cornerRadius = dp(radiusDp).toFloat(); setColor(Color.argb(alpha, 20, 22, 28)); setStroke(dp(1), Color.argb(55, 255, 255, 255)) }
    // ---------- Tema: Koyu / Açık / Cam ----------
    private val themeNames = listOf("Koyu", "Açık", "Koyu Cam", "Açık Cam")
    private val themeIdx: Int get() = prefs.getInt("theme", 0).coerceIn(0, 3)
    private val lightTheme: Boolean get() = themeIdx == 1 || themeIdx == 3   // koyu yazılı temalar
    private val glassTheme: Boolean get() = themeIdx >= 2                     // buzlu cam temaları
    private fun cText() = if (lightTheme) Color.BLACK else Color.WHITE
    private fun cSub() = if (lightTheme) Color.parseColor("#4A4A50") else Color.parseColor("#A2A2AD")
    private fun cFoot() = if (lightTheme) Color.parseColor("#66666C") else Color.parseColor("#85858F")
    private fun cDiv() = if (lightTheme) Color.argb(32, 0, 0, 0) else Color.argb(38, 255, 255, 255)
    private fun cFocus() = if (lightTheme) Color.argb(24, 0, 0, 0) else Color.argb(48, 255, 255, 255)
    private fun cFocusStroke() = if (lightTheme) Color.argb(50, 0, 0, 0) else Color.argb(75, 255, 255, 255)
    private fun cField() = if (lightTheme) Color.argb(26, 0, 0, 0) else Color.argb(60, 255, 255, 255)
    private fun cKnob() = if (lightTheme) Color.parseColor("#2C2C2E") else Color.WHITE
    private fun cPill() = if (lightTheme) Color.BLACK else Color.WHITE
    private fun cPillSub() = if (lightTheme) Color.parseColor("#3A3A40") else Color.parseColor("#D0D0DA")
    private fun cPillFocus() = if (lightTheme) Color.argb(34, 0, 0, 0) else Color.argb(90, 255, 255, 255)
    private fun pillBg(): GradientDrawable = GradientDrawable().apply { cornerRadius = dp(28).toFloat()
        when (themeIdx) {
            1 -> { setColor(Color.argb(242, 234, 234, 238)); setStroke(dp(1), Color.argb(40, 0, 0, 0)) }
            2 -> { setColor(Color.argb(70, 40, 44, 54)); setStroke(dp(1), Color.argb(95, 255, 255, 255)) }
            3 -> { setColor(Color.argb(150, 240, 240, 244)); setStroke(dp(1), Color.argb(130, 255, 255, 255)) }
            else -> { setColor(Color.argb(150, 14, 15, 19)); setStroke(dp(1), Color.argb(40, 255, 255, 255)) } } }
    // Yazı boyutu: bütün ayar panellerinde yazı, simge ve çerçeve bu oranla büyür/küçülür
    private val ui: Float get() = prefs.getFloat("uiScale", 1f).coerceIn(0.8f, 1.5f)
    private fun sp(v: Float) = v * ui
    private fun du(v: Int) = dp(Math.round(v * ui))

    private fun glyphBtn(kind: Int, action: () -> Unit): View {
        val bg = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.TRANSPARENT) }
        val g = GlyphView(this, kind).apply { setTint(cPill()) }
        val f = FrameLayout(this).apply { background = bg; isFocusable = true; setPadding(dp(9), dp(9), dp(9), dp(9)); addView(g, FrameLayout.LayoutParams(matchP, matchP)) }
        f.setOnFocusChangeListener { v, has -> if (has) { bg.setColor(cPillFocus()); animView(v, 1.15f, dur = 120) } else { bg.setColor(Color.TRANSPARENT); animView(v, 1f, dur = 120) } }
        f.setOnClickListener { action() }
        f.setOnKeyListener { _, k, e -> if (e.action == KeyEvent.ACTION_DOWN && k == KeyEvent.KEYCODE_DPAD_DOWN) { focusGrid(); true } else false }
        f.layoutParams = LinearLayout.LayoutParams(dp(36), dp(36)).apply { setMargins(dp(2), 0, dp(2), 0) }
        return f
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("launcher", Context.MODE_PRIVATE)
        WxIconView.cloudColor = if (lightTheme) Color.parseColor("#8F99A8") else Color.parseColor("#E8EBF2")
        root = FrameLayout(this); root.setBackgroundColor(Color.parseColor("#141414")); root.clipChildren = false

        bgView = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
        root.addView(bgView, FrameLayout.LayoutParams(matchP, matchP))
        // Dinamik arka plan: seçili uygulamanın rengi iki katman arasında yumuşak geçişle yansır
        tintA = View(this).apply { alpha = 0f }; tintB = View(this).apply { alpha = 0f }
        root.addView(tintA, FrameLayout.LayoutParams(matchP, matchP)); root.addView(tintB, FrameLayout.LayoutParams(matchP, matchP))
        scrimView = View(this).apply { background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(Color.argb(0, 0, 0, 0), Color.argb(210, 0, 0, 0))) }
        root.addView(scrimView, FrameLayout.LayoutParams(matchP, (resources.displayMetrics.heightPixels * 0.6f).toInt(), Gravity.BOTTOM))
        // Fotoğraf bilgisi: arka plan fotoğrafının adı sol alt köşede, silik ve küçük (kutuların altında kalır)
        bgInfoView = TextView(this).apply { textSize = 11.5f; setTextColor(Color.WHITE); alpha = 0.78f; maxLines = 1; maxWidth = resources.displayMetrics.widthPixels / 2
            ellipsize = android.text.TextUtils.TruncateAt.END; setShadowLayer(dp(6).toFloat(), 0f, dp(1).toFloat(), Color.argb(190, 0, 0, 0)); visibility = View.GONE }
        root.addView(bgInfoView, FrameLayout.LayoutParams(wrap, wrap, Gravity.BOTTOM or Gravity.START).apply { setMargins(dp(40), 0, 0, dp(14)) })
        applyBg(); applyScrim()

        grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(gridPad), 0, dp(gridPad), 0); clipChildren = false; clipToPadding = false }
        gridScroll = object : ScrollView(this@MainActivity) {
            // Otomatik kaydırma kapalı: kaydırmayı satır satır biz yapıyoruz (yarım satır görünmesin)
            override fun computeScrollDeltaToGetChildRectOnScreen(rect: android.graphics.Rect): Int = 0
        }.apply { isVerticalScrollBarEnabled = false; clipChildren = false; clipToPadding = false; addView(grid) }
        // Kap: içindeki kaydırma alanını KENDİ sınırında keser -> taşan satırlar üst bara asla çizilmez
        gridBox = FrameLayout(this).apply { clipChildren = true; clipToPadding = true; addView(gridScroll, FrameLayout.LayoutParams(matchP, matchP)) }
        // Izgara ekranın ALTINA sabit; yüksekliği rebuildRows'ta sınırlanır, üst bara asla ulaşmaz
        root.addView(gridBox, FrameLayout.LayoutParams(matchP, dp(200), Gravity.TOP).apply { topMargin = dp(150) })
        upHint = GlyphView(this, GlyphView.CHEVRON).apply { rotation = -90f; setTint(Color.argb(170, 255, 255, 255)); visibility = View.INVISIBLE }
        downHint = GlyphView(this, GlyphView.CHEVRON).apply { rotation = 90f; setTint(Color.argb(170, 255, 255, 255)); visibility = View.INVISIBLE }
        root.addView(upHint, FrameLayout.LayoutParams(dp(22), dp(22), Gravity.TOP or Gravity.CENTER_HORIZONTAL))
        root.addView(downHint, FrameLayout.LayoutParams(dp(22), dp(22), Gravity.TOP or Gravity.CENTER_HORIZONTAL))

        buildTopBar()

        hintView = TextView(this).apply { text = "← → ↑ ↓ ile taşı   ·   Tamam ile bitir"; textSize = 14f; setTextColor(Color.WHITE); background = glass(30, 205); setPadding(dp(22), dp(10), dp(22), dp(10)); visibility = View.GONE }
        root.addView(hintView, FrameLayout.LayoutParams(wrap, wrap, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { setMargins(0, dp(96), 0, 0) })

        setContentView(root)
        root.viewTreeObserver.addOnGlobalFocusChangeListener { _, now -> if (!showGearBtn()) gearView?.visibility = if (inTopBar(now)) View.VISIBLE else View.GONE }
        // Kaldırılan ayarların eski kayıtları (Uygulama sıralaması, Tüm uygulamaları göster, Çerçeve kalınlığı)
        if (prefs.contains("sort") || prefs.contains("showAll") || prefs.contains("frameW")) prefs.edit().remove("sort").remove("showAll").remove("frameW").apply()
        if (prefs.getInt("barPos", 2) == 1) prefs.edit().putInt("barPos", 2).apply()   // kaldırılan "Orta" konumu
        val pf = android.content.IntentFilter().apply { addAction(Intent.ACTION_PACKAGE_ADDED); addAction(Intent.ACTION_PACKAGE_REMOVED); addAction(Intent.ACTION_PACKAGE_CHANGED); addAction(Intent.ACTION_PACKAGE_REPLACED); addDataScheme("package") }
        try { if (Build.VERSION.SDK_INT >= 33) registerReceiver(pkgReceiver, pf, Context.RECEIVER_EXPORTED) else registerReceiver(pkgReceiver, pf) } catch (_: Exception) {}
        watchNetwork()
        handler.postDelayed({ lastWeather = System.currentTimeMillis(); fetchWeather(); if (prefs.getBoolean("saver", true) && prefs.getInt("saverBg", 0) == 0) fetchBing() }, 3100)
        try { registerReceiver(screenReceiver, android.content.IntentFilter(Intent.ACTION_SCREEN_ON)) } catch (_: Exception) {}
    }

    private fun buildTopBar() {
        val timeBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
        clock = TextView(this).apply { textSize = 20f; typeface = Typeface.create("sans-serif-light", Typeface.NORMAL); setTextColor(cPill()); gravity = Gravity.CENTER }
        date = TextView(this).apply { textSize = 11.5f; setTextColor(cPillSub()); gravity = Gravity.CENTER; maxLines = 1 }
        wxIcon = WxIconView(this, WxIconView.CLOUD)
        weatherText = TextView(this).apply { textSize = 11.5f; setTextColor(cPillSub()); maxLines = 1 }
        val wxRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(6), dp(2), dp(6), dp(2)) }
        barAlertDot = View(this).apply { visibility = View.GONE }
        wxRow.addView(barAlertDot, LinearLayout.LayoutParams(dp(7), dp(7)).apply { setMargins(0, 0, dp(5), 0) })
        wxRow.addView(wxIcon, LinearLayout.LayoutParams(dp(15), dp(15)).apply { setMargins(0, 0, dp(5), 0) }); wxRow.addView(weatherText)
        val wxBg = GradientDrawable().apply { cornerRadius = dp(10).toFloat(); setColor(Color.TRANSPARENT) }
        val weatherBox = FrameLayout(this).apply { background = wxBg; isFocusable = true; addView(wxRow) }; weatherBoxView = weatherBox
        weatherBox.setOnFocusChangeListener { _, has -> wxBg.setColor(if (has) cPillFocus() else Color.TRANSPARENT) }
        weatherBox.setOnClickListener { if (prefs.getString("city", null) == null) showCitySearch(null) else showWeatherDetail() }
        weatherBox.setOnKeyListener { _, k, e -> if (e.action == KeyEvent.ACTION_DOWN && k == KeyEvent.KEYCODE_DPAD_DOWN) { focusGrid(); true } else false }
        timeBox.addView(clock, LinearLayout.LayoutParams(wrap, wrap)); timeBox.addView(date, LinearLayout.LayoutParams(wrap, wrap))
        timeBox.addView(weatherBox, LinearLayout.LayoutParams(wrap, wrap).apply { setMargins(0, dp(2), 0, 0) })

        wifiIcon = NetView(this).apply { setPadding(dp(8), dp(8), dp(8), dp(8)) }
        val wifiBtn = FrameLayout(this).apply {
            isFocusable = true
            val bg = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.TRANSPARENT) }; background = bg; addView(wifiIcon, FrameLayout.LayoutParams(matchP, matchP))
            setOnFocusChangeListener { v, has -> if (has) { bg.setColor(cPillFocus()); animView(v, 1.15f, dur = 120) } else { bg.setColor(Color.TRANSPARENT); animView(v, 1f, dur = 120) } }
            setOnClickListener { showNetPanel() }
            setOnKeyListener { _, k, e -> if (e.action == KeyEvent.ACTION_DOWN && k == KeyEvent.KEYCODE_DPAD_DOWN) { focusGrid(); true } else false }
            layoutParams = LinearLayout.LayoutParams(dp(36), dp(36)).apply { setMargins(dp(2), 0, dp(2), 0) }
        }
        wifiBtnView = wifiBtn
        val gearBtn = glyphBtn(GlyphView.GEAR) { openSettingsFresh() }; gearView = gearBtn
        gearBtn.onFocusChangeListener.let { prev -> gearBtn.setOnFocusChangeListener { v, has -> prev?.onFocusChange(v, has); if (has && glassTheme) handler.postDelayed({ frostRoot() }, 140) } }

        topPill = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; background = pillBg(); setPadding(dp(10), dp(4), dp(14), dp(4)); clipChildren = false }
        topPill.addView(wifiBtn); topPill.addView(gearBtn)
        val divider = View(this).apply { setBackgroundColor(pillDiv()) }
        topPill.addView(divider, LinearLayout.LayoutParams(dp(1), dp(30)).apply { setMargins(dp(10), 0, dp(12), 0) })
        topPill.addView(timeBox)
        topPill.addOnLayoutChangeListener { v, _, t, _, b, _, ot, _, ob -> setBarPivot(); if (b - t != ob - ot && ::gridBox.isInitialized) v.post { layoutGrid() } }
        root.addView(topPill, FrameLayout.LayoutParams(wrap, wrap, Gravity.TOP or barGravity()).apply { setMargins(if (barPos() == 0) dp(40) else 0, dp(24), if (barPos() == 2) dp(40) else 0, 0) })
        topPill.addOnLayoutChangeListener { _, l, _, r, _, ol, _, or2, _ -> if (r - l != or2 - ol) refreshPillFrost() }
        buildWxCard()
        applyTopScale(); applyTopItems(); applyWxPanel()
    }

    // ---------- Üst bar konumu (sol / orta / sağ) ----------
    // Kayıtta 0 = Sol, 2 = Sağ ("Orta" kaldırıldı; eski kayıttaki Orta, Sağ sayılır). Hava durumu paneli her zaman karşı köşede durur.
    private val barPosNames = listOf("Sol", "Sağ")
    private fun barPos() = if (prefs.getInt("barPos", 2) == 0) 0 else 2
    private fun barPosName() = barPosNames[if (barPos() == 0) 0 else 1]
    private fun barGravity() = if (barPos() == 0) Gravity.START else Gravity.END
    private fun applyBarPos() {
        (topPill.layoutParams as FrameLayout.LayoutParams).apply { gravity = Gravity.TOP or barGravity(); setMargins(if (barPos() == 0) dp(40) else 0, dp(24), if (barPos() == 2) dp(40) else 0, 0) }
        topPill.requestLayout(); markFrostDirty(); topPill.post { setBarPivot(); refreshPillFrost() }
        positionWxCard()
    }
    // Boyut ölçeği barın bağlı olduğu kenardan büyür/küçülür
    private fun setBarPivot() { topPill.pivotX = if (barPos() == 0) 0f else topPill.width.toFloat(); topPill.pivotY = 0f }
    private fun applyTopItems() {
        // Bağlantı koparsa Wi-Fi düğmesi gizli olsa bile (çarpı işaretiyle) görünür
        wifiBtnView?.visibility = if (showWifiBtn() || !online) View.VISIBLE else View.GONE
        gearView?.let { it.visibility = if (showGearBtn() || it.hasFocus()) View.VISIBLE else View.GONE }
    }
    private fun inTopBar(v: View?): Boolean { var p: Any? = v; while (p is View) { if (p === topPill) return true; p = p.parent }; return false }
    // Ayar düğmesi gizliyse: odak bara gelince belirir, bardan ayrılınca yeniden gizlenir
    private fun revealGear() { val g = gearView ?: return; if (g.visibility != View.VISIBLE) g.visibility = View.VISIBLE; g.requestFocus() }

    // ---------- Hava durumu paneli ----------
    // Üst barın karşı köşesinde, barla aynı cam görünümde: solda simge + sıcaklık + durum · konum, sağda 2x3 ayrıntı.
    // Açıkken bardaki hava durumu satırı gizlenir; kapalıyken bar eskisi gibi hava durumunu gösterir. Basınca 3 günlük tahmin açılır.
    private lateinit var wxCard: LinearLayout
    private lateinit var wxCardIcon: WxIconView
    private lateinit var wxCardTemp: TextView
    private lateinit var wxCardCond: TextView
    private val wxCardVals = ArrayList<TextView>()
    private lateinit var wxCardTomorrow: TextView
    private lateinit var wxCardAlert: LinearLayout
    private lateinit var wxCardAlertDot: View
    private lateinit var wxCardAlertText: TextView
    private fun pillDiv() = if (lightTheme) Color.argb(40, 0, 0, 0) else Color.argb(60, 255, 255, 255)
    private fun wxPanelOn() = prefs.getBoolean("wxPanel", false)
    private fun buildWxCard() {
        val fg = GradientDrawable().apply { cornerRadius = dp(28).toFloat(); setColor(Color.TRANSPARENT) }
        wxCard = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = pillBg(); foreground = fg; isFocusable = true; setPadding(dp(16), dp(8), dp(18), dp(8)) }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val topRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        wxCardIcon = WxIconView(this, WxIconView.CLOUD)
        wxCardTemp = TextView(this).apply { textSize = 26f; typeface = Typeface.create("sans-serif-light", Typeface.NORMAL); setTextColor(cPill()); includeFontPadding = false }
        topRow.addView(wxCardIcon, LinearLayout.LayoutParams(dp(26), dp(26)).apply { setMargins(0, 0, dp(8), 0) }); topRow.addView(wxCardTemp)
        wxCardCond = TextView(this).apply { textSize = 11.5f; setTextColor(cPillSub()); maxLines = 1; maxWidth = dp(150); ellipsize = android.text.TextUtils.TruncateAt.END }
        left.addView(topRow); left.addView(wxCardCond, LinearLayout.LayoutParams(wrap, wrap).apply { setMargins(0, dp(3), 0, 0) })
        top.addView(left)
        top.addView(View(this).apply { setBackgroundColor(pillDiv()) }, LinearLayout.LayoutParams(dp(1), dp(44)).apply { setMargins(dp(14), 0, dp(14), 0) })
        val stats = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val labels = listOf("Hissedilen", "Nem", "Rüzgâr", "Yağış", "Gün doğumu", "Gün batımı")
        wxCardVals.clear()
        for (r in 0 until 3) { val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (c in 0 until 2) { val cell = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; minimumWidth = dp(if (c == 0) 128 else 110) }
                cell.addView(TextView(this).apply { text = labels[r * 2 + c]; textSize = 11f; setTextColor(cPillSub()) })
                val v = TextView(this).apply { text = "—"; textSize = 11.5f; setTextColor(cPill()); typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL) }
                cell.addView(v, LinearLayout.LayoutParams(wrap, wrap).apply { setMargins(dp(6), 0, 0, 0) }); wxCardVals.add(v)
                row.addView(cell) }
            stats.addView(row, LinearLayout.LayoutParams(wrap, wrap).apply { setMargins(0, if (r == 0) 0 else dp(2), 0, 0) }) }
        top.addView(stats)
        wxCard.addView(top)
        // Alt satır: yarının özeti ve (varsa) MGM uyarısı
        wxCard.addView(View(this).apply { setBackgroundColor(pillDiv()) }, LinearLayout.LayoutParams(matchP, dp(1)).apply { setMargins(0, dp(7), 0, dp(6)) })
        val bottom = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        wxCardTomorrow = TextView(this).apply { textSize = 11f; setTextColor(cPillSub()); maxLines = 1; maxWidth = dp(300); ellipsize = android.text.TextUtils.TruncateAt.END }
        bottom.addView(wxCardTomorrow, LinearLayout.LayoutParams(wrap, wrap))
        wxCardAlert = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; visibility = View.GONE }
        wxCardAlertDot = View(this); wxCardAlert.addView(wxCardAlertDot, LinearLayout.LayoutParams(dp(8), dp(8)).apply { setMargins(dp(10), 0, dp(5), 0) })
        wxCardAlertText = TextView(this).apply { textSize = 11f; setTextColor(cPill()); typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL); maxLines = 1 }
        wxCardAlert.addView(wxCardAlertText); bottom.addView(wxCardAlert)
        // Alt satır içeriği kadar yer kaplar (ağırlık verilirse panel bütün ekran genişliğine yayılıp üst barın üstüne biner)
        wxCard.addView(bottom, LinearLayout.LayoutParams(wrap, wrap))
        wxCard.setOnFocusChangeListener { _, has -> fg.setColor(if (has) cPillFocus() else Color.TRANSPARENT) }
        wxCard.setOnClickListener { if (prefs.getString("city", null) == null) showCitySearch(null) else showWeatherDetail(3) }
        wxCard.setOnKeyListener { _, k, e -> if (e.action == KeyEvent.ACTION_DOWN && k == KeyEvent.KEYCODE_DPAD_DOWN) { focusGrid(); true } else false }
        root.addView(wxCard, FrameLayout.LayoutParams(wrap, wrap, Gravity.TOP))
        wxCard.addOnLayoutChangeListener { v, l, t, r, b, ol, ot, or2, ob ->
            if (r - l != or2 - ol) { v.pivotX = if (barPos() == 0) v.width.toFloat() else 0f; v.pivotY = 0f; refreshPillFrost() }
            if (b - t != ob - ot && ::gridBox.isInitialized) v.post { layoutGrid() } }
        positionWxCard()
    }
    // Panel barın karşı köşesine yerleşir; boyut ölçeği o köşeye yaslı büyür/küçülür
    private fun positionWxCard() {
        if (!::wxCard.isInitialized) return
        // Güvenlik payı: panel en fazla ekranın, üst bar ve kenar boşlukları çıktıktan sonra kalan kısmı kadar genişleyebilir
        topPill.post { val room = root.width - (topPill.width * topPill.scaleX).toInt() - dp(40) * 2 - dp(24)
            if (room > 0 && wxCard.width * wxCard.scaleX > room) { (wxCard.layoutParams as FrameLayout.LayoutParams).width = (room / wxCard.scaleX).toInt(); wxCard.requestLayout() } }
        val left = barPos() != 0
        (wxCard.layoutParams as FrameLayout.LayoutParams).apply { gravity = Gravity.TOP or (if (left) Gravity.START else Gravity.END); setMargins(if (left) dp(40) else 0, dp(24), if (left) 0 else dp(40), 0) }
        wxCard.requestLayout(); wxCard.post { wxCard.pivotX = if (left) 0f else wxCard.width.toFloat(); wxCard.pivotY = 0f; refreshPillFrost() }
    }
    private fun applyWxPanel() {
        if (!::wxCard.isInitialized) return
        val on = wxPanelOn()
        wxCard.visibility = if (on) View.VISIBLE else View.GONE
        weatherBoxView?.visibility = if (on) View.GONE else View.VISIBLE
        updateWeatherText(); markFrostDirty()
        if (::gridBox.isInitialized) topPill.post { layoutGrid() }
    }
    private fun updateWxCard() {
        if (!::wxCard.isInitialized || !wxPanelOn()) return
        val city = prefs.getString("city", null); val vals = Array(6) { "—" }; var tomorrow = ""
        if (city == null) { wxCardIcon.visibility = View.GONE; wxCardTemp.text = "—"; wxCardCond.text = "Konum seçilmedi" }
        else try {
            val o = JSONObject(prefs.getString("wxfull", null) ?: throw java.io.IOException())
            val code = o.getInt("c"); wxCardIcon.setKind(wxKind(code)); wxCardIcon.visibility = View.VISIBLE
            wxCardTemp.text = Math.round(o.getDouble("t")).toString() + "°"; wxCardCond.text = wxText(code) + " · " + city
            vals[0] = Math.round(o.optDouble("f", o.getDouble("t"))).toString() + "°"
            vals[1] = "%" + Math.round(o.optDouble("h", 0.0))
            vals[2] = Math.round(o.optDouble("w", 0.0)).toString() + " km/sa"
            val days = o.optJSONArray("days"); val d0 = days?.optJSONObject(0)
            if (d0 != null) vals[3] = rainText(d0, "0 mm")
            val d1 = days?.optJSONObject(1)
            if (d1 != null) { val r = rainText(d1, ""); tomorrow = "Yarın: " + Math.round(d1.optDouble("mx")) + "° / " + Math.round(d1.optDouble("mn")) + "° · " + wxText(d1.optInt("c", 3)) + (if (r.isNotEmpty()) " · $r" else "") }
        } catch (_: Exception) { wxCardIcon.visibility = View.GONE; wxCardTemp.text = "—"; wxCardCond.text = city }
        val lat = prefs.getString("lat", null)?.toDoubleOrNull(); val lon = prefs.getString("lon", null)?.toDoubleOrNull()
        if (lat != null && lon != null) { val f = SimpleDateFormat("HH:mm", Locale.getDefault())
            sunTime(lat, lon, true)?.let { vals[4] = f.format(Date(it)) }; sunTime(lat, lon, false)?.let { vals[5] = f.format(Date(it)) } }
        for (i in 0 until minOf(6, wxCardVals.size)) wxCardVals[i].text = vals[i]
        wxCardTomorrow.text = tomorrow.ifEmpty { "Yarın: —" }
        val al = activeAlerts().maxByOrNull { it.lvl }
        if (al == null) wxCardAlert.visibility = View.GONE
        else { wxCardAlert.visibility = View.VISIBLE; wxCardAlertDot.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(alertColor(al.lvl)) }
            wxCardAlertText.text = alertLevelName(al.lvl) + " uyarı · " + alertTypeName(al.type) }
    }
    // Günlük yağış: ihtimal varsa yüzde, yoksa miktar (mm); ikisi de yoksa none
    private fun rainText(d: JSONObject, none: String): String { val pp = d.optInt("pp", -1); val mm = d.optDouble("p", 0.0)
        return if (pp >= 0) "%$pp" else if (mm >= 0.5) Math.round(mm).toString() + " mm" else none }
    // Bugünün gün doğumu/batımı (NOAA yaklaşık hesabı, internet gerektirmez; ±1-2 dk). Kutup gecesi/gündüzünde null.
    private fun sunTime(lat: Double, lon: Double, rising: Boolean): Long? {
        val rad = Math.PI / 180.0; val now = Calendar.getInstance()
        val n = now.get(Calendar.DAY_OF_YEAR); val lngHour = lon / 15.0
        val t = n + ((if (rising) 6.0 else 18.0) - lngHour) / 24.0
        val m = 0.9856 * t - 3.289
        var l = m + 1.916 * Math.sin(m * rad) + 0.020 * Math.sin(2 * m * rad) + 282.634; l = ((l % 360) + 360) % 360
        var ra = Math.atan(0.91764 * Math.tan(l * rad)) / rad; ra = ((ra % 360) + 360) % 360
        ra += Math.floor(l / 90.0) * 90.0 - Math.floor(ra / 90.0) * 90.0; ra /= 15.0
        val sinDec = 0.39782 * Math.sin(l * rad); val cosDec = Math.cos(Math.asin(sinDec))
        val cosH = (Math.cos(90.833 * rad) - sinDec * Math.sin(lat * rad)) / (cosDec * Math.cos(lat * rad))
        if (cosH > 1 || cosH < -1) return null
        val h = (if (rising) 360.0 - Math.acos(cosH) / rad else Math.acos(cosH) / rad) / 15.0
        val tt = h + ra - 0.06571 * t - 6.622
        val ut = ((tt - lngHour) % 24 + 24) % 24
        val c = Calendar.getInstance(java.util.TimeZone.getTimeZone("UTC")).apply {
            set(now.get(Calendar.YEAR), now.get(Calendar.MONTH), now.get(Calendar.DAY_OF_MONTH), 0, 0, 0); set(Calendar.MILLISECOND, 0) }
        return c.timeInMillis + (ut * 3_600_000).toLong()
    }

    private fun focusGrid() { (lastTileView() ?: firstTile())?.requestFocus() }
    private fun firstTile(): View? = (grid.getChildAt(0) as? ViewGroup)?.getChildAt(0)
    private fun lastTileView(): View? {
        for (r in 0 until grid.childCount) { val row = grid.getChildAt(r) as ViewGroup; for (ccc in 0 until row.childCount) if (row.getChildAt(ccc).tag == lastPkg) return row.getChildAt(ccc) }
        return firstTile()
    }

    // Uygulama listesi sadece bir uygulama kurulunca/kaldırılınca/güncellenince yeniden okunur (her dönüşte değil -> hızlı)
    private var appsDirty = true
    private val pkgReceiver = object : android.content.BroadcastReceiver() { override fun onReceive(c: Context?, i: Intent?) {
        val p = i?.data?.schemeSpecificPart; if (p != null) { colorCache.remove(p); lightBgCache.remove(p) }
        appsDirty = true; if (hasWindowFocus()) { appsDirty = false; refreshApps(lastPkg) } } }
    override fun onDestroy() { try { unregisterReceiver(pkgReceiver) } catch (_: Exception) {}; try { unregisterReceiver(screenReceiver) } catch (_: Exception) {}; try { netCallback?.let { cm().unregisterNetworkCallback(it) } } catch (_: Exception) {}; try { if (imgPoolL.isInitialized()) imgPool.shutdownNow(); if (coverPoolL.isInitialized()) coverPool.shutdownNow() } catch (_: Exception) {}; handler.removeCallbacksAndMessages(null); super.onDestroy() }
    override fun onResume() { super.onResume()
        if (appsDirty) { appsDirty = false
            // İlk açılış: önbellek varsa anında göster, gerçek listeyi sistem sakinleşince arka planda tazele
            val cached = if (shown.isEmpty() && hiddenApps.isEmpty()) loadFromCache() else null
            if (cached != null) { val sg = sig(cached); diskSig = sg; shownSig = sg; applyList(sortApps(cached), lastPkg); scheduleCacheSync(4000) } else refreshApps(lastPkg) }
        if (pausedAt > 0 && System.currentTimeMillis() - pausedAt > 5 * 60_000L) lastWeather = 0L
        handler.removeCallbacks(tick); handler.post(tick); resetSaverTimer()
        if (prefs.getBoolean("reopen", false)) { prefs.edit().remove("reopen").apply(); handler.postDelayed({ curCat = CAT_LOOK; catRow[CAT_LOOK] = 0; showCategory(CAT_LOOK) }, 400) }
        if (prefs.getBoolean("reopenMain", false)) { prefs.edit().remove("reopenMain").apply(); handler.postDelayed({ mainRow = MAIN_RESET_ROW; showSettings() }, 400) } }
    override fun onPause() { super.onPause(); pausedAt = System.currentTimeMillis(); handler.removeCallbacks(tick); handler.removeCallbacks(saverRunnable) }
    // Uykudan (bekleme modundan) ya da uzun bir aradan dönünce hava durumu, saat ve ağ bilgisi beklemeden yenilenir
    private var pausedAt = 0L
    private val screenReceiver = object : android.content.BroadcastReceiver() { override fun onReceive(c: Context?, i: Intent?) {
        if (i?.action == Intent.ACTION_SCREEN_ON) { lastWeather = 0L; if (!stopped) { handler.removeCallbacks(tick); handler.post(tick) } } } }
    // Ana ekrandayken kumandanın Home tuşu: paneller ve ekran koruyucu kapanır, ızgara en üste kayar, imleç ilk kutuya gelir.
    // Başka bir uygulamadan Home ile dönülünce (ekran yeni görünür olmuşken) hiçbir şey değişmez, kalınan yerden devam edilir.
    private var visibleSince = 0L; private var stopped = true
    override fun onStart() { super.onStart(); stopped = false; visibleSince = android.os.SystemClock.uptimeMillis() }
    override fun onStop() { super.onStop(); stopped = true }
    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent)
        if (intent.action == Intent.ACTION_MAIN && intent.hasCategory(Intent.CATEGORY_HOME) && !stopped && android.os.SystemClock.uptimeMillis() - visibleSince > 700) goHomeTop() }
    private fun goHomeTop() {
        if (saverView != null) hideSaver()
        for (d in openDialogs.toList()) try { d.dismiss() } catch (_: Exception) {}
        if (movingPkg != null) endMove()
        firstRow = 0; gridScroll.smoothScrollTo(0, 0); updateHints(); markFrostDirty()
        firstTile()?.requestFocus()
    }
    override fun onUserInteraction() { super.onUserInteraction(); resetSaverTimer() }

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        if (saverView != null && !saverPreview) { if (e.action == KeyEvent.ACTION_DOWN) hideSaver(); return true }
        resetSaverTimer()
        if (movingPkg != null) {
            if (e.action == KeyEvent.ACTION_DOWN) when (e.keyCode) {
                KeyEvent.KEYCODE_DPAD_LEFT -> moveBy(-1); KeyEvent.KEYCODE_DPAD_RIGHT -> moveBy(1)
                KeyEvent.KEYCODE_DPAD_UP -> moveBy(-cols); KeyEvent.KEYCODE_DPAD_DOWN -> moveBy(cols)
                KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_BACK -> endMove(); else -> {}
            }
            return true
        }
        return super.dispatchKeyEvent(e)
    }

    @Suppress("OVERRIDE_DEPRECATION")
    override fun onBackPressed() {}

    // ---------- Uygulama listesi ----------
    private fun updTime(p: String): Long = try { packageManager.getPackageInfo(p, 0).lastUpdateTime } catch (_: Exception) { 0L }
    // Ham liste (sıralamasız): yalnızca TV için yapılmış (Android TV ana ekranında görünen) uygulamalar. Arka planda da çağrılabilir.
    private fun loadRaw(): List<AppItem> {
        val pm = packageManager
        val map = LinkedHashMap<String, AppItem>()
        val lean = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER), 0)
        for (ri in lean) { val p = ri.activityInfo.packageName; if (p == packageName) continue
            val banner = ri.activityInfo.loadBanner(pm)
            map[p] = AppItem(p, ri.activityInfo.name, ri.loadLabel(pm).toString(), banner ?: ri.loadIcon(pm), banner != null, updTime(p)) }
        return map.values.toList()
    }
    // Sıra elle belirlenir (Taşı): kayıtlı sıra, sonra sabitlenmiş uygulamalar, sonra alfabetik yeni gelenler
    private fun sortApps(all: List<AppItem>): List<AppItem> {
        val order = (prefs.getString("order", "") ?: "").split("|").filter { it.isNotEmpty() }
        return all.sortedWith(compareBy({ val o = order.indexOf(it.pkg); if (o >= 0) o else { val p = pinned.indexOf(it.pkg); 10000 + (if (p >= 0) p else 1000) } }, { it.label.lowercase() }))
    }

    private fun refreshApps(focusPkg: String?) { val raw = loadRaw(); shownSig = sig(raw); applyList(sortApps(raw), focusPkg); scheduleCacheSync() }
    // "Yeni" rozeti: ilk kurulumda var olan uygulamalar bilinen sayılır; sonradan kurulan uygulama ilk açılışına kadar rozetli kalır
    private fun trackNew(all: List<AppItem>) {
        val pk = all.map { it.pkg }.toHashSet(); val known = prefs.getStringSet("knownPkgs", null)
        if (known == null) { prefs.edit().putStringSet("knownPkgs", pk).apply(); return }
        val nw = HashSet(prefs.getStringSet("newPkgs", emptySet()) ?: emptySet()); nw.addAll(pk - known); nw.retainAll(pk)
        prefs.edit().putStringSet("knownPkgs", pk).putStringSet("newPkgs", nw).apply()
    }
    private fun isNew(pkg: String) = prefs.getStringSet("newPkgs", emptySet())?.contains(pkg) == true
    private fun clearNew(pkg: String) { val nw = HashSet(prefs.getStringSet("newPkgs", emptySet()) ?: emptySet()); if (nw.remove(pkg)) prefs.edit().putStringSet("newPkgs", nw).apply() }
    private fun applyList(all: List<AppItem>, focusPkg: String?) {
        trackNew(all)
        val hidden = prefs.getStringSet("hidden", emptySet()) ?: emptySet()
        shown = all.filter { !hidden.contains(it.pkg) }.toMutableList(); hiddenApps = all.filter { hidden.contains(it.pkg) }
        rebuildRows(focusPkg)
    }

    // ---------- Hızlı açılış önbelleği ----------
    // TV tam açılırken sistem çok meşgul: uygulama listesini ve afişleri diğer uygulamalardan okumak saniyeler sürüyor.
    // Son listeyi afişleriyle birlikte kendi klasörümüzde tutar, açılışta anında gösterir; gerçek listeyi sonra arka planda tazeleriz.
    private fun cacheDir() = File(filesDir, "appcache")
    private fun sig(list: List<AppItem>) = list.joinToString("|") { it.pkg + "/" + it.label + "/" + it.isBanner + "/" + it.upd }
    private fun loadFromCache(): List<AppItem>? {
        try {
            val f = File(cacheDir(), "list.txt"); if (!f.exists()) return null
            val out = ArrayList<AppItem>()
            for (line in f.readLines()) { val p = line.split("\t"); if (p.size < 5) continue
                val bmp = BitmapFactory.decodeFile(File(cacheDir(), p[0] + ".png").path) ?: return null
                out.add(AppItem(p[0], p[1], p[2], android.graphics.drawable.BitmapDrawable(resources, bmp), p[3] == "1", p[4].toLongOrNull() ?: 0L))
                if (p.size >= 7) { lightBgCache[p[0]] = p[5] == "1"; p[6].toIntOrNull()?.let { colorCache[p[0]] = it } } }
            return if (out.isEmpty()) null else out
        } catch (_: Exception) { return null }
    }
    private fun toBitmap(d: Drawable, banner: Boolean): android.graphics.Bitmap {
        var w = d.intrinsicWidth; var h = d.intrinsicHeight
        if (w <= 0 || h <= 0) { w = if (banner) 320 else 192; h = if (banner) 180 else 192 }
        val maxW = if (banner) 480 else 192; if (w > maxW) { h = h * maxW / w; w = maxW }
        val bmp = android.graphics.Bitmap.createBitmap(w, maxOf(1, h), android.graphics.Bitmap.Config.ARGB_8888)
        d.setBounds(0, 0, w, maxOf(1, h)); d.draw(Canvas(bmp)); return bmp
    }
    private fun writeCache(raw: List<AppItem>) { try {
        val dir = cacheDir(); dir.mkdirs(); val keep = HashSet<String>()
        for (a in raw) { val bmp = toBitmap(a.image, a.isBanner); FileOutputStream(File(dir, a.pkg + ".png")).use { bmp.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, it) }; bmp.recycle(); keep.add(a.pkg + ".png") }
        val tmp = File(dir, "list.tmp")
        // Açılışı hızlandırmak için kutu zemini (açık/koyu) ve dinamik renk de burada, arka planda hesaplanıp saklanır
        tmp.writeText(raw.joinToString("\n") { listOf(it.pkg, it.cls, it.label.replace(Regex("[\t\n]"), " "), if (it.isBanner) "1" else "0", it.upd.toString(),
            if (lightOf(it.image)) "1" else "0", colorOf(it.image).toString()).joinToString("\t") })
        tmp.renameTo(File(dir, "list.txt"))
        dir.listFiles()?.forEach { if (it.name.endsWith(".png") && it.name !in keep) it.delete() }
    } catch (_: Exception) {} }
    @Volatile private var diskSig = ""   // diskteki önbelleğin imzası
    private var shownSig = ""             // ekrandaki listenin imzası
    private val cacheSync = Runnable {
        Thread { try {
            val raw = loadRaw(); val sg = sig(raw)          // taze nesneler: henüz ekranda değiller, arka planda güvenle çizilir
            if (sg != diskSig) { writeCache(raw); diskSig = sg }
            handler.post { if (sg != shownSig) { shownSig = sg; applyList(sortApps(raw), lastPkg) } }
        } catch (_: Exception) {} }.start()
    }
    private fun scheduleCacheSync(delayMs: Long = 3000) { handler.removeCallbacks(cacheSync); handler.postDelayed(cacheSync, delayMs) }

    private fun rebuildRows(focusPkg: String?) {
        grid.removeAllViews(); val n = cols
        // Satırları ekranda tam ortala
        val side = maxOf(gridPad / 2, (screenWdp() - n * (tileW + tileGap)) / 2); grid.setPadding(dp(side), 0, dp(side), 0)
        val views = mutableListOf<View>(); for (app in shown) views.add(tile(app))
        var target: View? = null; var cur: LinearLayout? = null
        views.forEachIndexed { i, v ->
            if (i % n == 0) { val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; clipChildren = false }; cur = r
                grid.addView(r, LinearLayout.LayoutParams(wrap, wrap).apply { setMargins(0, dp(halfGap()), 0, dp(halfGap())) }) }
            cur?.addView(v); if (focusPkg != null && v.tag == focusPkg) target = v
        }
        // Yüksekliği sınırla: üstte panel + geniş boşluk hep kalsın (büyüyen kutu bile panele değmesin)
        rowCount = (views.size + n - 1) / n
        layoutGrid(); markFrostDirty()
        (target ?: firstTile())?.requestFocus()
    }

    // Seçili kutu büyüdüğünde sığsın diye satırın üst/alt boşluğu (dp)
    private fun halfGap(): Int = maxOf(12, Math.ceil(tileH * (focusZoom() - 1) / 2.0).toInt() + 4)
    private fun rowPx(): Int = dp(tileH) + 2 * dp(halfGap())

    // Izgarayı panelin altındaki alana, sadece TAM satırlar görünecek şekilde yerleştir
    private fun layoutGrid() {
        val screenH = resources.displayMetrics.heightPixels
        val top = pillBottomPx() + dp(16); val bottom = screenH - dp(16)
        val avail = bottom - top; val rp = rowPx()
        visibleRows = maxOf(1, avail / rp)
        val shownRows = maxOf(1, minOf(rowCount, visibleRows))
        val h = shownRows * rp
        val y = top + (avail - h) / 2
        gridBox.layoutParams = (gridBox.layoutParams as FrameLayout.LayoutParams).apply { height = h; gravity = Gravity.TOP; topMargin = y; bottomMargin = 0 }
        (upHint.layoutParams as FrameLayout.LayoutParams).topMargin = y - dp(22)
        (downHint.layoutParams as FrameLayout.LayoutParams).topMargin = y + h
        upHint.requestLayout(); downHint.requestLayout()
        firstRow = firstRow.coerceIn(0, maxOf(0, rowCount - visibleRows))
        gridScroll.post { gridScroll.scrollTo(0, firstRow * rp) }
        updateHints()
    }
    private fun updateHints() {
        upHint.visibility = if (firstRow > 0) View.VISIBLE else View.INVISIBLE
        downHint.visibility = if (firstRow + visibleRows < rowCount) View.VISIBLE else View.INVISIBLE
    }
    private fun ensureRowVisible(v: View) {
        val r = grid.indexOfChild(v.parent as? View ?: return); if (r < 0) return
        val old = firstRow
        if (r < firstRow) firstRow = r else if (r >= firstRow + visibleRows) firstRow = r - visibleRows + 1
        if (firstRow != old) { gridScroll.smoothScrollTo(0, firstRow * rowPx()); updateHints(); markFrostDirty() }
    }

    private fun saveOrder() { prefs.edit().putString("order", (shown.map { it.pkg } + hiddenApps.map { it.pkg }).joinToString("|")).apply() }
    private fun startMove(app: AppItem) { movingPkg = app.pkg; hintView.visibility = View.VISIBLE; rebuildRows(app.pkg) }
    private fun moveBy(d: Int) { val mp = movingPkg ?: return; val i = shown.indexOfFirst { it.pkg == mp }; val j = i + d; if (i < 0 || j < 0 || j >= shown.size) return; val t = shown[i]; shown[i] = shown[j]; shown[j] = t; saveOrder(); rebuildRows(mp) }
    private fun endMove() { val mp = movingPkg; movingPkg = null; hintView.visibility = View.GONE; rebuildRows(mp) }
    private fun hide(app: AppItem) { val h = (prefs.getStringSet("hidden", emptySet()) ?: emptySet()).toMutableSet(); h.add(app.pkg); prefs.edit().putStringSet("hidden", h).apply(); refreshApps(null) }
    private fun unhide(app: AppItem) { val h = (prefs.getStringSet("hidden", emptySet()) ?: emptySet()).toMutableSet(); h.remove(app.pkg); prefs.edit().putStringSet("hidden", h).apply(); refreshApps(app.pkg) }
    private fun uninstall(app: AppItem) { try { startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:" + app.pkg))) } catch (_: Exception) {} }
    private fun appInfo(app: AppItem) { try { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + app.pkg)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {} }

    // ---------- Ekran koruyucu ----------
    // Süreler: 15 dk, 30 dk, 1 sa, 2 sa, 4 sa. Arka plan: Bing'in günün fotoğrafları (önbellekte) ya da siyah.
    // Saat/tarih/hava, fotoğrafın en sakin köşesine yerleşir; yazı boyutu ayarlanabilir (canlı önizlemeyle).
    private val saverMins = intArrayOf(15, 30, 60, 120, 240)
    private fun saverLabel(m: Int) = if (m < 60) "$m Dakika" else "${m / 60} Saat"
    private var saverPreview = false
    private var saverImgA: ImageView? = null
    private var saverImgB: ImageView? = null
    private var saverFrontA = true
    private var saverGen = 0
    private var saverScrim: View? = null
    private var saverInfo: LinearLayout? = null
    private var saverDate: TextView? = null
    private var saverWxView: TextView? = null
    private var saverCaption: TextView? = null
    private var saverCorner = -1
    private var saverIdx = 0
    private val saverRotate = Runnable { nextSaverPhoto() }
    private fun saverScale() = prefs.getFloat("saverScale", 1f)

    private fun resetSaverTimer() { handler.removeCallbacks(saverRunnable); if (saverView != null) return; if (!prefs.getBoolean("saver", true)) return
        val idx = prefs.getInt("saverMin", 1).coerceIn(0, saverMins.size - 1); handler.postDelayed(saverRunnable, saverMins[idx] * 60_000L) }

    private fun saverText(size: Float, light: Boolean = false): TextView = TextView(this).apply {
        textSize = size; setTextColor(Color.WHITE); if (light) typeface = Typeface.create("sans-serif-thin", Typeface.NORMAL)
        setShadowLayer(dp(10).toFloat(), 0f, dp(1).toFloat(), Color.argb(170, 0, 0, 0)) }

    private fun showSaver(preview: Boolean = false) {
        if (saverView != null) return
        saverPreview = preview
        if (!preview) { while (openDialogs.isNotEmpty()) openDialogs.removeAt(0).dismiss() }
        val ov = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        val photos = if (prefs.getInt("saverBg", 0) == 0) bingFiles() else emptyList()
        if (photos.isNotEmpty()) {
            val a = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
            val b = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP; alpha = 0f }
            ov.addView(a, FrameLayout.LayoutParams(matchP, matchP)); ov.addView(b, FrameLayout.LayoutParams(matchP, matchP))
            saverImgA = a; saverImgB = b; saverFrontA = true
        }
        val scr = View(this); ov.addView(scr, FrameLayout.LayoutParams(matchP, matchP)); saverScrim = scr
        val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        saverClock = saverText(84f, true); saverDate = saverText(20f); saverWxView = saverText(17f)
        saverCaption = saverText(11f).apply { alpha = 0.75f; maxLines = 1; maxWidth = dp(420); ellipsize = android.text.TextUtils.TruncateAt.END; visibility = if (photos.isEmpty()) View.GONE else View.VISIBLE }
        info.addView(saverClock); info.addView(saverDate); info.addView(saverWxView, LinearLayout.LayoutParams(wrap, wrap).apply { topMargin = dp(6) })
        info.addView(saverCaption, LinearLayout.LayoutParams(wrap, wrap).apply { topMargin = dp(14) })
        ov.addView(info, FrameLayout.LayoutParams(wrap, wrap, Gravity.CENTER)); saverInfo = info
        applySaverText()
        root.addView(ov, FrameLayout.LayoutParams(matchP, matchP)); saverView = ov; saverCorner = -1
        if (photos.isNotEmpty()) {
            saverIdx = ((System.currentTimeMillis() / 86_400_000L) % photos.size).toInt()
            showSaverPhoto(photos[saverIdx], true); handler.postDelayed(saverRotate, 5 * 60_000L)
        } else placeInfo(4, false)
        if (prefs.getInt("saverBg", 0) == 0 && photos.isEmpty()) fetchBing(true)
    }
    private fun hideSaver() {
        handler.removeCallbacks(saverRotate); saverGen++
        saverView?.let { root.removeView(it) }; saverView = null; saverClock = null; saverDate = null; saverWxView = null; saverCaption = null
        saverInfo = null; saverScrim = null; saverImgA = null; saverImgB = null; saverPreview = false; resetSaverTimer()
    }
    private fun applySaverText() { val s = saverScale()
        saverClock?.textSize = 84f * s; saverDate?.textSize = 20f * s; saverWxView?.textSize = 17f * s; saverCaption?.textSize = 11f * minOf(s, 1.3f)
        updateSaverInfo() }
    private fun updateSaverInfo() {
        val now = Date()
        saverClock?.let { setClockText(it, SimpleDateFormat("HH:mm", Locale.getDefault()).format(now)) }
        saverDate?.text = SimpleDateFormat("d MMMM, EEEE", Locale("tr", "TR")).format(now)
        val v = saverWxView ?: return
        val wx = prefs.getString("wx", null); val city = prefs.getString("city", null)
        if (prefs.getBoolean("saverWx", true) && wx != null && city != null) { val p = wx.split("|"); v.text = city + " · " + p[0] + " " + (p.getOrNull(1) ?: ""); v.visibility = View.VISIBLE }
        else v.visibility = View.GONE
    }
    private fun nextSaverPhoto() {
        val photos = bingFiles(); if (saverView == null || photos.size < 2) return
        saverIdx = (saverIdx + 1) % photos.size; showSaverPhoto(photos[saverIdx], false); handler.postDelayed(saverRotate, 5 * 60_000L)
    }
    private fun showSaverPhoto(f: File, first: Boolean) {
        val g = saverGen
        Thread {
            val bmp = try { val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }; BitmapFactory.decodeFile(f.path, o)
                var s = 1; while (o.outWidth / s > 1920) s *= 2; BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = s }) } catch (_: Exception) { null }
            val corner = if (bmp != null) calmCorner(bmp) else 2
            handler.post {
                val a = saverImgA; val b = saverImgB
                if (bmp == null || a == null || b == null || g != saverGen) return@post
                saverCaption?.text = bingCaption(f.name)
                if (first) { a.setImageBitmap(bmp); a.alpha = 1f; saverFrontA = true; placeInfo(corner, false) }
                else {
                    val inc = if (saverFrontA) b else a; val out = if (saverFrontA) a else b; saverFrontA = !saverFrontA
                    inc.setImageBitmap(bmp); val gen = ++saverGen
                    animateFrames(1600, { p -> if (gen == saverGen) { inc.alpha = p; out.alpha = 1f - p } }, { if (gen == saverGen) out.setImageDrawable(null) })
                    placeInfo(corner, true)
                }
            }
        }.start()
    }
    // Fotoğrafın en sakin (en az ayrıntılı, çok parlak olmayan) köşesi: 0 sol üst, 1 sağ üst, 2 sol alt, 3 sağ alt
    private fun calmCorner(bmp: android.graphics.Bitmap): Int {
        val sm = android.graphics.Bitmap.createScaledBitmap(bmp, 64, 36, true); var best = 2; var bestScore = Double.MAX_VALUE
        for (q in 0..3) { val x0 = if (q % 2 == 0) 0 else 32; val y0 = if (q < 2) 0 else 18
            var sum = 0.0; var sq = 0.0; var n = 0
            for (y in y0 until y0 + 18) for (x in x0 until x0 + 32) { val c = sm.getPixel(x, y); val l = (0.299 * Color.red(c) + 0.587 * Color.green(c) + 0.114 * Color.blue(c)) / 255.0; sum += l; sq += l * l; n++ }
            val mean = sum / n; val std = Math.sqrt(maxOf(0.0, sq / n - mean * mean))
            var score = std + maxOf(0.0, mean - 0.55) * 0.6; if (q >= 2) score *= 0.9
            if (score < bestScore) { bestScore = score; best = q } }
        if (sm != bmp) sm.recycle(); return best
    }
    private fun placeInfo(corner: Int, animate: Boolean) {
        val info = saverInfo ?: return; val scr = saverScrim ?: return
        val doPlace = {
            val center = corner == 4; val left = corner == 0 || corner == 2; val top = corner < 2
            val hg = if (center) Gravity.CENTER_HORIZONTAL else if (left) Gravity.START else Gravity.END
            info.gravity = hg; for (i in 0 until info.childCount) (info.getChildAt(i) as? TextView)?.gravity = hg
            info.layoutParams = FrameLayout.LayoutParams(wrap, wrap, if (center) Gravity.CENTER else ((if (top) Gravity.TOP else Gravity.BOTTOM) or (if (left) Gravity.START else Gravity.END))).apply { setMargins(dp(72), dp(60), dp(72), dp(60)) }
            scr.background = if (center) null else GradientDrawable(when (corner) { 0 -> GradientDrawable.Orientation.TL_BR; 1 -> GradientDrawable.Orientation.TR_BL; 2 -> GradientDrawable.Orientation.BL_TR; else -> GradientDrawable.Orientation.BR_TL },
                intArrayOf(Color.argb(165, 0, 0, 0), Color.argb(50, 0, 0, 0), Color.argb(0, 0, 0, 0)))
        }
        if (!animate || corner == saverCorner) { doPlace(); saverCorner = corner; return }
        saverCorner = corner
        animateFrames(400, { p -> info.alpha = 1f - p }, { doPlace(); animateFrames(500, { p -> info.alpha = p }) })
    }

    // ---------- Bing fotoğrafları ----------
    private class WebImg(val id: String, val full: String, val thumb: String, val caption: String)
    private fun bingDir() = File(filesDir, "bing")
    private fun bingFiles(): List<File> = bingDir().listFiles()?.filter { it.name.endsWith(".jpg") }?.sortedByDescending { it.lastModified() } ?: emptyList()
    private fun bingCaption(name: String): String = try { JSONObject(prefs.getString("bingMeta", "{}") ?: "{}").optString(name, "") } catch (_: Exception) { "" }
    @Volatile private var bingBusy = false
    private fun fetchBing(force: Boolean = false) {
        if (bingBusy || !online) return
        val now = System.currentTimeMillis()
        if (!force && now - prefs.getLong("bingAt", 0L) < 6 * 3_600_000L) return
        bingBusy = true
        Thread { try {
            val list = bingList(); if (list.isNotEmpty()) {
                val dir = bingDir(); dir.mkdirs()
                val meta = try { JSONObject(prefs.getString("bingMeta", "{}") ?: "{}") } catch (_: Exception) { JSONObject() }
                for (b in list.take(8)) { val f = File(dir, b.id + ".jpg"); if (!f.exists()) try { download(b.full, f) } catch (_: Exception) {}; meta.put(b.id + ".jpg", b.caption) }
                bingFiles().drop(16).forEach { it.delete() }
                prefs.edit().putLong("bingAt", now).putString("bingMeta", meta.toString()).apply()
            }
        } catch (_: Exception) {} finally { bingBusy = false } }.start()
    }
    private fun bingList(): List<WebImg> {
        val out = ArrayList<WebImg>()
        for (idx in intArrayOf(0, 7)) { try {
            val arr = JSONObject(httpGet("https://www.bing.com/HPImageArchive.aspx?format=js&idx=$idx&n=8&mkt=tr-TR")).getJSONArray("images")
            for (i in 0 until arr.length()) { val o = arr.getJSONObject(i); val base = o.getString("urlbase")
                val id = base.substringAfter("id=").replace(Regex("[^A-Za-z0-9_.-]"), "_")
                if (out.none { it.id == id }) out.add(WebImg(id, "https://www.bing.com" + base + "_1920x1080.jpg", "https://www.bing.com" + base + "_640x360.jpg", o.optString("copyright"))) }
        } catch (_: Exception) {} }
        return out
    }
    // Sunucu hata dönerse hemen, indirme 60 sn'de bitmezse yarıda bırakılır (simge sonsuza kadar dönmesin)
    private fun download(url: String, f: File, onProgress: ((Float) -> Unit)? = null) {
        val c = URL(url).openConnection() as HttpURLConnection; c.connectTimeout = 10000; c.readTimeout = 20000; c.instanceFollowRedirects = true; c.setRequestProperty("User-Agent", UA)
        if (c.responseCode != 200) { c.disconnect(); throw java.io.IOException("HTTP " + c.responseCode) }
        val total = c.contentLengthLong; val deadline = System.currentTimeMillis() + 60_000
        val tmp = File(f.path + ".part")
        c.inputStream.use { i -> FileOutputStream(tmp).use { o ->
            val buf = ByteArray(16 * 1024); var got = 0L
            while (true) { val n = i.read(buf); if (n < 0) break; o.write(buf, 0, n); got += n
                if (System.currentTimeMillis() > deadline) { c.disconnect(); throw java.io.IOException("zaman aşımı") }
                if (onProgress != null && total > 0) onProgress((got.toFloat() / total).coerceAtMost(1f)) } } }
        if (tmp.length() < 10_000) { tmp.delete(); throw java.io.IOException("küçük dosya") }
        if (f.exists()) f.delete(); tmp.renameTo(f)
    }

    // ---------- Paneller ----------
    private fun panelBox(): LinearLayout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(du(10), du(12), du(10), du(10))
        background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, when (themeIdx) {
                1 -> intArrayOf(Color.argb(250, 238, 238, 242), Color.argb(252, 226, 227, 232))
                2 -> intArrayOf(Color.argb(if (blurOk) 105 else 150, 70, 74, 86), Color.argb(if (blurOk) 120 else 170, 40, 43, 52))
                3 -> intArrayOf(Color.argb(if (blurOk) 150 else 215, 248, 248, 251), Color.argb(if (blurOk) 170 else 225, 232, 234, 240))
                else -> intArrayOf(Color.argb(242, 26, 27, 31), Color.argb(246, 12, 13, 16)) }).apply {
            cornerRadius = du(20).toFloat(); setStroke(dp(1), when (themeIdx) { 1 -> Color.argb(45, 0, 0, 0); 2, 3 -> Color.argb(120, 255, 255, 255); else -> Color.argb(45, 255, 255, 255) }) } }
    // TV sistem bulanıklığını destekliyorsa panellerin arkası gerçek buzlu cam gibi bulanıklaşır (Android 12+)
    private val blurOk: Boolean by lazy { Build.VERSION.SDK_INT >= 31 && try { windowManager.isCrossWindowBlurEnabled } catch (_: Exception) { false } }
    private var dialogAt = 0L
    // Uzun basıştan kalan OK tuşu yeni paneldeki ilk satırı yanlışlıkla seçmesin
    private fun tooSoon(): Boolean = android.os.SystemClock.uptimeMillis() - dialogAt < 350
    // onGone: panel kapanınca yapılacak temizlik (ör. galeri küçük resimlerini bellekten bırakmak)
    // Paneller: ana ekrandan açılırken 0,16 sn'de solarak ve hafifçe aşağı kayarak gelir, ana ekrana kapanırken solarak gider.
    // Panelden panele geçişte (alt menüye girme, Geri ile dönme) geçiş anlıktır: iki panel üst üste binmez, beklenmez.
    private var panelGoneAt = 0L
    private inner class PanelDialog : Dialog(this@MainActivity) {
        private var closing = false
        init { requestWindowFeature(Window.FEATURE_NO_TITLE) }
        private fun others() = openDialogs.any { it !== this && it.isShowing }
        override fun onStart() { super.onStart()
            val v = window?.decorView ?: return
            if (others() || android.os.SystemClock.uptimeMillis() - panelGoneAt < 250) return
            val dy = dp(10).toFloat(); v.alpha = 0f; v.translationY = -dy
            animateFrames(160, { p -> val e = ease(p); v.alpha = e; v.translationY = -dy * (1f - e) }) }
        override fun dismiss() {
            if (closing) return; closing = true
            // Aynı tıklamada yeni bir panel açılıyorsa (alt menü/geri) bir sonraki karede anında kapanır, açılmıyorsa solarak kapanır
            handler.post {
                val v = window?.decorView
                if (v == null || !isShowing || others() || saverView != null) finish()
                else { val dy = dp(8).toFloat(); animateFrames(130, { p -> v.alpha = 1f - p; v.translationY = -dy * p }, { finish() }) } } }
        private fun finish() { panelGoneAt = android.os.SystemClock.uptimeMillis(); try { super.dismiss() } catch (_: Exception) {} }
    }
    private fun registerDialog(dlg: Dialog, onGone: () -> Unit = {}) { dialogAt = android.os.SystemClock.uptimeMillis(); for (d in openDialogs.toList()) if (d !== dlg) { try { d.dismiss() } catch (_: Exception) {} }; openDialogs.add(dlg); dlg.setOnKeyListener { _, _, _ -> resetSaverTimer(); false }; dlg.setOnDismissListener { openDialogs.remove(dlg); onGone(); resetSaverTimer() }; resetSaverTimer() }
    // ---------- Buzlu cam (Koyu cam / Açık cam) ----------
    // Bu TV pencere arkası bulanıklığını desteklemiyor; ekranın 1/8 boyutlu görüntüsünü alıp kendimiz bulanıklaştırıyoruz.
    // Hız için: görüntü önbellekte tutulur (ekran değişmedikçe yeniden çekilmez), dişliye gelindiğinde önceden hazırlanır ve
    // panelin zemini daha pencere açılmadan, konumu hesaplanarak çizilir -> panel ilk karede buzlu açılır, gecikme olmaz.
    private val frostScale = 0.125f
    private var frostRootCache: android.graphics.Bitmap? = null
    private var frostBgCache: android.graphics.Bitmap? = null
    private fun markFrostDirty() { frostRootCache = null }
    private fun frostSnapshot(src: View): android.graphics.Bitmap? = try {
        if (src.width == 0) null else android.graphics.Bitmap.createBitmap(Math.max(1, (src.width * frostScale).toInt()), Math.max(1, (src.height * frostScale).toInt()), android.graphics.Bitmap.Config.ARGB_8888).also { b ->
            val c = Canvas(b); c.scale(frostScale, frostScale); src.draw(c); boxBlur(b, 4); boxBlur(b, 4) }
    } catch (_: Exception) { null }
    private fun frostRoot(): android.graphics.Bitmap? { if (frostRootCache == null) frostRootCache = frostSnapshot(root); return frostRootCache }
    // Hızlı kutu bulanıklığı (yatay + dikey kayan toplam); 240x135 görüntüde birkaç milisaniye
    private fun boxBlur(b: android.graphics.Bitmap, r: Int) {
        val w = b.width; val h = b.height; val px = IntArray(w * h); val tmp = IntArray(w * h); b.getPixels(px, 0, w, 0, 0, w, h); val n = 2 * r + 1
        for (y in 0 until h) { var ra = 0; var ga = 0; var ba = 0; val row = y * w
            for (i in -r..r) { val c = px[row + i.coerceIn(0, w - 1)]; ra += (c shr 16) and 255; ga += (c shr 8) and 255; ba += c and 255 }
            for (x in 0 until w) { tmp[row + x] = (0xFF shl 24) or ((ra / n) shl 16) or ((ga / n) shl 8) or (ba / n)
                val o = px[row + (x - r).coerceIn(0, w - 1)]; val i2 = px[row + (x + r + 1).coerceIn(0, w - 1)]
                ra += ((i2 shr 16) and 255) - ((o shr 16) and 255); ga += ((i2 shr 8) and 255) - ((o shr 8) and 255); ba += (i2 and 255) - (o and 255) } }
        for (x in 0 until w) { var ra = 0; var ga = 0; var ba = 0
            for (i in -r..r) { val c = tmp[i.coerceIn(0, h - 1) * w + x]; ra += (c shr 16) and 255; ga += (c shr 8) and 255; ba += c and 255 }
            for (y in 0 until h) { px[y * w + x] = (0xFF shl 24) or ((ra / n) shl 16) or ((ga / n) shl 8) or (ba / n)
                val o = tmp[(y - r).coerceIn(0, h - 1) * w + x]; val i2 = tmp[(y + r + 1).coerceIn(0, h - 1) * w + x]
                ra += ((i2 shr 16) and 255) - ((o shr 16) and 255); ga += ((i2 shr 8) and 255) - ((o shr 8) and 255); ba += (i2 and 255) - (o and 255) } }
        b.setPixels(px, 0, w, 0, 0, w, h)
    }
    private fun frostOf(snap: android.graphics.Bitmap, screenX: Int, screenY: Int, radius: Float): FrostDrawable =
        if (lightTheme) FrostDrawable(snap, frostScale, screenX, screenY, radius, Color.argb(150, 250, 250, 252), Color.argb(175, 234, 236, 242), dp(1).toFloat(), Color.argb(150, 255, 255, 255))
        else FrostDrawable(snap, frostScale, screenX, screenY, radius, Color.argb(110, 70, 74, 86), Color.argb(150, 26, 28, 36), dp(1).toFloat(), Color.argb(95, 255, 255, 255))
    // Üst panelin camı: arka plan görüntüsünden (panel her zaman arka planın üstünde durur)
    private fun refreshPillFrost() {
        if (!glassTheme || !::topPill.isInitialized) return
        val views = if (::wxCard.isInitialized) listOf<View>(topPill, wxCard) else listOf<View>(topPill)
        for (v in views) v.post { if (v.width == 0) return@post
            val snap = frostBgCache ?: frostSnapshot(bgView)?.also { frostBgCache = it } ?: return@post
            val loc = IntArray(2); v.getLocationOnScreen(loc)
            v.background = frostOf(snap, loc[0], loc[1], dp(28).toFloat()) }
    }
    // underBar: panel üst barın altında, barla aynı hizada (sol/orta/sağ) açılır; false ise ekranın ortasında
    private fun styleWindow(dlg: Dialog, widthDp: Int, underBar: Boolean = true) {
        val w = dlg.window ?: return; w.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT)); w.setLayout(du(widthDp), ViewGroup.LayoutParams.WRAP_CONTENT)
        val g = if (underBar) barGravity() else Gravity.CENTER_HORIZONTAL; w.setGravity(Gravity.TOP or g); w.setDimAmount(when (themeIdx) { 1 -> 0.08f; 2, 3 -> 0f; else -> 0.16f }); val lp = w.attributes; lp.y = pillBottomPx() + dp(12); lp.x = if (g == Gravity.CENTER_HORIZONTAL) 0 else dp(40); w.attributes = lp
        if (glassTheme && !blurOk) {
            val box = w.decorView.findViewById<ViewGroup>(android.R.id.content)?.getChildAt(0); val snap = frostRoot()
            if (box != null && snap != null) {
                val sx = when (g) { Gravity.START -> dp(40); Gravity.END -> root.width - dp(40) - du(widthDp); else -> (root.width - du(widthDp)) / 2 }
                box.background = frostOf(snap, sx, lp.y, du(20).toFloat())
            }
        }
        if (glassTheme && blurOk && Build.VERSION.SDK_INT >= 31) try {
            // Panelin yuvarlak arka planını pencereye taşı: bulanıklık köşeleri izlesin
            val box = w.decorView.findViewById<ViewGroup>(android.R.id.content)?.getChildAt(0)
            val bgd = box?.background; if (box != null && bgd != null) { box.background = null; w.setBackgroundDrawable(bgd) }
            w.setBackgroundBlurRadius(dp(26))
        } catch (_: Exception) {}
    }
    // Üst alanın alt kenarı: bar ile (açıksa) hava durumu panelinden hangisi daha aşağıdaysa
    private fun pillBottomPx(): Int { val a = if (topPill.height == 0) dp(130) else (topPill.top + topPill.height * topPill.scaleY).toInt()
        val b = if (::wxCard.isInitialized && wxCard.visibility == View.VISIBLE && wxCard.height > 0) (wxCard.top + wxCard.height * wxCard.scaleY).toInt() else 0
        return maxOf(a, b) }
    // Panelde liste/ızgaraya kalan yükseklik: ekran - üst alan - panel boşluğu - alt pay - (başlık + ayraç + alt yazı + iç boşluk)
    private fun panelListMax(): Int = maxOf(dp(150), resources.displayMetrics.heightPixels - pillBottomPx() - dp(12) - dp(16) - du(84))
    // Panel başlığı; path verilirse önünde nerede olunduğu silik ve küçük yazılır: "Ayarlar › Görünüm › Arka Plan".
    // Tek satırdır (yükseklik değişmez); sığmazsa baştan kısalır, asıl başlık her zaman görünür.
    private fun titleView(t: String, path: List<String> = emptyList()): TextView = TextView(this).apply {
        val sb = android.text.SpannableStringBuilder()
        for (part in path.takeLast(2)) { val st = sb.length; sb.append(part).append("  ›  ")
            sb.setSpan(android.text.style.ForegroundColorSpan(cSub()), st, sb.length, 0); sb.setSpan(android.text.style.RelativeSizeSpan(0.84f), st, sb.length, 0) }
        sb.append(t)
        text = sb; textSize = sp(14.5f); typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL); setTextColor(cText()); letterSpacing = 0.01f
        maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.START; setPadding(du(10), du(2), du(10), du(9)) }
    private fun crumbs(parent: (() -> Unit)?): List<String> = when {
        parent === backToCat -> listOf("Ayarlar", catNames[curCat])
        parent === backToMain -> listOf("Ayarlar")
        parent === backToBg -> listOf("Görünüm", "Arka Plan")
        parent === backToSources -> listOf("Arka Plan", "Fotoğraf Seç")
        else -> emptyList() }
    // Liste ekrana sığıyorsa kaydırmasız, tam boy gösterilir. Sığmıyorsa önce satır içi boşluklar daraltılır; yine sığmazsa
    // alan sabitlenir ve alt/üst kenar yumuşakça solar (yarım satır keskin biçimde kesik görünmez).
    private fun fitList(list: LinearLayout, panelWidthDp: Int, rows: List<View>): ScrollView {
        val max = panelListMax(); val wSpec = View.MeasureSpec.makeMeasureSpec(du(panelWidthDp) - 2 * du(10), View.MeasureSpec.EXACTLY)
        fun measure(): Int { list.measure(wSpec, View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)); return list.measuredHeight }
        var h = measure()
        if (h > max) { rows.forEach { it.setPadding(it.paddingLeft, du(3), it.paddingRight, du(3)) }; h = measure() }
        val sv = ScrollView(this).apply { isVerticalScrollBarEnabled = false; addView(list) }
        if (h > max) { h = max; sv.isVerticalFadingEdgeEnabled = true; sv.setFadingEdgeLength(du(28)) }
        sv.layoutParams = LinearLayout.LayoutParams(matchP, h)
        return sv
    }
    private fun footView(t: String): TextView = TextView(this).apply { text = t; textSize = sp(10.5f); setTextColor(cFoot()); setPadding(du(10), du(8), du(10), 0) }

    // Tek satır (kendi tıklamasıyla) — bölümlü menü için
    private fun menuRow(item: PItem, onClick: () -> Unit): View {
        val rowBg = GradientDrawable().apply { cornerRadius = dp(11).toFloat(); setColor(Color.TRANSPARENT) }
        val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; isFocusable = true; background = rowBg; setPadding(du(8), du(6), du(10), du(6)) }
        if (item.glyph >= 0) { val ic = FrameLayout(this).apply { background = GradientDrawable().apply { cornerRadius = dp(7).toFloat(); setColor(Color.parseColor(item.tint)) } }
            ic.addView(GlyphView(this, item.glyph), FrameLayout.LayoutParams(matchP, matchP)); r.addView(ic, LinearLayout.LayoutParams(du(26), du(26)).apply { setMargins(0, 0, du(10), 0) }) }
        else if (item.image != null) { val iv = ImageView(this).apply { setImageDrawable(item.image); scaleType = ImageView.ScaleType.CENTER_CROP; background = GradientDrawable().apply { cornerRadius = dp(7).toFloat(); setColor(Color.parseColor("#20222A")) }; clipToOutline = true }
            r.addView(iv, LinearLayout.LayoutParams(du(44), du(30)).apply { setMargins(0, 0, du(10), 0) }) }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(TextView(this).apply { text = item.label; textSize = sp(13f); setTextColor(cText()) })
        val subTv = item.sub?.let { TextView(this).apply { text = it; textSize = sp(10.5f); setTextColor(cSub()) }.also { t -> col.addView(t) } }
        r.addView(col, LinearLayout.LayoutParams(0, wrap, 1f))
        val sw: SwitchView? = if (item.toggle != null) SwitchView(this, item.toggle, lightTheme).also { r.addView(it, LinearLayout.LayoutParams(du(38), du(23))) } else null
        // Yerinde ayarlanabilen satır: seçiliyken sağda küçük "◀ ▶" belirir
        val adj = item.adjust
        val lr = if (adj != null) TextView(this).apply { text = "◀ ▶"; textSize = sp(9f); setTextColor(cSub()); alpha = 0f; setPadding(0, 0, du(6), 0) }.also { r.addView(it) } else null
        if (sw == null && item.arrow) { val ch = GlyphView(this, GlyphView.CHEVRON); ch.setTint(Color.parseColor("#8E8E99")); r.addView(ch, LinearLayout.LayoutParams(du(16), du(16))) }
        if (adj != null) r.setOnKeyListener { _, k, e ->
            if (e.action == KeyEvent.ACTION_DOWN && (k == KeyEvent.KEYCODE_DPAD_LEFT || k == KeyEvent.KEYCODE_DPAD_RIGHT)) { adj(if (k == KeyEvent.KEYCODE_DPAD_RIGHT) 1 else -1)?.let { subTv?.text = it }; true } else false }
        r.setOnFocusChangeListener { _, has -> rowBg.setColor(if (has) cFocus() else Color.TRANSPARENT); rowBg.setStroke(if (has) dp(1) else 0, cFocusStroke()); lr?.alpha = if (has) 1f else 0f }
        r.setOnClickListener { if (!tooSoon()) { sw?.flip(); onClick() } }
        return r
    }

    // Çoktan seçmeli panel (canlı önizleme için stayOpen)
    private fun showPanel(title: String, items: List<PItem>, checked: Int, parent: (() -> Unit)?, stayOpen: Boolean, focusAt: Int = -1, onPick: (Int) -> Unit) {
        val dlg = PanelDialog()
        val box = panelBox(); box.addView(titleView(title, crumbs(parent)))
        box.addView(View(this).apply { setBackgroundColor(cDiv()) }, LinearLayout.LayoutParams(matchP, dp(1)).apply { setMargins(0, 0, 0, dp(6)) })
        val selectable = stayOpen || checked >= 0; val rowViews = ArrayList<View>()
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val checks = arrayOfNulls<GlyphView>(items.size); var focusTarget: View? = null
        items.forEachIndexed { i, item ->
            val rowBg = GradientDrawable().apply { cornerRadius = dp(11).toFloat(); setColor(Color.TRANSPARENT) }
            val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; isFocusable = true; background = rowBg; setPadding(du(8), du(6), du(10), du(6)) }
            if (item.glyph >= 0) { val ic = FrameLayout(this).apply { background = GradientDrawable().apply { cornerRadius = dp(7).toFloat(); setColor(Color.parseColor(item.tint)) } }
                ic.addView(GlyphView(this, item.glyph), FrameLayout.LayoutParams(matchP, matchP)); r.addView(ic, LinearLayout.LayoutParams(du(26), du(26)).apply { setMargins(0, 0, du(10), 0) }) }
            val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            if (item.label.isNotEmpty()) col.addView(TextView(this).apply { text = item.label; textSize = sp(13f); setTextColor(cText()) })
            item.sub?.let { col.addView(TextView(this).apply { text = it; textSize = sp(10.5f); setTextColor(cSub()) }) }
            r.addView(col, LinearLayout.LayoutParams(0, wrap, 1f))
            val sw: SwitchView? = if (item.toggle != null) SwitchView(this, item.toggle, lightTheme).also { r.addView(it, LinearLayout.LayoutParams(du(38), du(23))) } else null
            if (sw == null && selectable) { val ck = GlyphView(this, GlyphView.CHECK); ck.setTint(cText()); ck.visibility = if (i == checked) View.VISIBLE else View.INVISIBLE; r.addView(ck, LinearLayout.LayoutParams(du(18), du(18))); checks[i] = ck }
            else if (sw == null && item.arrow) { val ch = GlyphView(this, GlyphView.CHEVRON); ch.setTint(Color.parseColor("#8E8E99")); r.addView(ch, LinearLayout.LayoutParams(du(16), du(16))) }
            r.setOnFocusChangeListener { _, has -> rowBg.setColor(if (has) cFocus() else Color.TRANSPARENT); rowBg.setStroke(if (has) dp(1) else 0, cFocusStroke()) }
            rowViews.add(r)
            r.setOnClickListener { if (tooSoon()) return@setOnClickListener
                if (sw != null) { sw.flip(); onPick(i) }
                else if (stayOpen) { checks.forEachIndexed { k, v -> v?.visibility = if (k == i) View.VISIBLE else View.INVISIBLE }; onPick(i) } else { dlg.dismiss(); onPick(i) } }
            list.addView(r, LinearLayout.LayoutParams(matchP, wrap).apply { setMargins(0, dp(1), 0, dp(1)) })
            if (i == (if (focusAt >= 0) focusAt else if (checked >= 0) checked else 0)) focusTarget = r
        }
        box.addView(fitList(list, 310, rowViews))
        box.addView(footView(backText(parent)))
        dlg.setContentView(box); styleWindow(dlg, 310); registerDialog(dlg)
        dlg.setOnCancelListener { parent?.invoke() }; dlg.setOnShowListener { focusTarget?.requestFocus() }; dlg.show()
    }

    private fun showInput(title: String, hint: String, initial: String, parent: (() -> Unit)?, onDone: (String) -> Unit) {
        val dlg = PanelDialog(); val box = panelBox(); box.addView(titleView(title, crumbs(parent)))
        val et = EditText(this).apply { setText(initial); this.hint = hint; setHintTextColor(Color.parseColor("#7C7C88")); setTextColor(cText()); textSize = sp(16f); setSingleLine(); imeOptions = EditorInfo.IME_ACTION_DONE
            background = GradientDrawable().apply { cornerRadius = dp(12).toFloat(); setColor(cField()) }; setPadding(dp(14), dp(10), dp(14), dp(10)) }
        et.setOnEditorActionListener { v, a, _ -> if (a == EditorInfo.IME_ACTION_DONE || a == EditorInfo.IME_ACTION_SEARCH) { dlg.dismiss(); onDone(v.text.toString().trim()); true } else false }
        box.addView(et, LinearLayout.LayoutParams(matchP, wrap)); box.addView(footView(backText(parent)))
        dlg.setContentView(box); styleWindow(dlg, 320); registerDialog(dlg); dlg.setOnCancelListener { parent?.invoke() }; dlg.show()
    }

    private fun showMenu(app: AppItem) {
        showPanel("Seçenekler", listOf(PItem("Taşı", GlyphView.MOVE, "#4C7DF0"), PItem("Gizle", GlyphView.EYE_OFF, "#8A6BD6"), PItem("Kaldır", GlyphView.TRASH, "#C25A5A"), PItem("Uygulama Bilgisi", GlyphView.INFO, "#6F7684")), -1, null, false) { w -> when (w) { 0 -> startMove(app); 1 -> hide(app); 2 -> uninstall(app); 3 -> appInfo(app); else -> {} } }
    }
    private fun showHidden(parent: (() -> Unit)? = null) {
        if (hiddenApps.isEmpty()) { Toast.makeText(this, "Gizli uygulama yok", Toast.LENGTH_SHORT).show(); parent?.invoke(); return }
        val dlg = PanelDialog()
        val box = panelBox(); box.addView(titleView("Gizli Uygulamalar", crumbs(parent))); box.addView(TextView(this).apply { text = "Ana ekrana geri almak için seç"; textSize = sp(10.5f); setTextColor(cSub()); setPadding(dp(10), 0, dp(10), dp(8)) })
        box.addView(View(this).apply { setBackgroundColor(cDiv()) }, LinearLayout.LayoutParams(matchP, dp(1)).apply { setMargins(0, 0, 0, dp(10)) })
        val ncol = 3; val tw = 90; val th = 51; val gap = 9
        // Büyüyen (seçili) kutu kenarlardan kesilmesin diye pay bırak, kırpmayı kapat
        val gridL = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; clipChildren = false; clipToPadding = false; setPadding(du(8), du(6), du(8), du(6)) }
        var rowL: LinearLayout? = null; var first: View? = null
        hiddenApps.forEach { app ->
            if (rowL == null || rowL!!.childCount >= ncol) { rowL = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; clipChildren = false }; gridL.addView(rowL, LinearLayout.LayoutParams(wrap, wrap).apply { setMargins(0, 0, 0, du(gap)) }) }
            val tileBg = GradientDrawable().apply { cornerRadius = dp(12).toFloat(); setColor(if (needsLightBg(app)) Color.parseColor("#ECECF2") else Color.parseColor("#2A2C36")) }
            val ring = GradientDrawable().apply { cornerRadius = dp(12).toFloat(); setColor(Color.TRANSPARENT); setStroke(dp(1), Color.argb(40, 255, 255, 255)) }
            val f = FrameLayout(this).apply { background = tileBg; foreground = ring; isFocusable = true; clipToOutline = true }
            val iv = ImageView(this).apply { setImageDrawable(app.image); if (app.isBanner) scaleType = ImageView.ScaleType.CENTER_CROP else { scaleType = ImageView.ScaleType.FIT_CENTER; setPadding(dp(12), dp(8), dp(12), dp(8)) } }
            f.addView(iv, FrameLayout.LayoutParams(matchP, matchP))
            f.setOnFocusChangeListener { v, has -> if (has) { animView(v, 1.1f, z = dp(6).toFloat(), dur = 120); ring.setStroke(dp(2), accent()) } else { animView(v, 1f, z = 0f, dur = 120); ring.setStroke(dp(1), Color.argb(40, 255, 255, 255)) } }
            f.setOnClickListener { if (!tooSoon()) { dlg.dismiss(); unhide(app) } }
            f.layoutParams = LinearLayout.LayoutParams(du(tw), du(th)).apply { setMargins(0, 0, if (rowL!!.childCount < ncol - 1) du(gap) else 0, 0) }
            rowL!!.addView(f); if (first == null) first = f
        }
        val rows = (hiddenApps.size + ncol - 1) / ncol
        box.addView(ScrollView(this).apply { isVerticalScrollBarEnabled = false; clipChildren = false; isVerticalFadingEdgeEnabled = true; setFadingEdgeLength(du(24)); addView(gridL) }, LinearLayout.LayoutParams(wrap, minOf(du(rows * (th + gap) + 12), panelListMax())).apply { gravity = Gravity.CENTER_HORIZONTAL })
        box.addView(footView(backText(parent)))
        dlg.setContentView(box); styleWindow(dlg, 330); registerDialog(dlg); dlg.setOnCancelListener { parent?.invoke() }; dlg.setOnShowListener { first?.requestFocus() }; dlg.show()
    }

    // ---------- AYARLAR (bölümlü) ----------
    private val topScales = floatArrayOf(0.7f, 0.85f, 1.0f, 1.15f)
    private val topLabels = listOf("Çok Küçük", "Küçük", "Orta", "Büyük")
    private fun applyTopScale() { val i = prefs.getInt("topScale", 1).coerceIn(0, topScales.size - 1); topPill.scaleX = topScales[i]; topPill.scaleY = topScales[i]
        if (::wxCard.isInitialized) { wxCard.scaleX = topScales[i]; wxCard.scaleY = topScales[i] }
        if (::gridBox.isInitialized) topPill.post { layoutGrid() } }

    private fun customBgFile() = File(filesDir, "custom_bg.jpg")
    // Önceki arka plan: arka plan her değiştiğinde bir önceki hali (fotoğrafsa dosyasıyla) saklanır; tek basışla geri gelir
    private fun prevBgFile() = File(filesDir, "prev_bg.jpg")
    private fun rememberBg() {
        val custom = prefs.getBoolean("bgCustom", false)
        if (custom) { val f = customBgFile(); if (!f.exists()) return; try { f.copyTo(prevBgFile(), true) } catch (_: Exception) { return } }
        prefs.edit().putBoolean("prevSet", true).putBoolean("prevCustom", custom).putInt("prevBg", prefs.getInt("bg", 0))
            .putString("prevWebId", prefs.getString("bgWebId", "") ?: "").putString("prevCaption", prefs.getString("bgCaption", "") ?: "").apply()
    }
    private fun restorePrevBg() {
        if (!prefs.getBoolean("prevSet", false)) return
        val pc = prefs.getBoolean("prevCustom", false); if (pc && !prevBgFile().exists()) return
        val cc = prefs.getBoolean("bgCustom", false); val cb = prefs.getInt("bg", 0); val cw = prefs.getString("bgWebId", "") ?: ""; val ccap = prefs.getString("bgCaption", "") ?: ""
        try { val tmp = File(filesDir, "swap_bg.jpg"); if (cc) customBgFile().copyTo(tmp, true)
            if (pc) prevBgFile().copyTo(customBgFile(), true)
            if (cc) { prevBgFile().delete(); tmp.renameTo(prevBgFile()) } else tmp.delete() } catch (_: Exception) { return }
        prefs.edit().putBoolean("bgCustom", pc).putInt("bg", prefs.getInt("prevBg", 0)).putString("bgWebId", prefs.getString("prevWebId", "") ?: "").putString("bgCaption", prefs.getString("prevCaption", "") ?: "")
            .putBoolean("prevCustom", cc).putInt("prevBg", cb).putString("prevWebId", cw).putString("prevCaption", ccap).apply()
        applyBg(); setDynBg(!pc && bgPresets[prefs.getInt("bg", 0).coerceIn(0, bgPresets.size - 1)].second != null)
    }
    private fun prevBgThumb(): Drawable? = if (prefs.getBoolean("prevCustom", false)) {
        val f = prevBgFile(); if (!f.exists()) null else { val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }; BitmapFactory.decodeFile(f.path, o); var sm = 1; while (o.outWidth / sm > 240) sm *= 2
            BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = sm })?.let { android.graphics.drawable.BitmapDrawable(resources, it) } } }
        else { val c = bgPresets[prefs.getInt("prevBg", 0).coerceIn(0, bgPresets.size - 1)].second; if (c == null) classicThumb() else GradientDrawable(GradientDrawable.Orientation.TL_BR, c) }
    private fun decodeBg(maxW: Int): android.graphics.Bitmap? { val f = customBgFile(); if (!f.exists()) return null
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }; BitmapFactory.decodeFile(f.path, o); var s = 1; while (o.outWidth / s > maxW) s *= 2
        return BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = s }) }
    private fun classicThumb(): Drawable = resources.getDrawable(R.drawable.bg, theme)
    private fun customThumb(): Drawable? = decodeBg(240)?.let { android.graphics.drawable.BitmapDrawable(resources, it) }
    private fun applyBg() {
        if (prefs.getBoolean("bgCustom", false)) { Thread { val bmp = decodeBg(1920); handler.post { if (bmp != null) bgView.setImageBitmap(bmp) else bgView.setImageResource(R.drawable.bg); frostBgCache = null; markFrostDirty(); refreshPillFrost() } }.start() }
        else { val idx = prefs.getInt("bg", 0).coerceIn(0, bgPresets.size - 1); val colors = bgPresets[idx].second
            if (colors == null) bgView.setImageResource(R.drawable.bg) else bgView.setImageDrawable(GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, colors)) }
        if (Build.VERSION.SDK_INT >= 31) { val b = blurValues[prefs.getInt("blur", 0).coerceIn(0, blurValues.size - 1)]
            bgView.setRenderEffect(if (b > 0) RenderEffect.createBlurEffect(b.toFloat(), b.toFloat(), Shader.TileMode.CLAMP) else null) }
        frostBgCache = null; markFrostDirty(); refreshPillFrost(); applyBgInfo()
    }
    private fun applyBgInfo() { if (!::bgInfoView.isInitialized) return
        val cap = if (prefs.getBoolean("bgInfo", false) && prefs.getBoolean("bgCustom", false)) prefs.getString("bgCaption", "") ?: "" else ""
        bgInfoView.text = cap; bgInfoView.visibility = if (cap.isNotEmpty()) View.VISIBLE else View.GONE }
    // Bing başlıklarının sonundaki "(© ...)" telif kısmı kısaltılır: "Kapadokya, Türkiye (© Ad/Getty)" -> "Kapadokya, Türkiye"
    private fun cleanCaption(c: String): String = c.substringBefore(" (©").substringBefore("(©").trim()
    private fun applyScrim() { scrimView.alpha = scrimFr[prefs.getInt("scrim", 2).coerceIn(0, scrimFr.size - 1)]; markFrostDirty() }

    // Ayarlar iki seviyeli: Ana menü (bölümler) -> bölüm içeriği -> seçenek paneli
    // Geri: seçenek -> bölüm -> ana menü -> kapat
    // İmleç hafızası: Ayarlar dişliden her açıldığında her şey en üstten başlar; bir bölüme ana menüden girince de en üstten
    // başlar. Bir alt panelden Geri ile dönünce imleç en son girilen satırda durur.
    private val catNames = listOf("Ana Ekran", "Görünüm", "Ekran Koruyucu", "Hava Durumu")
    private val CAT_HOME = 0; private val CAT_LOOK = 1; private val CAT_SAVER = 2; private val CAT_WX = 3
    private var curCat = 0
    private var mainRow = 0
    private val catRow = IntArray(4)
    private val MAIN_RESET_ROW = 6
    private val backToCat: () -> Unit = { showCategory(curCat) }
    private val backToMain: () -> Unit = { showSettings() }
    private fun backText(parent: (() -> Unit)?): String = when {
        parent == null -> "‹  Geri: Kapat"
        parent === backToCat -> "‹  Geri: " + catNames[curCat]
        parent === backToMain -> "‹  Geri: Ayarlar"
        parent === backToBg -> "‹  Geri: Arka Plan"
        parent === backToSources -> "‹  Geri: Fotoğraf Seç"
        else -> "‹  Geri: Önceki Menü"
    }
    // Dişliden açılış: bütün imleç hafızası sıfırlanır
    private fun openSettingsFresh() { curCat = 0; mainRow = 0; catRow.fill(0); srcRow = 0; showSettings() }

    // focusAt: geri dönünce imleç en son girilen satırda dursun; onPicked: hangi satıra girildiğini kaydet
    // gaps: bu satırlardan önce ince ayraç çiz (ilgili ayarları gruplamak için)
    private fun showMenuList(title: String, rows: List<Pair<PItem, () -> Unit>>, parent: (() -> Unit)?, focusAt: Int = 0, gaps: Set<Int> = emptySet(), onPicked: (Int) -> Unit = {}) {
        val dlg = PanelDialog(); val box = panelBox()
        box.addView(titleView(title, crumbs(parent)))
        box.addView(View(this).apply { setBackgroundColor(cDiv()) }, LinearLayout.LayoutParams(matchP, dp(1)).apply { setMargins(0, 0, 0, dp(6)) })
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        var first: View? = null; val rowViews = ArrayList<View>()
        rows.forEachIndexed { idx, (item, go) ->
            if (idx in gaps) list.addView(View(this).apply { setBackgroundColor(cDiv()) }, LinearLayout.LayoutParams(matchP, dp(1)).apply { setMargins(dp(10), dp(6), dp(10), dp(6)) })
            // Anahtarlı satırlar (aç/kapa) paneli kapatmadan yerinde değişir
            val v = menuRow(item) { onPicked(idx); if (item.toggle == null) dlg.dismiss(); go() }
            list.addView(v, LinearLayout.LayoutParams(matchP, wrap).apply { setMargins(0, dp(1), 0, dp(1)) }); rowViews.add(v)
            if (idx == focusAt.coerceIn(0, rows.size - 1)) first = v
        }
        box.addView(fitList(list, 330, rowViews))
        box.addView(footView(backText(parent)))
        dlg.setContentView(box); styleWindow(dlg, 330); registerDialog(dlg)
        dlg.setOnCancelListener { parent?.invoke() }; dlg.setOnShowListener { first?.requestFocus() }; dlg.show()
    }

    private fun showSettings() {
        // Ana menüden bir bölüme girince o bölüm her zaman en üstten başlar
        fun enter(c: Int): () -> Unit = { catRow[c] = 0; showCategory(c) }
        val city = prefs.getString("city", null)
        showMenuList("Ayarlar", listOf(
            PItem("Ana Ekran", GlyphView.GRID, "#4C7DF0", sub = "Üst bar ve kutular", arrow = true) to enter(CAT_HOME),
            PItem("Görünüm", GlyphView.PALETTE, "#8A6BD6", sub = "Tema, yazı boyutu, arka plan", arrow = true) to enter(CAT_LOOK),
            PItem("Ekran Koruyucu", GlyphView.MONITOR, "#3FA27A", sub = "Zamanlama, arka plan, yazı boyutu", arrow = true) to enter(CAT_SAVER),
            PItem("Hava Durumu", GlyphView.CLOUD, "#3A9DB8", sub = city ?: "Konum, güncelleme süresi ve kaynak", arrow = true) to enter(CAT_WX),
            PItem("Gizli Uygulamalar", GlyphView.EYE_OFF, "#5B4B9A", sub = if (hiddenApps.isEmpty()) "Gizli uygulama yok" else hiddenApps.size.toString() + " uygulama", arrow = true) to { showHidden(backToMain) },
            PItem("Android Ayarları", GlyphView.GEAR, "#6F7684", sub = "TV'nin sistem ayarlarını aç", arrow = true) to { openSystem(Settings.ACTION_SETTINGS) },
            PItem("Varsayılana Sıfırla", GlyphView.RESET, "#C25A5A", sub = "Ayarları ilk hâline döndür", arrow = true) to { showResetPanel() }
        ), null, mainRow, gaps = setOf(4, 5)) { mainRow = it }
    }

    private fun showCategory(c: Int) {
        curCat = c
        val rows: List<Pair<PItem, () -> Unit>>; val gaps: Set<Int>
        when (c) {
            // Ana ekran: üst bar · kutular
            CAT_HOME -> {
                rows = listOf(
                    PItem("Üst Bar Boyutu", GlyphView.SLIDERS, "#3FA27A", sub = topLabels[prefs.getInt("topScale", 1).coerceIn(0, topLabels.size - 1)], arrow = true,
                        adjust = { d -> stepPref("topScale", 1, topScales.size, d)?.let { applyTopScale(); topLabels[it] } }) to { showTopPanel() },
                    PItem("Üst Bar Konumu", GlyphView.MOVE, "#4C7DF0", sub = barPosName(), arrow = true,
                        adjust = { d -> val v = if (d > 0) 2 else 0; if (v == barPos()) null else { prefs.edit().putInt("barPos", v).apply(); applyBarPos(); catRow[CAT_HOME] = 1; topPill.post { showCategory(CAT_HOME) }; barPosName() } }) to { showBarPosPanel() },
                    PItem("Wi-Fi ve Ayar Düğmesi", GlyphView.GEAR, "#6F7684", sub = topButtonsLabel(), arrow = true) to { showTopButtonsPanel() },
                    PItem("Kutu Boyutu", GlyphView.GRID, "#4C7DF0", sub = "$cols sütun · kaydırarak ayarla", arrow = true,
                        adjust = { d -> val w = (tileW + d * sizeStep).coerceIn(sizeMin, sizeMax); if (w == tileW) null else { prefs.edit().putInt("tileW", w).remove("cols").apply(); rebuildSoon(); colsFor(w).toString() + " sütun · kaydırarak ayarla" } }) to { showSizePanel() },
                    PItem("Kutu Aralığı", GlyphView.SLIDERS, "#3FA27A", sub = gapNames[prefs.getInt("gap", 1).coerceIn(0, 2)], arrow = true,
                        adjust = { d -> stepPref("gap", 1, gapNames.size, d)?.let { rebuildSoon(); gapNames[it] } }) to { showGapPanel() },
                    PItem("Kutu Köşeleri", GlyphView.CORNER, "#8A6BD6", sub = radiusNames[prefs.getInt("radius", 1).coerceIn(0, 3)], arrow = true,
                        adjust = { d -> stepPref("radius", 1, radiusNames.size, d)?.let { rebuildSoon(); radiusNames[it] } }) to { showRadiusPanel() },
                    PItem("Kutu Saydamlığı", GlyphView.OPACITY, "#3A9DB8", sub = tileAlphaNames[prefs.getInt("tileAlpha", 0).coerceIn(0, 2)], arrow = true,
                        adjust = { d -> stepPref("tileAlpha", 0, tileAlphaNames.size, d)?.let { rebuildSoon(); tileAlphaNames[it] } }) to { showTileAlphaPanel() },
                    PItem("Seçili Kutu Büyümesi", GlyphView.ZOOM, "#D98A4E", sub = zoomNames[prefs.getInt("zoom", 1).coerceIn(0, 2)], arrow = true,
                        adjust = { d -> stepPref("zoom", 1, zoomNames.size, d)?.let { rebuildSoon(); zoomNames[it] } }) to { showZoomPanel() },
                    PItem("Kutu Büyüme Hızı", GlyphView.CLOCK, "#B07A3E", sub = animNames[prefs.getInt("anim", 1).coerceIn(0, 2)], arrow = true,
                        adjust = { d -> stepPref("anim", 1, animNames.size, d)?.let { animNames[it] } }) to { showAnimPanel() },
                    PItem("Işık Parlaması", GlyphView.BLUR, "#B8A04A", sub = "Seçili kutuda cam yansıması", toggle = prefs.getBoolean("shine", true)) to { prefs.edit().putBoolean("shine", !prefs.getBoolean("shine", true)).apply() }
                )
                gaps = setOf(3)
            }
            // Görünüm
            CAT_LOOK -> {
                val bgName = if (prefs.getBoolean("bgCustom", false)) "Seçilen Fotoğraf" else bgPresets[prefs.getInt("bg", 0).coerceIn(0, bgPresets.size - 1)].first
                rows = listOf(
                    PItem("Tema", GlyphView.CONTRAST, "#5B6B8C", sub = themeNames[themeIdx], arrow = true) to { showThemePanel() },
                    PItem("Yazı Boyutu", GlyphView.SLIDERS, "#4C7DF0", sub = "%" + Math.round(ui * 100) + " · ayar panelleri", arrow = true) to { showUiScalePanel() },
                    PItem("Arka Plan", GlyphView.IMAGE, "#8A6BD6", sub = bgName, arrow = true) to { showBgPanel() },
                    PItem("Bulanıklık", GlyphView.BLUR, "#5B8BD0", sub = blurNames[prefs.getInt("blur", 0).coerceIn(0, 3)], arrow = true,
                        adjust = { d -> stepPref("blur", 0, blurNames.size, d)?.let { applyBg(); blurNames[it] } }) to { showBlurPanel() },
                    PItem("Karartma", GlyphView.CONTRAST, "#6F7684", sub = scrimNames[prefs.getInt("scrim", 2).coerceIn(0, 3)], arrow = true,
                        adjust = { d -> stepPref("scrim", 2, scrimNames.size, d)?.let { applyScrim(); scrimNames[it] } }) to { showScrimPanel() },
                    PItem("Dinamik Renk", GlyphView.PALETTE, "#C2557A", sub = "Seçili uygulamanın rengi arka plana yansır", toggle = prefs.getBoolean("dynBg", true)) to { setDynBg(!prefs.getBoolean("dynBg", true)) },
                    PItem("Fotoğraf Bilgisi", GlyphView.INFO, "#5B8BD0", sub = "Arka plan fotoğrafının adı sol alt köşede", toggle = prefs.getBoolean("bgInfo", false)) to { prefs.edit().putBoolean("bgInfo", !prefs.getBoolean("bgInfo", false)).apply(); applyBgInfo() }
                )
                gaps = emptySet()
            }
            // Ekran koruyucu: ayarlar · önizleme
            CAT_SAVER -> {
                val saverOn = prefs.getBoolean("saver", true); val sm = prefs.getInt("saverMin", 1).coerceIn(0, saverMins.size - 1)
                rows = listOf(
                    PItem("Zamanlama", GlyphView.CLOCK, "#5B8BD0", sub = if (saverOn) saverLabel(saverMins[sm]) + " Sonra" else "Kapalı", arrow = true,
                        adjust = { d -> val cur = if (prefs.getBoolean("saver", true)) prefs.getInt("saverMin", 1).coerceIn(0, saverMins.size - 1) else -1
                            val n = (cur + d).coerceIn(-1, saverMins.size - 1)
                            if (n == cur) null else { if (n < 0) prefs.edit().putBoolean("saver", false).apply() else prefs.edit().putBoolean("saver", true).putInt("saverMin", n).apply()
                                resetSaverTimer(); if (n < 0) "Kapalı" else saverLabel(saverMins[n]) + " Sonra" } }) to { showSaverPanel() },
                    PItem("Arka Plan", GlyphView.IMAGE, "#3A9DB8", sub = saverBgNames[prefs.getInt("saverBg", 0).coerceIn(0, 1)], arrow = true,
                        adjust = { d -> stepPref("saverBg", 0, saverBgNames.size, d)?.let { if (it == 0) fetchBing(true); saverBgNames[it] } }) to { showSaverBgPanel() },
                    PItem("Yazı Boyutu", GlyphView.SLIDERS, "#8A6BD6", sub = "%" + Math.round(saverScale() * 100) + " · canlı önizlemeyle", arrow = true) to { showSaverTextPanel() },
                    PItem("Hava Durumunu Göster", GlyphView.CLOUD, "#3FA27A", sub = "Saatin altında", toggle = prefs.getBoolean("saverWx", true)) to { prefs.edit().putBoolean("saverWx", !prefs.getBoolean("saverWx", true)).apply() },
                    PItem("Önizleme", GlyphView.MONITOR, "#6F7684", sub = "Herhangi bir tuşla çıkılır", arrow = true) to { showSaver() }
                )
                gaps = setOf(4)
            }
            // Hava durumu
            else -> {
                rows = listOf(
                    PItem("Konum Bilgisi", GlyphView.CLOUD, "#3A9DB8", sub = prefs.getString("city", null) ?: "Seçilmedi · mahalle, sokak ya da şehir", arrow = true) to { showCitySearch(backToCat) },
                    PItem("Güncelleme Süresi", GlyphView.CLOCK, "#3FA27A", sub = wxEveryNames[prefs.getInt("wxEvery", 2).coerceIn(0, 3)], arrow = true,
                        adjust = { d -> stepPref("wxEvery", 2, wxEveryNames.size, d)?.let { wxEveryNames[it] } }) to { showWxEveryPanel() },
                    PItem("Kaynak", GlyphView.CLOUD, "#5B8BD0", sub = wxSources[prefs.getInt("wxSrc", 0).coerceIn(0, wxSources.size - 1)], arrow = true,
                        adjust = { d -> stepPref("wxSrc", 0, wxSources.size, d)?.let { prefs.edit().remove("wxfull").apply(); lastWeather = System.currentTimeMillis(); fetchWeather(); wxSources[it] } }) to { showWxSrcPanel() },
                    PItem("Hava Durumu Paneli", GlyphView.CLOUD, "#4C7DF0", sub = "Üst barın karşı köşesinde ayrıntılı bilgi", toggle = wxPanelOn()) to { prefs.edit().putBoolean("wxPanel", !wxPanelOn()).apply(); applyWxPanel() }
                )
                gaps = setOf(3)
            }
        }
        showMenuList(catNames[c], rows, backToMain, catRow[c], gaps) { catRow[c] = it }
    }
    // Seçenek adları (hem panelde hem bölüm satırının alt yazısında aynı ad kullanılır)
    private val gapNames = listOf("Dar", "Orta", "Geniş")
    private val radiusNames = listOf("Az", "Orta", "Çok", "Tam")
    private val tileAlphaNames = listOf("Dolu", "Hafif", "Çok Saydam")
    private val zoomNames = listOf("Az", "Orta", "Çok")
    private val animNames = listOf("Hızlı", "Normal", "Yavaş")
    private val blurNames = listOf("Kapalı", "Az", "Orta", "Çok")
    private val scrimNames = listOf("Yok", "Az", "Orta", "Çok")
    private val saverBgNames = listOf("Bing Günün Fotoğrafları", "Siyah")

    // Üst bardaki Wi-Fi ve ayar düğmeleri. Ayar düğmesi kapalıyken gizli durur, yukarı tuşuyla bara çıkınca belirir.
    private fun showWifiBtn() = prefs.getBoolean("showWifi", true)
    private fun showGearBtn() = prefs.getBoolean("showGear", true)
    private fun topButtonsLabel(): String = when {
        showWifiBtn() && showGearBtn() -> "İkisi de görünür"
        showWifiBtn() -> "Ayar düğmesi gizli"
        showGearBtn() -> "Wi-Fi düğmesi gizli"
        else -> "İkisi de gizli"
    }
    private fun showTopButtonsPanel() {
        showMenuList("Wi-Fi ve Ayar Düğmesi", listOf(
            PItem("Wi-Fi Düğmesi", GlyphView.MONITOR, "#5B8BD0", sub = "Üst barda göster", toggle = showWifiBtn()) to { prefs.edit().putBoolean("showWifi", !showWifiBtn()).apply(); applyTopItems() },
            PItem("Ayar Düğmesi", GlyphView.GEAR, "#6F7684", sub = "Kapalıyken yukarı tuşuyla bara çıkınca belirir", toggle = showGearBtn()) to { prefs.edit().putBoolean("showGear", !showGearBtn()).apply(); applyTopItems() }
        ), backToCat)
    }

    // Yerinde ayar yardımcıları: değer bir adım değişir (uçlarda durur); kutu değişiklikleri art arda basışta bir kez çizilir
    private fun stepPref(key: String, def: Int, count: Int, d: Int): Int? { val cur = prefs.getInt(key, def).coerceIn(0, count - 1); val n = (cur + d).coerceIn(0, count - 1)
        if (n == cur) return null; prefs.edit().putInt(key, n).apply(); return n }
    private val rebuildLater = Runnable { rebuildRows(lastPkg) }
    private fun rebuildSoon() { handler.removeCallbacks(rebuildLater); handler.postDelayed(rebuildLater, 200) }
    private fun choice(title: String, labels: List<String>, cur: Int, key: String, apply: () -> Unit) {
        showPanel(title, labels.map { PItem(it) }, cur, backToCat, true) { i -> prefs.edit().putInt(key, i).apply(); apply() }
    }
    // Tema değişince arayüz baştan kurulur; ardından ayarlar Görünüm'de yeniden açılır
    private fun showThemePanel() = choice("Tema", themeNames, themeIdx, "theme") { prefs.edit().putBoolean("reopen", true).apply(); handler.postDelayed({ recreate() }, 150) }
    // Yazı boyutu (ayar panelleri): ◀ ▶ ile değişir, panel anında yeni boyutla yeniden çizilir (canlı önizleme)
    private val uiSteps = floatArrayOf(0.8f, 0.85f, 0.9f, 0.95f, 1f, 1.05f, 1.1f, 1.15f, 1.2f, 1.25f, 1.3f, 1.4f, 1.5f)
    private fun showUiScalePanel() {
        var lvl = uiSteps.indices.minByOrNull { Math.abs(uiSteps[it] - ui) } ?: 4
        val dlg = PanelDialog(); val box = panelBox(); box.addView(titleView("Yazı Boyutu", crumbs(backToCat)))
        box.addView(View(this).apply { setBackgroundColor(cDiv()) }, LinearLayout.LayoutParams(matchP, dp(1)).apply { setMargins(0, 0, 0, du(10)) })
        box.addView(menuRow(PItem("Örnek Ayar Satırı", GlyphView.PALETTE, "#8A6BD6", sub = "Yazılar ve çerçeve bu boyutta görünecek", arrow = true)) {}.apply { isFocusable = false })
        val info = TextView(this).apply { textSize = sp(13.5f); setTextColor(cText()); gravity = Gravity.CENTER; text = "%" + Math.round(uiSteps[lvl] * 100) }
        val track = object : View(this) {
            val pp = Paint(Paint.ANTI_ALIAS_FLAG); var focusedNow = false
            override fun onDraw(c: Canvas) { val h = height / 2f; val l = dp(14).toFloat(); val r = width - l; val x = l + (r - l) * lvl / (uiSteps.size - 1)
                pp.color = cField(); c.drawRoundRect(RectF(l, h - dp(3), r, h + dp(3)), dp(3).toFloat(), dp(3).toFloat(), pp)
                pp.color = accent(); c.drawRoundRect(RectF(l, h - dp(3), x, h + dp(3)), dp(3).toFloat(), dp(3).toFloat(), pp)
                pp.color = cKnob(); c.drawCircle(x, h, dp(if (focusedNow) 11 else 9).toFloat(), pp) }
        }.apply { isFocusable = true }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        row.addView(TextView(this).apply { text = "A"; textSize = 11f; setTextColor(cText()) }); row.addView(track, LinearLayout.LayoutParams(0, dp(40), 1f)); row.addView(TextView(this).apply { text = "A"; textSize = 18f; setTextColor(cText()) })
        track.setOnFocusChangeListener { _, has -> track.focusedNow = has; track.invalidate() }
        track.setOnKeyListener { _, k, e ->
            if (e.action != KeyEvent.ACTION_DOWN) return@setOnKeyListener false
            when (k) {
                KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT -> { val nl = (lvl + if (k == KeyEvent.KEYCODE_DPAD_RIGHT) 1 else -1).coerceIn(0, uiSteps.size - 1)
                    if (nl != lvl) { lvl = nl; prefs.edit().putFloat("uiScale", uiSteps[lvl]).apply(); showUiScalePanel() }; true }
                KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> { if (!tooSoon()) { dlg.dismiss(); backToCat() }; true }
                else -> false
            } }
        box.addView(info, LinearLayout.LayoutParams(matchP, wrap).apply { setMargins(0, du(8), 0, 0) })
        box.addView(row, LinearLayout.LayoutParams(matchP, wrap).apply { setMargins(dp(6), 0, dp(6), dp(4)) })
        box.addView(TextView(this).apply { text = "◀ ▶ ile ayarla, panel hemen değişir · OK: kaydet"; textSize = sp(10.5f); setTextColor(cSub()); gravity = Gravity.CENTER })
        box.addView(footView(backText(backToCat)))
        dlg.setContentView(box); styleWindow(dlg, 330); registerDialog(dlg)
        dlg.setOnCancelListener { backToCat() }; dlg.setOnShowListener { track.requestFocus() }; dlg.show()
    }
    private fun showScrimPanel() = choice("Karartma", scrimNames, prefs.getInt("scrim", 2), "scrim") { applyScrim() }
    private fun showBlurPanel() = choice("Bulanıklık", blurNames, prefs.getInt("blur", 0), "blur") { applyBg() }
    private fun showRadiusPanel() = choice("Kutu Köşeleri", radiusNames, prefs.getInt("radius", 1), "radius") { rebuildRows(lastPkg) }
    private fun showTileAlphaPanel() = choice("Kutu Saydamlığı", tileAlphaNames, prefs.getInt("tileAlpha", 0), "tileAlpha") { rebuildRows(lastPkg) }
    private fun showZoomPanel() = choice("Seçili Kutu Büyümesi", zoomNames, prefs.getInt("zoom", 1), "zoom") { rebuildRows(lastPkg) }
    // Kaydırmalı kutu boyutu paneli: ◀ ▶ ile anında önizleme, OK kaydet ve dön, Geri dön
    private fun showSizePanel() {
        val dlg = PanelDialog(); val box = panelBox(); box.addView(titleView("Kutu Boyutu", crumbs(backToCat)))
        box.addView(View(this).apply { setBackgroundColor(cDiv()) }, LinearLayout.LayoutParams(matchP, dp(1)).apply { setMargins(0, 0, 0, dp(14)) })
        val levels = (sizeMax - sizeMin) / sizeStep
        var lvl = ((tileW - sizeMin + sizeStep / 2) / sizeStep).coerceIn(0, levels)
        val info = TextView(this).apply { textSize = sp(13.5f); setTextColor(cText()); gravity = Gravity.CENTER }
        val track = object : View(this) {
            val pp = Paint(Paint.ANTI_ALIAS_FLAG); var focusedNow = false
            override fun onDraw(c: Canvas) { val h = height / 2f; val l = dp(14).toFloat(); val r = width - l; val x = l + (r - l) * lvl / levels
                pp.color = cField(); c.drawRoundRect(RectF(l, h - dp(3), r, h + dp(3)), dp(3).toFloat(), dp(3).toFloat(), pp)
                pp.color = accent(); c.drawRoundRect(RectF(l, h - dp(3), x, h + dp(3)), dp(3).toFloat(), dp(3).toFloat(), pp)
                pp.color = cKnob(); c.drawCircle(x, h, dp(if (focusedNow) 11 else 9).toFloat(), pp) }
        }.apply { isFocusable = true }
        val small = GlyphView(this, GlyphView.GRID).apply { scaleX = 0.7f; scaleY = 0.7f; setTint(cText()) }; val big = GlyphView(this, GlyphView.GRID).apply { setTint(cText()) }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        row.addView(small, LinearLayout.LayoutParams(dp(22), dp(22))); row.addView(track, LinearLayout.LayoutParams(0, dp(40), 1f)); row.addView(big, LinearLayout.LayoutParams(dp(26), dp(26)))
        fun refresh() { val w = sizeMin + lvl * sizeStep; info.text = "%" + (lvl * 100 / levels) + "  ·  " + colsFor(w) + " sütun"; track.invalidate() }
        val applyLater = Runnable { rebuildRows(lastPkg) }
        track.setOnFocusChangeListener { _, has -> track.focusedNow = has; track.invalidate() }
        track.setOnKeyListener { _, k, e ->
            if (e.action != KeyEvent.ACTION_DOWN) return@setOnKeyListener false
            when (k) {
                KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT -> { val nl = (lvl + if (k == KeyEvent.KEYCODE_DPAD_RIGHT) 1 else -1).coerceIn(0, levels)
                    if (nl != lvl) { lvl = nl; prefs.edit().putInt("tileW", sizeMin + lvl * sizeStep).remove("cols").apply(); refresh(); handler.removeCallbacks(applyLater); handler.postDelayed(applyLater, 180) }; true }
                KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> { if (!tooSoon()) { dlg.dismiss(); backToCat() }; true }
                else -> false
            } }
        box.addView(info, LinearLayout.LayoutParams(matchP, wrap).apply { setMargins(0, 0, 0, dp(4)) })
        box.addView(row, LinearLayout.LayoutParams(matchP, wrap).apply { setMargins(dp(6), 0, dp(6), dp(4)) })
        box.addView(TextView(this).apply { text = "◀ ▶ ile ayarla, değişiklik hemen görünür · OK: kaydet"; textSize = sp(10.5f); setTextColor(cSub()); gravity = Gravity.CENTER })
        box.addView(footView(backText(backToCat))); refresh()
        dlg.setContentView(box); styleWindow(dlg, 330); registerDialog(dlg)
        dlg.setOnCancelListener { handler.removeCallbacks(applyLater); rebuildRows(lastPkg); backToCat() }; dlg.setOnShowListener { track.requestFocus() }; dlg.show()
    }
    private fun showGapPanel() = choice("Kutu Aralığı", gapNames, prefs.getInt("gap", 1), "gap") { rebuildRows(lastPkg) }
    // Üst bar konumu: seçince bar hemen yer değiştirir, panel de yeni konumunda yeniden açılır
    private fun showBarPosPanel(focus: Int = -1) { val cur = if (barPos() == 0) 0 else 1
        showPanel("Üst Bar Konumu", barPosNames.map { PItem(it) }, cur, backToCat, true, focus) { i -> val v = if (i == 0) 0 else 2
            if (v != barPos()) { prefs.edit().putInt("barPos", v).apply(); applyBarPos(); topPill.post { showBarPosPanel(i) } } } }
    private fun showTopPanel() { val cur = prefs.getInt("topScale", 1).coerceIn(0, topScales.size - 1)
        showPanel("Üst Bar Boyutu", topLabels.map { PItem(it) }, cur, backToCat, true) { i -> prefs.edit().putInt("topScale", i).apply(); applyTopScale() } }
    private fun showSaverPanel(focusAt: Int = -1) { val on = prefs.getBoolean("saver", true)
        val items = mutableListOf(PItem("Ekran Koruyucu", GlyphView.MONITOR, "#5B8BD0", toggle = on)); saverMins.forEach { items.add(PItem(saverLabel(it) + " Sonra")) }
        val cur = 1 + prefs.getInt("saverMin", 1).coerceIn(0, saverMins.size - 1)
        showPanel("Zamanlama", items, cur, backToCat, true, if (focusAt >= 0) focusAt else 0) { i ->
            if (i == 0) prefs.edit().putBoolean("saver", !prefs.getBoolean("saver", true)).apply()
            else { val wasOn = prefs.getBoolean("saver", true); prefs.edit().putBoolean("saver", true).putInt("saverMin", i - 1).apply(); if (!wasOn) showSaverPanel(i) }
            resetSaverTimer() } }
    private fun showSaverBgPanel() = choice("Arka Plan", saverBgNames, prefs.getInt("saverBg", 0), "saverBg") { if (prefs.getInt("saverBg", 0) == 0) fetchBing(true) }
    // Yazı boyutu: arkada ekran koruyucu açılır, ◀ ▶ ile boyut anında değişir
    private fun showSaverTextPanel() {
        showSaver(true)
        val dlg = PanelDialog(); val box = panelBox(); box.addView(titleView("Yazı Boyutu", crumbs(backToCat)))
        box.addView(View(this).apply { setBackgroundColor(cDiv()) }, LinearLayout.LayoutParams(matchP, dp(1)).apply { setMargins(0, 0, 0, dp(14)) })
        val levels = 10; var lvl = Math.round((saverScale() - 0.6f) * 10).coerceIn(0, levels)
        val info = TextView(this).apply { textSize = sp(13.5f); setTextColor(cText()); gravity = Gravity.CENTER }
        val track = object : View(this) {
            val pp = Paint(Paint.ANTI_ALIAS_FLAG); var focusedNow = false
            override fun onDraw(c: Canvas) { val h = height / 2f; val l = dp(14).toFloat(); val r = width - l; val x = l + (r - l) * lvl / levels
                pp.color = cField(); c.drawRoundRect(RectF(l, h - dp(3), r, h + dp(3)), dp(3).toFloat(), dp(3).toFloat(), pp)
                pp.color = accent(); c.drawRoundRect(RectF(l, h - dp(3), x, h + dp(3)), dp(3).toFloat(), dp(3).toFloat(), pp)
                pp.color = cKnob(); c.drawCircle(x, h, dp(if (focusedNow) 11 else 9).toFloat(), pp) }
        }.apply { isFocusable = true }
        val small = TextView(this).apply { text = "A"; textSize = sp(11f); setTextColor(cText()) }; val big = TextView(this).apply { text = "A"; textSize = sp(18f); setTextColor(cText()) }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        row.addView(small); row.addView(track, LinearLayout.LayoutParams(0, dp(40), 1f)); row.addView(big)
        fun refresh() { info.text = "%" + Math.round((0.6f + lvl * 0.1f) * 100); track.invalidate() }
        track.setOnFocusChangeListener { _, has -> track.focusedNow = has; track.invalidate() }
        track.setOnKeyListener { _, k, e ->
            if (e.action != KeyEvent.ACTION_DOWN) return@setOnKeyListener false
            when (k) {
                KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT -> { val nl = (lvl + if (k == KeyEvent.KEYCODE_DPAD_RIGHT) 1 else -1).coerceIn(0, levels)
                    if (nl != lvl) { lvl = nl; prefs.edit().putFloat("saverScale", 0.6f + lvl * 0.1f).apply(); refresh(); applySaverText() }; true }
                KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> { if (!tooSoon()) { dlg.dismiss(); backToCat() }; true }
                else -> false
            } }
        box.addView(info, LinearLayout.LayoutParams(matchP, wrap).apply { setMargins(0, 0, 0, dp(4)) })
        box.addView(row, LinearLayout.LayoutParams(matchP, wrap).apply { setMargins(dp(6), 0, dp(6), dp(4)) })
        box.addView(TextView(this).apply { text = "◀ ▶ ile ayarla, arkada hemen görünür · OK: kaydet"; textSize = sp(10.5f); setTextColor(cSub()); gravity = Gravity.CENTER })
        box.addView(footView(backText(backToCat))); refresh()
        dlg.setContentView(box); styleWindow(dlg, 330); registerDialog(dlg)
        dlg.setOnDismissListener { openDialogs.remove(dlg); if (saverPreview) hideSaver(); resetSaverTimer() }
        dlg.setOnCancelListener { backToCat() }; dlg.setOnShowListener { track.requestFocus() }; dlg.show()
    }
    private fun showWxSrcPanel() = choice("Kaynak", listOf("MET Norway (yr.no)", "Open-Meteo", "MGM · Türkiye Resmî Meteoroloji (Önerilen)"), prefs.getInt("wxSrc", 0), "wxSrc") { prefs.edit().remove("wxfull").apply(); lastWeather = System.currentTimeMillis(); fetchWeather() }
    private fun showAnimPanel() = choice("Kutu Büyüme Hızı", animNames, prefs.getInt("anim", 1), "anim") {}
    // Sıfırlama: onay paneli, iki seçenek. Konum ve hava verisi korunur.
    private fun showResetPanel() {
        showPanel("Varsayılana Sıfırla", listOf(
            PItem("Ayarları Sıfırla", GlyphView.RESET, "#C25A5A", sub = "Uygulama sırası, gizlenenler ve favori fotoğraflar korunur"),
            PItem("Her Şeyi Sıfırla", GlyphView.TRASH, "#9E3B3B", sub = "Sıralama, gizlenenler ve favoriler de sıfırlanır"),
            PItem("Vazgeç", GlyphView.CHEVRON, "#6F7684")), -1, backToMain, false) { i -> if (i == 2) showSettings() else resetSettings(i == 1) }
    }
    private fun resetSettings(everything: Boolean) {
        // Konum, hava verisi ve "Yeni" rozeti kayıtları ayar değildir: her iki sıfırlamada da korunur
        val keep = mutableSetOf("city", "lat", "lon", "il", "ilce", "mgmCur", "mgmDay", "mgmName", "wx", "wxfull", "wxAlerts", "bingAt", "bingMeta", "knownPkgs", "newPkgs")
        if (!everything) keep.addAll(listOf("order", "hidden", "favPhotos"))
        val e = prefs.edit(); for (k in prefs.all.keys) if (k !in keep) e.remove(k); e.commit()
        try { prevBgFile().delete() } catch (_: Exception) {}
        if (everything) try { customBgFile().delete(); File(filesDir, "favthumbs").deleteRecursively() } catch (_: Exception) {}
        // Tema ve yazı boyutu da sıfırlandığı için arayüz baştan kurulur; ardından ayarlar ana menüsü açılır
        Toast.makeText(this, if (everything) "Her şey varsayılana döndü" else "Ayarlar varsayılana döndü", Toast.LENGTH_SHORT).show()
        prefs.edit().putBoolean("reopenMain", true).commit(); handler.postDelayed({ recreate() }, 150)
    }

    // ---------- Fotoğraf ----------
    // TV'de dosya seçici olmadığı için fotoğraflar uygulamanın içinden seçilir: Favoriler, Bing, Wikimedia Commons (konulara göre) ve Picsum
    private val backToBg: () -> Unit = { showBgPanel() }
    // Arka plan paneli: üstte fotoğraf satırı; çizginin altında hazır arka planlar 4'lü ızgarada önizleme kutuları.
    // Hazır arka plan seçilince hemen uygulanır, panel açık kalır, tik yeni seçime geçer.
    private fun showBgPanel() {
        val dlg = PanelDialog(); val box = panelBox().apply { clipChildren = false; clipToPadding = false }
        box.addView(titleView("Arka Plan", crumbs(backToCat)))
        box.addView(View(this).apply { setBackgroundColor(cDiv()) }, LinearLayout.LayoutParams(matchP, dp(1)).apply { setMargins(0, 0, 0, dp(6)) })
        val custom = prefs.getBoolean("bgCustom", false); val thumb = if (custom) customThumb() else null
        val photoRow = menuRow(if (thumb != null) PItem("Seçilen Fotoğraf", image = thumb, sub = "Değiştirmek için seç", arrow = true)
            else PItem("Fotoğraf Seç", GlyphView.IMAGE, "#D98A4E", sub = "Favoriler, Bing, Wikimedia ve karışık koleksiyon", arrow = true)) { dlg.dismiss(); srcRow = 0; showPhotoSources() }
        box.addView(photoRow, LinearLayout.LayoutParams(matchP, wrap))
        if (prefs.getBoolean("prevSet", false)) prevBgThumb()?.let { th ->
            val pName = if (prefs.getBoolean("prevCustom", false)) (prefs.getString("prevCaption", "") ?: "").ifEmpty { "Önceki fotoğraf" } else bgPresets[prefs.getInt("prevBg", 0).coerceIn(0, bgPresets.size - 1)].first
            box.addView(menuRow(PItem("Önceki Arka Plan", image = th, sub = pName)) { restorePrevBg(); dlg.dismiss(); showBgPanel() }, LinearLayout.LayoutParams(matchP, wrap)) }
        box.addView(View(this).apply { setBackgroundColor(cDiv()) }, LinearLayout.LayoutParams(matchP, dp(1)).apply { setMargins(dp(10), dp(8), dp(10), dp(8)) })
        val ncol = 4; val cw = 62; val ch = 40; val gap = 10
        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; clipChildren = false; clipToPadding = false; setPadding(du(4), du(4), du(4), du(2)) }
        val marks = ArrayList<StatusBadge>(); var focusTarget: View = photoRow
        val cur = if (custom) -1 else prefs.getInt("bg", 0).coerceIn(0, bgPresets.size - 1)
        var rowL: LinearLayout? = null
        bgPresets.forEachIndexed { i, (name, colors) ->
            if (i % ncol == 0) { rowL = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; clipChildren = false }; grid.addView(rowL, LinearLayout.LayoutParams(wrap, wrap).apply { setMargins(0, 0, 0, if (i + ncol < bgPresets.size) du(8) else 0) }) }
            val cell = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; clipChildren = false }
            val ring = GradientDrawable().apply { cornerRadius = dp(10).toFloat(); setColor(Color.TRANSPARENT); setStroke(dp(1), cDiv()) }
            val sw = FrameLayout(this).apply { isFocusable = true; clipToOutline = true; foreground = ring
                background = if (colors == null) GradientDrawable().apply { cornerRadius = dp(10).toFloat(); setColor(Color.DKGRAY) } else GradientDrawable(GradientDrawable.Orientation.TL_BR, colors).apply { cornerRadius = dp(10).toFloat() } }
            if (colors == null) sw.addView(ImageView(this).apply { setImageDrawable(classicThumb()); scaleType = ImageView.ScaleType.CENTER_CROP }, FrameLayout.LayoutParams(matchP, matchP))
            val mark = StatusBadge(this, Color.WHITE, accent(), outline = true).apply { visibility = if (i == cur) View.VISIBLE else View.GONE; if (i == cur) done(false) }
            sw.addView(mark, FrameLayout.LayoutParams(du(18), du(18), Gravity.TOP or Gravity.END).apply { setMargins(0, du(4), du(4), 0) })
            val label = TextView(this).apply { text = name; textSize = sp(10f); setTextColor(cSub()); gravity = Gravity.CENTER; maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END }
            sw.setOnFocusChangeListener { v, has -> animView(v, if (has) 1.1f else 1f, z = if (has) dp(5).toFloat() else 0f, dur = 120)
                ring.setStroke(if (has) dp(2) else dp(1), if (has) accent() else cDiv()); label.setTextColor(if (has) cText() else cSub()) }
            sw.setOnClickListener {
                if (tooSoon()) return@setOnClickListener
                if (prefs.getBoolean("bgCustom", false) || prefs.getInt("bg", 0) != i) rememberBg()
                prefs.edit().putBoolean("bgCustom", false).remove("bgWebId").remove("bgCaption").putInt("bg", i).apply(); applyBg(); setDynBg(colors != null)
                marks.forEachIndexed { k, m -> if (k == i) { if (m.visibility != View.VISIBLE) { m.visibility = View.VISIBLE; m.done(true) } } else m.visibility = View.GONE }
            }
            cell.addView(sw, LinearLayout.LayoutParams(du(cw), du(ch)))
            cell.addView(label, LinearLayout.LayoutParams(du(cw + gap), wrap).apply { setMargins(0, du(4), 0, 0) })
            rowL!!.addView(cell, LinearLayout.LayoutParams(wrap, wrap).apply { setMargins(if (i % ncol == 0) 0 else du(gap) / 2, 0, if (i % ncol == ncol - 1) 0 else du(gap) / 2, 0) })
            marks.add(mark); if (i == cur) focusTarget = sw
        }
        box.addView(grid, LinearLayout.LayoutParams(wrap, wrap).apply { gravity = Gravity.CENTER_HORIZONTAL })
        box.addView(footView(backText(backToCat)))
        dlg.setContentView(box); styleWindow(dlg, 330); registerDialog(dlg)
        dlg.setOnCancelListener { backToCat() }; dlg.setOnShowListener { focusTarget.requestFocus() }; dlg.show()
    }
    // Kaynaklar: -2 Arama, -1 Favoriler, 0 Bing, 1 Picsum (karışık), 2+ Wikimedia Commons'un seçkin fotoğrafları (konuya göre)
    private val SRC_FAV = -1; private val SRC_SEARCH = -2
    private var searchQuery = ""
    private val backToSources: () -> Unit = { showPhotoSources() }
    // Fotoğraf Ara: yazılan konu Wikimedia Commons'un seçkin ve kaliteli fotoğrafları arasında aranır (Türkçe ya da İngilizce)
    private fun showPhotoSearch() {
        showInput("Fotoğraf Ara", "Örn. Kapadokya, lavanta, kuzey ışıkları", prefs.getString("photoQuery", "") ?: "", backToSources) { q ->
            if (q.isEmpty()) showPhotoSources()
            else { searchQuery = q; prefs.edit().putString("photoQuery", q).apply(); synchronized(galBufs) { galBufs.remove(SRC_SEARCH) }; openGallery(SRC_SEARCH, 1) } }
    }
    private val wmCats = listOf(
        "Doğa Manzaraları" to "landscape", "Dağlar" to "mountains", "Deniz ve Sahiller" to "coast", "Göller ve Nehirler" to "lake",
        "Şelaleler" to "waterfall", "Ormanlar" to "forest", "Çiçekler" to "flower", "Çöller" to "desert",
        "Gün Batımı" to "sunset", "Kış ve Kar" to "snow", "Gece Gökyüzü ve Uzay" to "night sky", "Şehir Manzaraları" to "cityscape",
        "Mimari" to "architecture", "Hayvanlar" to "wildlife")
    private fun srcName(src: Int): String = when (src) { SRC_SEARCH -> "“$searchQuery”"; SRC_FAV -> "Favoriler"; 0 -> "Bing Günün Fotoğrafları"; 1 -> "Karışık Koleksiyon"; else -> wmCats.getOrNull(src - 2)?.first ?: "" }
    // Izgaradaki sıra: Bing, Wikimedia konuları, Karışık (toplam 16 = 4 x 4)
    private val photoSrcOrder: List<Int> get() = listOf(0) + wmCats.indices.map { it + 2 } + listOf(1)
    // srcRow: 0 = Favoriler, 1 = Fotoğraf Ara, 2.. = ızgaradaki kutu (galeriden Geri ile dönünce imleç orada durur)
    private var srcRow = 0
    // Kategori kapakları: her kategorinin ilk açılışta bulunan bir fotoğrafı diske kaydedilir ve bir daha değişmez
    private fun coverFile(src: Int) = File(File(filesDir, "covers").apply { mkdirs() }, "c$src.jpg")
    private fun loadCover(src: Int, iv: ImageView) {
        val f = coverFile(src); iv.tag = src
        coverPool.execute {
            try {
                if (!f.exists()) {
                    val url = if (src == 1) "https://picsum.photos/id/1015/384/216" else galleryPage(src, 1).first.firstOrNull()?.thumb ?: return@execute
                    val b = fetchBitmap(url) ?: return@execute
                    val tmp = File(f.path + ".part"); FileOutputStream(tmp).use { b.compress(android.graphics.Bitmap.CompressFormat.JPEG, 88, it) }; tmp.renameTo(f)
                }
                val bmp = BitmapFactory.decodeFile(f.path) ?: return@execute
                handler.post { if (iv.tag == src) iv.setImageBitmap(bmp) }
            } catch (_: Exception) {}
        }
    }
    // Fotoğraf Seç: üstte Favoriler satırı; çizginin altında 16 kategori 4'lü ızgarada, sabit kapak fotoğraflarıyla
    private fun showPhotoSources() {
        val dlg = PanelDialog(); val box = panelBox().apply { clipChildren = false; clipToPadding = false }
        box.addView(titleView("Fotoğraf Seç", listOf("Görünüm", "Arka Plan")))
        box.addView(View(this).apply { setBackgroundColor(cDiv()) }, LinearLayout.LayoutParams(matchP, dp(1)).apply { setMargins(0, 0, 0, dp(6)) })
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; clipChildren = false; clipToPadding = false }
        val nFav = favList().size
        val favRow = menuRow(PItem("Favoriler", GlyphView.HEART, "#FF375F", sub = if (nFav == 0) "Henüz yok · galeride fotoğrafa OK ile uzun bas" else "$nFav fotoğraf", arrow = true)) { srcRow = 0; dlg.dismiss(); openGallery(SRC_FAV, 1) }
        content.addView(favRow, LinearLayout.LayoutParams(matchP, wrap))
        val lastQ = prefs.getString("photoQuery", "") ?: ""
        val searchRow = menuRow(PItem("Fotoğraf Ara", GlyphView.SEARCH, "#4C7DF0", sub = if (lastQ.isEmpty()) "İstediğin konuyu yaz: Kapadokya, lavanta…" else "Son arama: $lastQ", arrow = true)) { srcRow = 1; dlg.dismiss(); showPhotoSearch() }
        content.addView(searchRow, LinearLayout.LayoutParams(matchP, wrap))
        content.addView(View(this).apply { setBackgroundColor(cDiv()) }, LinearLayout.LayoutParams(matchP, dp(1)).apply { setMargins(dp(10), dp(8), dp(10), dp(8)) })
        val ncol = 4; val cw = 62; val ch = 38; val gap = 10
        val skel = if (lightTheme) Color.parseColor("#D9DAE0") else Color.parseColor("#2A2C36")
        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; clipChildren = false; clipToPadding = false; setPadding(du(4), du(4), du(4), du(4)) }
        var focusTarget: View = if (srcRow == 1) searchRow else favRow; var rowL: LinearLayout? = null
        val order = photoSrcOrder
        order.forEachIndexed { i, src ->
            if (i % ncol == 0) { rowL = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; clipChildren = false }; grid.addView(rowL, LinearLayout.LayoutParams(wrap, wrap).apply { setMargins(0, 0, 0, if (i + ncol < order.size) du(6) else 0) }) }
            val cell = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; clipChildren = false }
            val ring = GradientDrawable().apply { cornerRadius = dp(10).toFloat(); setColor(Color.TRANSPARENT); setStroke(dp(1), cDiv()) }
            val tile = FrameLayout(this).apply { isFocusable = true; clipToOutline = true; foreground = ring; background = GradientDrawable().apply { cornerRadius = dp(10).toFloat(); setColor(skel) } }
            val iv = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
            tile.addView(iv, FrameLayout.LayoutParams(matchP, matchP)); loadCover(src, iv)
            val label = TextView(this).apply { text = srcName(src); textSize = sp(9.5f); setTextColor(cSub()); gravity = Gravity.CENTER; maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END }
            tile.setOnFocusChangeListener { v, has -> animView(v, if (has) 1.1f else 1f, z = if (has) dp(5).toFloat() else 0f, dur = 120)
                ring.setStroke(if (has) dp(2) else dp(1), if (has) accent() else cDiv()); label.setTextColor(if (has) cText() else cSub()) }
            tile.setOnClickListener { if (tooSoon()) return@setOnClickListener; srcRow = i + 2; dlg.dismiss(); openGallery(src, 1) }
            cell.addView(tile, LinearLayout.LayoutParams(du(cw), du(ch)))
            cell.addView(label, LinearLayout.LayoutParams(du(cw + gap), wrap).apply { setMargins(0, du(3), 0, 0) })
            rowL!!.addView(cell, LinearLayout.LayoutParams(wrap, wrap).apply { setMargins(if (i % ncol == 0) 0 else du(gap) / 2, 0, if (i % ncol == ncol - 1) 0 else du(gap) / 2, 0) })
            if (srcRow == i + 2) focusTarget = tile
        }
        content.addView(grid, LinearLayout.LayoutParams(wrap, wrap).apply { gravity = Gravity.CENTER_HORIZONTAL })
        // Ekrana sığmazsa (büyük yazı boyutunda) içerik kayar; seçilen kutu her zaman görünür kalır
        box.addView(ScrollView(this).apply { isVerticalScrollBarEnabled = false; clipChildren = false; clipToPadding = false; isVerticalFadingEdgeEnabled = true; setFadingEdgeLength(du(24)); addView(content) },
            LinearLayout.LayoutParams(matchP, wrap).apply { height = minOf(panelListMax(), du(2 * 46 + 17 + 4 * (ch + 22) + 18)) })
        box.addView(footView(backText(backToBg)))
        dlg.setContentView(box); styleWindow(dlg, 330); registerDialog(dlg)
        dlg.setOnCancelListener { backToBg() }; dlg.setOnShowListener { focusTarget.requestFocus() }; dlg.show()
    }
    // Favori fotoğraflar: en son eklenen en başta. Adresleriyle birlikte TV'de kalıcı saklanır, kategorilerden bağımsızdır.
    private fun favList(): MutableList<WebImg> = try {
        val a = org.json.JSONArray(prefs.getString("favPhotos", "[]") ?: "[]")
        MutableList(a.length()) { val o = a.getJSONObject(it); WebImg(o.getString("id"), o.getString("full"), o.getString("thumb"), o.optString("cap")) }
    } catch (_: Exception) { mutableListOf() }
    private fun saveFavs(l: List<WebImg>) { val a = org.json.JSONArray(); l.forEach { a.put(JSONObject().put("id", it.id).put("full", it.full).put("thumb", it.thumb).put("cap", it.caption)) }; prefs.edit().putString("favPhotos", a.toString()).apply() }
    /** Favoriye ekler ya da çıkarır; eklendiyse true. Eklenince küçük resmi TV'ye kaydedilir, çıkarılınca silinir. */
    private fun toggleFav(img: WebImg, shown: android.graphics.Bitmap? = null): Boolean { val l = favList(); val i = l.indexOfFirst { it.id == img.id }; if (i >= 0) l.removeAt(i) else l.add(0, img); saveFavs(l)
        if (i >= 0) favThumbFile(img.id).delete() else saveFavThumb(img, shown); return i < 0 }
    // Favorilerin küçük resimleri diskte durur: Favoriler internet/sunucu durumundan bağımsız, anında açılır
    private fun favThumbFile(id: String) = File(File(filesDir, "favthumbs").apply { mkdirs() }, id.replace(Regex("[^A-Za-z0-9_-]"), "_") + ".jpg")
    // shown: kutuda o an görünen resim; varsa internete hiç gitmeden doğrudan o kaydedilir
    private fun saveFavThumb(img: WebImg, shown: android.graphics.Bitmap? = null) {
        val f = favThumbFile(img.id); if (f.exists()) return
        val have = shown ?: thumbCache.get(img.thumb)
        imgPool.execute { try {
            val bmp = have ?: fetchBitmap(img.thumb) ?: return@execute
            val tmp = File(f.path + ".part"); FileOutputStream(tmp).use { bmp.compress(android.graphics.Bitmap.CompressFormat.JPEG, 88, it) }; tmp.renameTo(f)
        } catch (e: Exception) { android.util.Log.w("PiLauncher", "favori resmi kaydedilemedi: " + e.javaClass.simpleName) } }
    }
    private fun loadFavThumb(img: WebImg, iv: ImageView) {
        val f = favThumbFile(img.id); iv.tag = img.thumb
        imgPool.execute {
            // Önce TV'deki kayıt; yoksa (ya da bozuksa) internetten tek istekle alınır, hem gösterilir hem kaydedilir
            var bmp = if (f.exists()) try { BitmapFactory.decodeFile(f.path) } catch (_: Exception) { null } else null
            if (bmp == null) { if (f.exists()) f.delete()
                bmp = thumbCache.get(img.thumb) ?: fetchBitmap(img.thumb) { iv.tag == img.thumb }
                if (bmp != null) try { val tmp = File(f.path + ".part"); FileOutputStream(tmp).use { bmp.compress(android.graphics.Bitmap.CompressFormat.JPEG, 88, it) }; tmp.renameTo(f) } catch (_: Exception) {} }
            val b = bmp ?: return@execute
            handler.post { if (iv.tag == img.thumb) iv.setImageBitmap(b) } }
    }
    // Wikimedia Commons: yalnızca "seçkin fotoğraf" (Featured picture) olanlar, yatay ve en az 1920 piksel genişlikte.
    // Bir sonraki sorgunun başlangıç sırasını da döndürür (-1: kategoride başka sonuç yok).
    // broad: aramada seçkin fotoğrafların yanında "kaliteli fotoğraf" onaylı olanlar da taranır (daha çok sonuç)
    private fun wikiList(q: String, offset: Int, broad: Boolean = false): Pair<List<WebImg>, Int> = try { wikiList0(q, offset, broad) }
        catch (e: Exception) { android.util.Log.w("PiLauncher", "Wikimedia araması başarısız (" + e.javaClass.simpleName + "): " + e.message?.take(80)); throw e }
    private fun wikiList0(q: String, offset: Int, broad: Boolean): Pair<List<WebImg>, Int> {
        val cat = if (broad) "Featured_pictures_on_Wikimedia_Commons|Quality_images" else "Featured_pictures_on_Wikimedia_Commons"
        val search = "incategory:$cat filemime:image/jpeg filew:>1900 " + q
        val url = "https://commons.wikimedia.org/w/api.php?action=query&format=json&generator=search&gsrnamespace=6&gsrlimit=50&gsroffset=" + offset +
            "&gsrsearch=" + URLEncoder.encode(search, "UTF-8") + "&prop=imageinfo&iiprop=url%7Csize%7Cextmetadata&iiextmetadatafilter=ObjectName&iiurlwidth=330"
        val root = JSONObject(httpGet(url))
        val next = root.optJSONObject("continue")?.optInt("gsroffset", -1) ?: -1
        val pages = root.optJSONObject("query")?.optJSONObject("pages") ?: return Pair(emptyList(), next)
        val tmp = ArrayList<Pair<Int, WebImg>>()
        for (k in pages.keys()) { val o = pages.getJSONObject(k); val ii = o.optJSONArray("imageinfo")?.optJSONObject(0) ?: continue
            val w = ii.optInt("width"); val h = ii.optInt("height"); if (w < 1900 || h > w * 0.85) continue
            val th = ii.optString("thumburl"); if (!th.contains("/330px-")) continue
            val name = ii.optJSONObject("extmetadata")?.optJSONObject("ObjectName")?.optString("value") ?: ""
            val cap = (if (name.isNotBlank()) name else o.optString("title").removePrefix("File:").substringBeforeLast(".")).replace(Regex("<[^>]*>"), "").trim()
            tmp.add(Pair(o.optInt("index", 999), WebImg("w$k", th.replace("/330px-", "/1920px-"), th, cap))) }
        return Pair(tmp.sortedBy { it.first }.map { it.second }, next)
    }
    private fun picsumList(page: Int): List<WebImg> {
        val arr = org.json.JSONArray(httpGet("https://picsum.photos/v2/list?page=$page&limit=30")); val out = ArrayList<WebImg>()
        for (i in 0 until arr.length()) { val o = arr.getJSONObject(i); val id = o.optString("id")
            out.add(WebImg("p$id", "https://picsum.photos/id/$id/1920/1080", "https://picsum.photos/id/$id/384/216", "Fotoğraf: " + o.optString("author"))) }
        return out
    }
    // Galeri sayfaları: her sayfa tam 4 sıra x 5 kutu. Kaynaktan gelen fotoğraflar bellekte birikir; sayfalar bu listeden
    // eşit parçalar halinde kesilir (kaynağın kendi sayfa düzeni ne olursa olsun yarım sıra kalmaz).
    private val galCols = 5; private val galRows = 4; private val galPer = galCols * galRows
    private class GalBuf { val items = ArrayList<WebImg>(); var next = 0; var end = false; val at = System.currentTimeMillis() }
    private val galBufs = HashMap<Int, GalBuf>()
    /** Arka planda çağrılır: sayfanın fotoğrafları ve ardından başka sayfa olup olmadığı. */
    private fun galleryPage(src: Int, page: Int): Pair<List<WebImg>, Boolean> {
        val from = (page - 1) * galPer
        // Favoriler her açılışta kayıttan okunur; hiçbiri gizlenmesin diye son sayfa kırpılmaz
        if (src == SRC_FAV) { val l = favList(); if (from >= l.size) return Pair(emptyList(), false); return Pair(l.subList(from, minOf(from + galPer, l.size)).toList(), l.size > from + galPer) }
        val b = synchronized(galBufs) { galBufs[src]?.takeIf { System.currentTimeMillis() - it.at < 6 * 3_600_000L } ?: GalBuf().also { galBufs[src] = it } }
        synchronized(b) {
            val need = page * galPer + 1
            for (attempt in 0 until 8) { if (b.items.size >= need || b.end) break
                val batch: List<WebImg> = try { when (src) {
                    0 -> bingList().also { b.end = true }
                    1 -> picsumList(b.next + 1).also { b.next++; if (it.size < 30) b.end = true }
                    SRC_SEARCH -> wikiList(searchQuery, b.next, broad = true).let { (l, nx) -> if (nx <= b.next) b.end = true else b.next = nx; l }
                    else -> wikiList(wmCats[src - 2].second, b.next).let { (l, nx) -> if (nx <= b.next) b.end = true else b.next = nx; l } }
                } catch (_: Exception) { break }
                for (w in batch) if (b.items.none { it.id == w.id }) b.items.add(w)
            }
            if (b.items.isEmpty()) { synchronized(galBufs) { if (galBufs[src] === b) galBufs.remove(src) }; return Pair(emptyList(), false) }
            if (from >= b.items.size) return Pair(emptyList(), false)
            var list = b.items.subList(from, minOf(from + galPer, b.items.size)).toList()
            val more = b.items.size > from + galPer || !b.end
            if (!more && list.size > galCols) list = list.take(list.size / galCols * galCols)   // son sayfada da yarım sıra kalmasın
            return Pair(list, more)
        }
    }
    private fun openGallery(src: Int, page: Int) = showGallery(src, page)
    // İş parçacıkları ilk ihtiyaçta kurulur (açılışta boşuna kurulmaz)
    private val imgPoolL = lazy { java.util.concurrent.Executors.newFixedThreadPool(3) }
    private val imgPool by imgPoolL
    // Kategori kapakları kendi sırasında yüklenir; galeri küçük resimlerinin önünü tıkamaz
    private val coverPoolL = lazy { java.util.concurrent.Executors.newSingleThreadExecutor() }
    private val coverPool by coverPoolL
    // Galeri küçük resimleri: en fazla 12 MB bellekte tutulur; galeri kapanınca tamamen bırakılır
    private val thumbCache = object : android.util.LruCache<String, android.graphics.Bitmap>(12 * 1024 * 1024) {
        override fun sizeOf(key: String, value: android.graphics.Bitmap): Int = value.byteCount }
    // Küçük resim indirme (arka planda): en fazla 4 deneme. Sunucu "çok fazla istek" (429) ya da "meşgul" (503) derse
    // istediği kadar (en çok 5 sn) beklenir; Wikimedia böyle durumda bir süre bütün istekleri reddettiği için hepsi birlikte yavaşlar.
    // Hatalar "PiLauncher" etiketiyle kayda yazılır (adb logcat -s PiLauncher).
    @Volatile private var wikiWaitUntil = 0L
    private fun fetchBitmap(url: String, alive: () -> Boolean = { true }): android.graphics.Bitmap? {
        for (attempt in 0 until 4) {
            if (!alive()) return null
            val wait = wikiWaitUntil - System.currentTimeMillis(); if (wait > 0) try { Thread.sleep(minOf(wait, 5000L)) } catch (_: InterruptedException) { return null }
            var delay = if (attempt == 0) 700L else 1800L
            try {
                val c = URL(url).openConnection() as HttpURLConnection; c.connectTimeout = 10000; c.readTimeout = 15000; c.instanceFollowRedirects = true
                c.setRequestProperty("User-Agent", UA); c.setRequestProperty("Accept", "image/webp,image/jpeg,image/*")
                val code = c.responseCode
                if (code == 200) { val b = c.inputStream.use { BitmapFactory.decodeStream(it) }; if (b != null) return b; android.util.Log.w("PiLauncher", "resim çözülemedi: " + url.take(120)) }
                else { android.util.Log.w("PiLauncher", "resim HTTP $code: " + url.take(120))
                    if (code == 429 || code == 503) { delay = ((c.getHeaderField("Retry-After")?.trim()?.toLongOrNull() ?: 3L) * 1000L).coerceIn(1000L, 5000L); wikiWaitUntil = System.currentTimeMillis() + delay }
                    c.disconnect(); if (code == 404 || code == 403) return null }
            } catch (e: Exception) { android.util.Log.w("PiLauncher", "resim alınamadı (" + e.javaClass.simpleName + "): " + url.take(120)) }
            if (attempt < 3) try { Thread.sleep(delay) } catch (_: InterruptedException) { return null }
        }
        return null
    }
    private fun loadThumb(url: String, iv: ImageView) {
        iv.tag = url
        thumbCache.get(url)?.let { iv.setImageBitmap(it); return }
        // Kutu bu arada başka fotoğrafa geçtiyse (sayfa değişti) denemeyi bırakır
        imgPool.execute {
            val b = fetchBitmap(url) { iv.tag == url } ?: return@execute
            thumbCache.put(url, b); handler.post { if (iv.tag == url) iv.setImageBitmap(b) }
        }
    }
    // Panel hemen açılır: kutular önce boş iskelet olarak görünür, sağ üstteki simge yüklemeyi/indirmeyi gösterir.
    // Sayfa değişince panel kapanıp açılmaz, kutuların içi yenilenir.
    // OK: arka plan yap. OK'a uzun bas: favoriye ekle/çıkar (sol üstte kırmızı kalp). Favorilerde çıkarılan kare, sayfa
    // değişene kadar yerinde kalır; yanlışlıkla çıkarılırsa yeniden uzun basılarak geri eklenebilir.
    private fun showGallery(src: Int, startPage: Int) {
        val dlg = PanelDialog(); val box = panelBox().apply { clipChildren = false; clipToPadding = false }
        val badge = StatusBadge(this, cText(), accent(), transient = true)
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(titleView(srcName(src), listOf("Arka Plan", "Fotoğraf Seç")), LinearLayout.LayoutParams(0, wrap, 1f))
        head.addView(badge, LinearLayout.LayoutParams(du(24), du(24)).apply { setMargins(du(8), 0, du(10), du(9)) })
        box.addView(head)
        val hintText = "OK: arka plan yap   ·   OK'a uzun bas: favoriye ekle / çıkar"
        val hint = TextView(this).apply { text = hintText; textSize = sp(10.5f); setTextColor(cSub()); setPadding(du(10), 0, du(10), du(8)); maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END }
        box.addView(hint)
        // Alt satır: üstüne gelinen fotoğrafın adı/yeri; fotoğraf seçili değilken kullanım ipucu
        var hintGen = 0; var capText = ""
        fun baseHint() = capText.ifEmpty { hintText }
        fun flash(msg: String) { val g = ++hintGen; hint.text = msg; handler.postDelayed({ if (g == hintGen) hint.text = baseHint() }, 2500) }
        // Kutu ölçüsü: 4 sıra her yazı boyutunda ekrana sığsın (gerekirse orantılı küçülür)
        val tw = 120; val th = 68; val gap = 9
        val needH = du(galRows * th + (galRows - 1) * gap + 12); val k = minOf(1f, (panelListMax() - du(30)).toFloat() / needH)
        val tW = (du(tw) * k).toInt(); val tH = (du(th) * k).toInt(); val g = (du(gap) * k).toInt()
        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; clipChildren = false; clipToPadding = false; setPadding(du(8), du(6), du(8), du(6)) }
        val tiles = ArrayList<FrameLayout>(); val ivs = ArrayList<ImageView>(); val marks = ArrayList<StatusBadge>(); val hearts = ArrayList<HeartBadge>()
        var page = startPage; var items: List<WebImg> = emptyList(); var loading = false; var gen = 0
        fun markCurrent() {
            val cur = if (prefs.getBoolean("bgCustom", false)) prefs.getString("bgWebId", "") ?: "" else ""
            for (i in marks.indices) { val on = cur.isNotEmpty() && i < items.size && items[i].id == cur
                if (on && marks[i].visibility != View.VISIBLE) { marks[i].visibility = View.VISIBLE; marks[i].done(true) } else if (!on) marks[i].visibility = View.GONE }
        }
        fun markFavs() { val ids = favList().map { it.id }.toHashSet(); for (i in hearts.indices) hearts[i].visibility = if (i < items.size && items[i].id in ids) View.VISIBLE else View.GONE }
        lateinit var prev: TextView; lateinit var next: TextView; lateinit var pageLbl: TextView
        fun load(p: Int) {
            val my = ++gen; loading = true; badge.busy(); if (items.isNotEmpty()) grid.alpha = 0.5f
            Thread { val res = try { galleryPage(src, p) } catch (_: Exception) { Pair(emptyList<WebImg>(), false) }
                handler.post {
                    if (my != gen || dlg !in openDialogs) return@post
                    loading = false; grid.alpha = 1f; hintGen++
                    if (res.first.isEmpty()) {
                        if (src == SRC_FAV && items.isEmpty()) { badge.idle(); hint.text = "Henüz favori yok · bir kategoride fotoğrafa OK ile uzun bas"; return@post }
                        if (src == SRC_SEARCH && items.isEmpty() && online) { badge.idle(); hint.text = "Bu arama için fotoğraf bulunamadı · Geri ile dönüp başka bir kelime dene"; return@post }
                        badge.fail()
                        if (items.isNotEmpty() && p > page) { hint.text = if (src == SRC_FAV) "Başka favori yok" else "Bu kategoride başka fotoğraf kalmadı"; next.visibility = View.INVISIBLE; if (prev.visibility == View.VISIBLE) prev.requestFocus() else tiles[0].requestFocus() }
                        else if (!online) hint.text = "İnternet bağlantısı yok · bağlanınca bir kutuya bas"
                        else if (items.isNotEmpty()) hint.text = "Fotoğraflar alınamadı · biraz sonra tekrar dene"
                        else hint.text = "Fotoğraflar alınamadı · tekrar denemek için bir kutuya bas"
                        return@post
                    }
                    badge.idle()
                    page = p; items = res.first
                    val fi = tiles.indexOf(dlg.currentFocus); capText = if (fi >= 0) cleanCaption(items.getOrNull(fi)?.caption ?: "") else ""; hint.text = baseHint()
                    for (i in tiles.indices) {
                        if (i < items.size) { tiles[i].visibility = View.VISIBLE; ivs[i].setImageDrawable(null); if (src == SRC_FAV) loadFavThumb(items[i], ivs[i]) else loadThumb(items[i].thumb, ivs[i]) }
                        else { tiles[i].visibility = View.INVISIBLE; ivs[i].tag = null; ivs[i].setImageDrawable(null) }
                    }
                    markCurrent(); markFavs()
                    pageLbl.text = "Sayfa $p"
                    prev.visibility = if (p > 1) View.VISIBLE else View.INVISIBLE
                    next.visibility = if (res.second) View.VISIBLE else View.INVISIBLE
                    val f = dlg.currentFocus
                    if (f == null || !f.isShown) (if (prev.visibility == View.VISIBLE) prev else tiles[0]).requestFocus()
                } }.start()
        }
        val skel = if (lightTheme) Color.parseColor("#D9DAE0") else Color.parseColor("#2A2C36")
        for (r in 0 until galRows) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; clipChildren = false }
            for (c in 0 until galCols) {
                val i = r * galCols + c
                val bg = GradientDrawable().apply { cornerRadius = dp(10).toFloat(); setColor(skel) }
                val ring = GradientDrawable().apply { cornerRadius = dp(10).toFloat(); setColor(Color.TRANSPARENT) }
                val f = FrameLayout(this).apply { background = bg; foreground = ring; isFocusable = true; clipToOutline = true }
                f.setOnFocusChangeListener { v, has -> animView(v, if (has) 1.08f else 1f, z = if (has) dp(6).toFloat() else 0f, dur = 120); ring.setStroke(if (has) dp(2) else 0, accent())
                    if (has) { capText = cleanCaption(items.getOrNull(i)?.caption ?: ""); hintGen++; hint.text = baseHint() }
                    // Üç denemede de gelmeyen küçük fotoğraf, kutunun üstüne gelince yeniden istenir
                    val img = (v as FrameLayout).getChildAt(0) as ImageView
                    if (has && !loading && img.drawable == null) items.getOrNull(i)?.let { if (src == SRC_FAV) loadFavThumb(it, img) else loadThumb(it.thumb, img) } }
                val iv = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
                f.addView(iv, FrameLayout.LayoutParams(matchP, matchP))
                val mark = StatusBadge(this, Color.WHITE, accent(), outline = true).apply { visibility = View.GONE }
                f.addView(mark, FrameLayout.LayoutParams(du(18), du(18), Gravity.TOP or Gravity.END).apply { setMargins(0, du(5), du(5), 0) })
                val heart = HeartBadge(this).apply { visibility = View.GONE }
                f.addView(heart, FrameLayout.LayoutParams(du(18), du(18), Gravity.TOP or Gravity.START).apply { setMargins(du(5), du(5), 0, 0) })
                f.setOnClickListener {
                    if (tooSoon() || loading || bgDownloading) return@setOnClickListener
                    if (items.isEmpty()) { load(page); return@setOnClickListener }
                    val img = items.getOrNull(i) ?: return@setOnClickListener
                    hintGen++; hint.text = baseHint()
                    applyWebBg(img, badge, { markCurrent() }, { flash("Fotoğraf indirilemedi · tekrar dene") })
                }
                f.setOnLongClickListener {
                    val img = items.getOrNull(i)
                    if (img != null && !loading) {
                        if (toggleFav(img, (iv.drawable as? android.graphics.drawable.BitmapDrawable)?.bitmap)) { heart.visibility = View.VISIBLE; heart.pop(); flash("Favorilere eklendi") }
                        else { heart.visibility = View.GONE; flash("Favorilerden çıkarıldı") }
                    }
                    true
                }
                row.addView(f, LinearLayout.LayoutParams(tW, tH).apply { setMargins(0, 0, if (c < galCols - 1) g else 0, 0) })
                tiles.add(f); ivs.add(iv); marks.add(mark); hearts.add(heart)
            }
            grid.addView(row, LinearLayout.LayoutParams(wrap, wrap).apply { setMargins(0, 0, 0, if (r < galRows - 1) g else 0) })
        }
        box.addView(grid, LinearLayout.LayoutParams(wrap, wrap).apply { gravity = Gravity.CENTER_HORIZONTAL; setMargins(0, 0, 0, du(4)) })
        // Küçük sayfa düğmeleri: ‹ Önceki · Sayfa N · Sonraki ›  (görünmeyen düğme yerini korur, düzen kaymaz)
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        fun navBtn(label: String, go: () -> Unit): TextView {
            val bg = GradientDrawable().apply { cornerRadius = dp(14).toFloat(); setColor(cField()) }
            return TextView(this).apply { text = label; textSize = sp(11f); setTextColor(cText()); background = bg; isFocusable = true; setPadding(dp(14), dp(5), dp(14), dp(5))
                setOnFocusChangeListener { _, has -> bg.setColor(if (has) cFocus() else cField()); bg.setStroke(if (has) dp(2) else 0, accent()); if (has) { capText = ""; hintGen++; hint.text = hintText } }
                setOnClickListener { if (!tooSoon() && !loading && !bgDownloading) go() } }
        }
        prev = navBtn("‹  Önceki") { load(page - 1) }.apply { visibility = View.INVISIBLE }
        next = navBtn("Sonraki  ›") { load(page + 1) }.apply { visibility = View.INVISIBLE }
        pageLbl = TextView(this).apply { text = "Sayfa $startPage"; textSize = sp(10.5f); setTextColor(cSub()); setPadding(dp(8), 0, dp(8), 0) }
        bar.addView(prev, LinearLayout.LayoutParams(wrap, wrap).apply { setMargins(dp(6), 0, dp(6), 0) })
        bar.addView(pageLbl)
        bar.addView(next, LinearLayout.LayoutParams(wrap, wrap).apply { setMargins(dp(6), 0, dp(6), 0) })
        box.addView(bar, LinearLayout.LayoutParams(matchP, wrap).apply { setMargins(0, dp(4), 0, dp(2)) })
        box.addView(footView("‹  Geri: Fotoğraf Seç"))
        dlg.setContentView(box); styleWindow(dlg, ((galCols * tw + (galCols - 1) * gap) * k).toInt() + 16 + 24, false)
        registerDialog(dlg) { gen++; ivs.forEach { it.tag = null; it.setImageDrawable(null) }; thumbCache.evictAll() }
        dlg.setOnCancelListener { showPhotoSources() }; dlg.setOnShowListener { tiles[0].requestFocus() }; dlg.show()
        load(startPage)
    }
    @Volatile private var bgDownloading = false
    private fun applyWebBg(img: WebImg, badge: StatusBadge, onDone: () -> Unit, onFail: () -> Unit) {
        if (bgDownloading) return; bgDownloading = true; badge.busy()
        Thread { try {
            val tmp = File(filesDir, "bg_download.jpg")
            var last = -1f
            // Anlık bağlantı/sunucu hatasında 1,5 sn sonra bir kez daha denenir
            for (attempt in 0 until 2) { try { download(img.full, tmp) { f -> if (f - last >= 0.02f || f >= 1f) { last = f; handler.post { badge.progress(f) } } }; break }
                catch (e: Exception) { if (attempt == 1) throw e; last = -1f; Thread.sleep(1500) } }
            rememberBg()
            val dst = customBgFile(); if (dst.exists()) dst.delete(); tmp.renameTo(dst)
            handler.post { bgDownloading = false; prefs.edit().putBoolean("bgCustom", true).putString("bgWebId", img.id).putString("bgCaption", cleanCaption(img.caption)).apply(); applyBg(); setDynBg(false); badge.done(); onDone() }
        } catch (_: Exception) { handler.post { bgDownloading = false; badge.fail(); onFail() } } }.start()
    }

    // ---------- Hava durumu ----------
    // Kaynaklar: 0 = MET Norway (yr.no), 1 = Open-Meteo, 2 = MGM (Türkiye'nin resmî meteoroloji servisi: ilçe istasyonu ölçümü + resmî tahmin).
    // Hepsi aynı biçime çevrilir; seçilen kaynak cevap vermezse diğerine geçilir.
    // Güncelleme süresi: ana ekran açıkken hava durumu bu aralıkla yenilenir (5 dk / 15 dk / 30 dk / 1 saat)
    private val wxEveryMins = intArrayOf(5, 15, 30, 60)
    private val wxEveryNames = listOf("5 Dakika", "15 Dakika", "30 Dakika", "1 Saat")
    private fun wxEveryMs() = wxEveryMins[prefs.getInt("wxEvery", 2).coerceIn(0, 3)] * 60_000L
    private fun showWxEveryPanel() = choice("Güncelleme Süresi", wxEveryNames, prefs.getInt("wxEvery", 2), "wxEvery") {}
    private val wxSources = listOf("MET Norway (yr.no)", "Open-Meteo", "MGM (Meteoroloji Genel Müdürlüğü)")
    private val UA = "PiLauncher/$VERSION (github.com/arslanburak/tvlauncher)"
    private fun saveCity(name: String, lat: String, lon: String, il: String = "", ilce: String = "") { prefs.edit().putString("city", name).putString("lat", lat).putString("lon", lon).putString("il", il).putString("ilce", ilce).remove("mgmCur").remove("mgmDay").remove("mgmName").remove("wx").remove("wxfull").remove("wxAlerts").apply(); updateWeatherText(); lastWeather = System.currentTimeMillis(); fetchWeather() }
    private fun showCitySearch(parent: (() -> Unit)?) { showInput("Konum Ara", "Mahalle, sokak, ilçe ya da şehir", "", parent) { q -> if (q.isNotEmpty()) searchCity(q, parent) else showCitySearch(parent) } }
    private fun httpGet(url: String): String { val conn = URL(url).openConnection() as HttpURLConnection; conn.connectTimeout = 9000; conn.readTimeout = 9000
        conn.setRequestProperty("User-Agent", UA); conn.setRequestProperty("Accept-Language", "tr"); return conn.inputStream.bufferedReader().use { it.readText() } }
    // OpenStreetMap (Nominatim) ile mahalle/sokak düzeyinde arama
    private fun searchCity(q: String, parent: (() -> Unit)?) {
        Toast.makeText(this, "Aranıyor…", Toast.LENGTH_SHORT).show()
        Thread { val found = mutableListOf<City>(); val titles = mutableListOf<String>(); val subs = mutableListOf<String>()
            try { val arr = org.json.JSONArray(httpGet("https://nominatim.openstreetmap.org/search?q=" + URLEncoder.encode(q, "UTF-8") + "&format=jsonv2&addressdetails=1&limit=8&accept-language=tr"))
                for (k in 0 until arr.length()) { val o = arr.getJSONObject(k); val a = o.optJSONObject("address") ?: JSONObject()
                    fun ad(vararg keys: String): String { for (key in keys) { val v = a.optString(key, ""); if (v.isNotEmpty()) return v }; return "" }
                    val local = ad("neighbourhood", "suburb", "quarter", "village", "hamlet", "town", "city_district", "district", "county", "city", "province", "state")
                    val type = o.optString("addresstype", ""); val nm = o.optString("name", "")
                    val short = if (nm.isNotEmpty() && type !in listOf("road", "house", "building", "amenity", "shop", "tourism", "leisure", "office", "highway")) nm else local.ifEmpty { nm }
                    val parts = o.optString("display_name", "").split(",").map { it.trim() }.filter { it.isNotEmpty() && !it.all { ch -> ch.isDigit() } && !it.endsWith("Bölgesi") && it != "Türkiye" }
                    if (parts.isEmpty()) continue
                    found.add(City(short.ifEmpty { parts[0] }, o.optString("lat"), o.optString("lon"), ad("province", "state", "city"), ad("town", "county", "city_district", "district"))); titles.add(parts[0]); subs.add(parts.drop(1).take(3).joinToString(", "))
                }
            } catch (_: Exception) {}
            handler.post { if (found.isEmpty()) { Toast.makeText(this, "Konum bulunamadı ya da internet yok", Toast.LENGTH_LONG).show(); showCitySearch(parent) }
                else showPanel("Sonuçlar", titles.indices.map { PItem(titles[it], sub = subs[it].ifEmpty { null }) }, -1, { showCitySearch(parent) }, false) { i -> saveCity(found[i].name, found[i].lat, found[i].lon, found[i].il, found[i].ilce); parent?.invoke() } }
        }.start()
    }
    private fun wxText(code: Int): String = when (code) { 0 -> "Açık"; 1 -> "Az bulutlu"; 2 -> "Parçalı bulutlu"; 3 -> "Kapalı"; 45, 48 -> "Sisli"; 51, 53, 55, 56, 57 -> "Çiseleme"
        61 -> "Hafif yağmur"; 63 -> "Yağmurlu"; 65 -> "Şiddetli yağmur"; 66, 67 -> "Karla karışık"; 71 -> "Hafif kar"; 73, 77 -> "Karlı"; 75 -> "Yoğun kar"
        80 -> "Hafif sağanak"; 81 -> "Sağanak"; 82 -> "Kuvvetli sağanak"; 85, 86 -> "Kar sağanağı"; 95, 96, 99 -> "Gök gürültülü"; else -> "" }
    private fun wxKind(code: Int): Int { val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY); val night = h < 6 || h >= 19
        return when (code) { 0, 1 -> if (night) WxIconView.MOON else WxIconView.SUN; 2 -> if (night) WxIconView.CLOUD else WxIconView.PARTLY; 3 -> WxIconView.CLOUD; 45, 48 -> WxIconView.FOG; 51, 53, 55, 56, 57, 61, 63, 65, 66, 67, 80, 81, 82 -> WxIconView.RAIN; 71, 73, 75, 77, 85, 86 -> WxIconView.SNOW; 95, 96, 99 -> WxIconView.STORM; else -> WxIconView.CLOUD } }
    private fun wxKindDay(code: Int): Int = when (code) { 0, 1 -> WxIconView.SUN; 2 -> WxIconView.PARTLY; else -> wxKind(code) }
    // MET Norway sembol kodu -> WMO kodu
    private fun metCode(sym: String): Int { val s = sym.substringBefore("_")
        return when { s.contains("thunder") -> 95; s.contains("sleet") -> if (s.startsWith("heavy")) 67 else 66
            s.contains("snow") -> if (s.startsWith("light")) 71 else if (s.startsWith("heavy")) 75 else 73
            s.contains("rainshowers") -> if (s.startsWith("light")) 80 else if (s.startsWith("heavy")) 82 else 81
            s.contains("rain") -> if (s.startsWith("light")) 61 else if (s.startsWith("heavy")) 65 else 63
            s == "fog" -> 45; s == "cloudy" -> 3; s == "partlycloudy" -> 2; s == "fair" -> 1; s == "clearsky" -> 0; else -> 3 } }
    // Hissedilen sıcaklık (Steadman / Avustralya BoM formülü)
    private fun feels(t: Double, windKmh: Double, rh: Double): Double { val e = rh / 100.0 * 6.105 * Math.exp(17.27 * t / (237.7 + t)); return t + 0.33 * e - 0.70 * (windKmh / 3.6) - 4.0 }
    private fun fetchMet(lat: String, lon: String): JSONObject {
        val ts = JSONObject(httpGet("https://api.met.no/weatherapi/locationforecast/2.0/compact?lat=" + "%.4f".format(Locale.US, lat.toDouble()) + "&lon=" + "%.4f".format(Locale.US, lon.toDouble()))).getJSONObject("properties").getJSONArray("timeseries")
        val iso = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).apply { timeZone = java.util.TimeZone.getTimeZone("UTC") }
        val dayF = SimpleDateFormat("yyyy-MM-dd", Locale.US); val now = System.currentTimeMillis()
        var curIdx = 0; for (i in 0 until ts.length()) { val t = iso.parse(ts.getJSONObject(i).getString("time"))!!.time; if (t <= now + 30 * 60_000L) curIdx = i else break }
        fun sym(d: JSONObject): String? = (d.optJSONObject("next_1_hours") ?: d.optJSONObject("next_6_hours"))?.optJSONObject("summary")?.optString("symbol_code")
        val cd = ts.getJSONObject(curIdx).getJSONObject("data"); val inst = cd.getJSONObject("instant").getJSONObject("details")
        val t = inst.getDouble("air_temperature"); val rh = inst.optDouble("relative_humidity", 50.0); val wind = inst.optDouble("wind_speed", 0.0) * 3.6
        val out = JSONObject().put("src", 0).put("t", t).put("f", feels(t, wind, rh)).put("h", rh).put("w", wind).put("c", metCode(sym(cd) ?: "cloudy"))
        val order = mutableListOf<String>(); val mx = HashMap<String, Double>(); val mn = HashMap<String, Double>(); val pr = HashMap<String, Double>(); val noon = HashMap<String, Pair<Int, Int>>()
        for (i in curIdx until ts.length()) { val e = ts.getJSONObject(i); val tm = iso.parse(e.getString("time"))!!; val day = dayF.format(tm); val d = e.getJSONObject("data")
            if (day !in order) { if (order.size >= 5) break; order.add(day) }
            val tt = d.getJSONObject("instant").getJSONObject("details").getDouble("air_temperature"); mx[day] = maxOf(mx[day] ?: tt, tt); mn[day] = minOf(mn[day] ?: tt, tt)
            val n1 = d.optJSONObject("next_1_hours"); val n6 = d.optJSONObject("next_6_hours")
            val amt = if (n1 != null) n1.optJSONObject("details")?.optDouble("precipitation_amount", 0.0) ?: 0.0 else n6?.optJSONObject("details")?.optDouble("precipitation_amount", 0.0) ?: 0.0
            pr[day] = (pr[day] ?: 0.0) + amt
            val s = sym(d); val hr = Calendar.getInstance().apply { time = tm }.get(Calendar.HOUR_OF_DAY)
            if (s != null) { val dist = Math.abs(hr - 13); val prev = noon[day]; if (prev == null || dist < prev.first) noon[day] = Pair(dist, metCode(s)) }
        }
        val days = org.json.JSONArray(); for (day in order) days.put(JSONObject().put("d", day).put("c", noon[day]?.second ?: 3).put("mx", mx[day]).put("mn", mn[day]).put("p", pr[day] ?: 0.0).put("pp", -1))
        return out.put("days", days)
    }
    private fun fetchOpenMeteo(lat: String, lon: String): JSONObject {
        val o = JSONObject(httpGet("https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current=temperature_2m,apparent_temperature,relative_humidity_2m,weather_code,wind_speed_10m&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_sum,precipitation_probability_max&timezone=auto&forecast_days=5"))
        val c = o.getJSONObject("current"); val d = o.getJSONObject("daily")
        val out = JSONObject().put("src", 1).put("t", c.getDouble("temperature_2m")).put("f", c.getDouble("apparent_temperature")).put("h", c.optDouble("relative_humidity_2m", 0.0)).put("w", c.optDouble("wind_speed_10m", 0.0)).put("c", c.getInt("weather_code"))
        val days = org.json.JSONArray(); val tm = d.getJSONArray("time")
        for (i in 0 until tm.length()) days.put(JSONObject().put("d", tm.getString(i)).put("c", d.getJSONArray("weather_code").optInt(i, 3)).put("mx", d.getJSONArray("temperature_2m_max").optDouble(i, 0.0)).put("mn", d.getJSONArray("temperature_2m_min").optDouble(i, 0.0))
            .put("p", d.getJSONArray("precipitation_sum").optDouble(i, 0.0)).put("pp", d.getJSONArray("precipitation_probability_max").optInt(i, -1)))
        return out.put("days", days)
    }
    // İnternet yokken boşuna denenmez; bağlantı gelince updateWifi hemen yeniden çağırır
    private fun fetchWeather() { if (!online) return; val lat = prefs.getString("lat", null) ?: return; val lon = prefs.getString("lon", null) ?: return; val src = prefs.getInt("wxSrc", 0)
        Thread { try {
            // Seçili kaynak cevap vermezse sırayla diğerlerine geçilir
            val order = when (src) { 1 -> listOf(1, 0, 2); 2 -> listOf(2, 0, 1); else -> listOf(0, 1, 2) }
            var o: JSONObject? = null
            for (k in order) { o = try { when (k) { 0 -> fetchMet(lat, lon); 1 -> fetchOpenMeteo(lat, lon); else -> fetchMgm(lat, lon) } } catch (_: Exception) { null }; if (o != null) break }
            if (o != null) { val temp = Math.round(o.getDouble("t")).toInt(); val code = o.getInt("c")
                prefs.edit().putString("wx", "$temp°|" + wxText(code) + "|" + code).putString("wxfull", o.toString()).apply() }
            try { fetchAlerts(lat, lon) } catch (_: Exception) {}
            handler.post { updateWeatherText() } } catch (_: Exception) {} }.start() }
    // ---------- Meteorolojik uyarılar (MGM) ----------
    // MGM'nin sarı/turuncu/kırmızı kodlu resmî uyarıları, MGM'nin de üyesi olduğu Avrupa uyarı ağı MeteoAlarm'ın açık
    // akışından alınır. Konumun iline ait, şu an geçerli ya da önümüzdeki 24 saat içinde başlayacak uyarılar saklanır.
    private class WxAlert(val lvl: Int, val type: Int, val head: String, val desc: String, val from: Long, val to: Long)
    private fun alertColor(lvl: Int) = Color.parseColor(when (lvl) { 4 -> "#FF453A"; 3 -> "#FF9F0A"; else -> "#FFD60A" })
    private fun alertLevelName(lvl: Int) = when (lvl) { 4 -> "Kırmızı"; 3 -> "Turuncu"; else -> "Sarı" }
    private fun alertTypeName(t: Int) = when (t) { 1 -> "Rüzgâr"; 2 -> "Kar ve buzlanma"; 3 -> "Gök gürültülü fırtına"; 4 -> "Sis"; 5 -> "Aşırı sıcak"; 6 -> "Aşırı soğuk"
        7 -> "Kıyı olayları"; 8 -> "Orman yangını"; 9 -> "Çığ"; 10 -> "Yağmur"; 12 -> "Sel"; 13 -> "Yağmur ve sel"; else -> "Meteorolojik olay" }
    private fun activeAlerts(): List<WxAlert> = try {
        val a = org.json.JSONArray(prefs.getString("wxAlerts", "[]") ?: "[]"); val now = System.currentTimeMillis()
        (0 until a.length()).map { a.getJSONObject(it) }.map { WxAlert(it.optInt("lvl"), it.optInt("type"), it.optString("head"), it.optString("desc"), it.optLong("from"), it.optLong("to")) }.filter { it.to > now }
    } catch (_: Exception) { emptyList() }
    private fun tokens(t: String): List<String> = ascii(t).lowercase(Locale.US).split(Regex("[^a-z]+")).filter { it.isNotEmpty() }
    private fun isoTime(t: String): Long = try { SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX", Locale.US).parse(t)!!.time } catch (_: Exception) { 0L }
    /** Arka planda çağrılır (hava durumuyla birlikte). */
    private fun fetchAlerts(lat: String, lon: String) {
        var il = prefs.getString("il", "") ?: ""
        if (il.isEmpty()) {   // eski kayıtlarda il yok: koordinattan bir kez bulunup saklanır
            val a = JSONObject(httpGet("https://nominatim.openstreetmap.org/reverse?format=jsonv2&zoom=8&accept-language=tr&lat=$lat&lon=$lon")).optJSONObject("address") ?: JSONObject()
            il = listOf("province", "state", "city").map { a.optString(it, "") }.firstOrNull { it.isNotEmpty() } ?: return
            prefs.edit().putString("il", il).apply() }
        val key = tokens(il.removeSuffix(" İli")).firstOrNull() ?: return
        // Ülke akışının adı "turkey"; ileride "turkiye" olarak değişirse o da denenir
        var warnings: org.json.JSONArray? = null
        for (slug in listOf("turkey", "turkiye")) { warnings = try { JSONObject(httpGet("https://feeds.meteoalarm.org/api/v1/warnings/feeds-$slug")).optJSONArray("warnings") } catch (_: Exception) { null }; if (warnings != null) break }
        if (warnings == null) return
        val out = org.json.JSONArray(); val now = System.currentTimeMillis(); val seen = HashSet<String>()
        for (k in 0 until warnings.length()) { val alert = warnings.optJSONObject(k)?.optJSONObject("alert") ?: continue
            val infos = alert.optJSONArray("info") ?: continue
            // İl eşleşmesi: uyarının bölgelerinden birinin adı (Türkçe ya da İngilizce yazımı) ilin adını kelime olarak içeriyor mu
            var match = false
            for (j in 0 until infos.length()) { val areas = infos.optJSONObject(j)?.optJSONArray("area") ?: continue
                for (x in 0 until areas.length()) if (key in tokens(areas.optJSONObject(x)?.optString("areaDesc", "") ?: "")) match = true }
            if (!match) continue
            var info: JSONObject? = null
            for (j in 0 until infos.length()) { val o = infos.optJSONObject(j) ?: continue; if (o.optString("language").lowercase(Locale.US).startsWith("tr")) { info = o; break } }
            val inf = info ?: infos.optJSONObject(0) ?: continue
            var lvl = 0; var type = 0; val params = inf.optJSONArray("parameter")
            if (params != null) for (j in 0 until params.length()) { val pr = params.optJSONObject(j) ?: continue; val v = pr.optString("value").substringBefore(";").trim().toIntOrNull() ?: continue
                when (pr.optString("valueName")) { "awareness_level" -> lvl = v; "awareness_type" -> type = v } }
            if (lvl < 2) continue
            val from = isoTime(inf.optString("onset", inf.optString("effective", ""))); val to = isoTime(inf.optString("expires", ""))
            if (to in 1 until now || from > now + 24 * 3_600_000L) continue
            val id = "$lvl/$type/$from"; if (!seen.add(id)) continue
            out.put(JSONObject().put("lvl", lvl).put("type", type).put("head", inf.optString("headline")).put("desc", inf.optString("description")).put("from", from).put("to", if (to > 0) to else now + 12 * 3_600_000L))
        }
        prefs.edit().putString("wxAlerts", out.toString()).apply()
    }
    // ---------- MGM (Meteoroloji Genel Müdürlüğü) ----------
    // Konumun il/ilçesine göre MGM merkezini bulur; anlık değerler ilçedeki MGM istasyonunun ölçümü, 5 günlük tahmin MGM'nin resmî tahmini.
    private fun mgmGet(url: String): String { val c = URL(url).openConnection() as HttpURLConnection; c.connectTimeout = 9000; c.readTimeout = 9000
        c.setRequestProperty("Origin", "https://www.mgm.gov.tr"); c.setRequestProperty("Referer", "https://www.mgm.gov.tr/"); c.setRequestProperty("Accept", "application/json"); c.setRequestProperty("User-Agent", UA)
        return c.inputStream.bufferedReader().use { it.readText() } }
    private fun ascii(t: String): String = t.map { when (it) { 'ç' -> 'c'; 'Ç' -> 'C'; 'ğ' -> 'g'; 'Ğ' -> 'G'; 'ı' -> 'i'; 'İ' -> 'I'; 'ö' -> 'o'; 'Ö' -> 'O'; 'ş' -> 's'; 'Ş' -> 'S'; 'ü' -> 'u'; 'Ü' -> 'U'; else -> it } }.joinToString("")
    private fun mgmIds(lat: String, lon: String): Triple<String, String, String> {
        val c0 = prefs.getString("mgmCur", null); val d0 = prefs.getString("mgmDay", null)
        if (c0 != null && d0 != null) return Triple(c0, d0, prefs.getString("mgmName", "") ?: "")
        var il = prefs.getString("il", "") ?: ""; var ilce = prefs.getString("ilce", "") ?: ""
        if (il.isEmpty()) {   // eski kayıtlarda il/ilçe yok: koordinattan bul
            val a = JSONObject(httpGet("https://nominatim.openstreetmap.org/reverse?format=jsonv2&zoom=10&accept-language=tr&lat=$lat&lon=$lon")).optJSONObject("address") ?: JSONObject()
            fun ad(vararg keys: String): String { for (k in keys) { val v = a.optString(k, ""); if (v.isNotEmpty()) return v }; return "" }
            il = ad("province", "state", "city"); ilce = ad("town", "county", "city_district", "district")
        }
        if (il.isEmpty()) throw java.io.IOException("il yok")
        val base = "https://servis.mgm.gov.tr/web/merkezler?il=" + URLEncoder.encode(ascii(il.removeSuffix(" İli").trim()), "UTF-8")
        var arr = if (ilce.isNotEmpty()) org.json.JSONArray(mgmGet(base + "&ilce=" + URLEncoder.encode(ascii(ilce.removeSuffix(" İlçesi").trim()), "UTF-8"))) else org.json.JSONArray()
        if (arr.length() == 0) arr = org.json.JSONArray(mgmGet(base))
        val m = arr.getJSONObject(0); val id = m.getString("merkezId")
        val day = m.optString("gunlukTahminIstNo", "").ifEmpty { id }
        val name = listOf(m.optString("ilce"), m.optString("il")).filter { it.isNotEmpty() && it != "null" }.distinct().joinToString(", ")
        prefs.edit().putString("mgmCur", id).putString("mgmDay", day).putString("mgmName", name).apply()
        return Triple(id, day, name)
    }
    // MGM hadise kodu -> uygulamadaki hava kodu
    private fun mgmCode(h: String): Int = when (h.trim().uppercase(Locale.US)) {
        "A", "SCK", "SGK" -> 0; "AB", "R", "GKR", "KKR" -> 1; "PB" -> 2; "CB", "KF" -> 3; "SIS", "PUS", "DMN" -> 45
        "HY" -> 61; "Y" -> 63; "KY" -> 65; "KKY" -> 66; "HKY" -> 71; "K" -> 73; "YKY" -> 75
        "HSY", "MSY" -> 80; "SY" -> 81; "KSY" -> 82; "GSY", "DY" -> 95; "KGY" -> 99; else -> 3 }
    private fun fetchMgm(lat: String, lon: String): JSONObject {
        val (cur, day, name) = mgmIds(lat, lon)
        val n = org.json.JSONArray(mgmGet("https://servis.mgm.gov.tr/web/sondurumlar?merkezid=$cur")).getJSONObject(0)
        val t = n.getDouble("sicaklik"); if (t < -90) throw java.io.IOException("ölçüm yok")
        val rh = n.optDouble("nem", 60.0).let { if (it < 0) 60.0 else it }; val wind = n.optDouble("ruzgarHiz", 0.0).let { if (it < 0) 0.0 else it }
        val out = JSONObject().put("src", 2).put("t", t).put("h", rh).put("w", wind).put("f", feels(t, wind, rh)).put("c", mgmCode(n.optString("hadiseKodu", ""))).put("st", name)
        val g = org.json.JSONArray(mgmGet("https://servis.mgm.gov.tr/web/tahminler/gunluk?istno=$day")).getJSONObject(0)
        val dayF = SimpleDateFormat("yyyy-MM-dd", Locale.US); val days = org.json.JSONArray()
        for (i in 1..5) { if (!g.has("enYuksekGun$i")) break
            val d = g.optString("tarihGun$i", "").take(10).ifEmpty { dayF.format(Date(System.currentTimeMillis() + (i - 1) * 86_400_000L)) }
            days.put(JSONObject().put("d", d).put("c", mgmCode(g.optString("hadiseGun$i", ""))).put("mx", g.optDouble("enYuksekGun$i")).put("mn", g.optDouble("enDusukGun$i")).put("p", 0.0).put("pp", -1)) }
        return out.put("days", days)
    }
    private fun fitText(tv: TextView) { tv.minWidth = Math.ceil(tv.paint.measureText(tv.text.toString()).toDouble()).toInt() + tv.paddingLeft + tv.paddingRight + 2; tv.requestLayout() }
    private fun updateWeatherText() { updateWeatherText0(); fitText(weatherText); updateWxCard()
        // Bardaki hava durumunun önünde, geçerli bir MGM uyarısı varsa en yüksek seviyenin renginde küçük nokta
        val al = activeAlerts().maxByOrNull { it.lvl }
        barAlertDot?.let { d -> if (al == null) d.visibility = View.GONE else { d.visibility = View.VISIBLE; d.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(alertColor(al.lvl)) } } } }
    private fun updateWeatherText0() { val city = prefs.getString("city", null)
        if (city == null) { wxIcon.visibility = View.GONE; weatherText.text = "Konum seç"; return }
        val wx = prefs.getString("wx", null); if (wx == null) { wxIcon.visibility = View.GONE; weatherText.text = city }
        else { val p = wx.split("|"); val code = if (p.size > 2) (p[2].toIntOrNull() ?: 3) else 3; wxIcon.setKind(wxKind(code)); wxIcon.visibility = View.VISIBLE; weatherText.text = city + " · " + p[0] + " " + (if (p.size > 1) p[1] else "") } }
    // Hava durumu ayrıntısı: üstte anlık durum ve (varsa) MGM uyarıları; altta yan yana gün kartları.
    // maxDays: hava durumu panelinden açılınca 3 gün, bardaki hava durumundan açılınca 5 gün.
    private fun showWeatherDetail(maxDays: Int = 5) {
        val full = prefs.getString("wxfull", null); val city = prefs.getString("city", null) ?: return
        if (full == null || !full.contains("\"days\"")) { lastWeather = System.currentTimeMillis(); fetchWeather(); Toast.makeText(this, if (online) "Hava durumu yükleniyor…" else "İnternet bağlantısı yok", Toast.LENGTH_SHORT).show(); return }
        val dlg = PanelDialog(); val box = panelBox(); var srcName = ""; var stName = ""; var nDays = 3
        try { val o = JSONObject(full); srcName = wxSources.getOrElse(o.optInt("src", 0)) { "" }; if (o.has("st")) stName = o.optString("st")
            val temp = Math.round(o.getDouble("t")).toInt(); val fl = Math.round(o.getDouble("f")).toInt(); val hum = Math.round(o.optDouble("h", 0.0)).toInt(); val wind = Math.round(o.optDouble("w", 0.0)).toInt(); val code = o.getInt("c")
            val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            head.addView(WxIconView(this, wxKind(code)), LinearLayout.LayoutParams(du(46), du(46)).apply { setMargins(0, 0, du(14), 0) })
            val hc = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            hc.addView(TextView(this).apply { text = city; textSize = sp(15f); setTextColor(cSub()); maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END })
            hc.addView(TextView(this).apply { text = "$temp°  ·  " + wxText(code); textSize = sp(26f); typeface = Typeface.create("sans-serif-light", Typeface.NORMAL); setTextColor(cText()) })
            head.addView(hc, LinearLayout.LayoutParams(0, wrap, 1f))
            val stats = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            fun stat(t: String, v: String): View { val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(du(10), 0, du(10), 0) }
                col.addView(TextView(this).apply { text = v; textSize = sp(15f); setTextColor(cText()); gravity = Gravity.CENTER }); col.addView(TextView(this).apply { text = t; textSize = sp(10.5f); setTextColor(cSub()); gravity = Gravity.CENTER }); return col }
            stats.addView(stat("Hissedilen", "$fl°")); stats.addView(stat("Nem", "%$hum")); stats.addView(stat("Rüzgâr", "$wind km/sa"))
            head.addView(stats)
            box.addView(head, LinearLayout.LayoutParams(matchP, wrap).apply { setMargins(du(8), du(2), du(8), du(10)) })
            // Geçerli MGM uyarıları: seviye renginde kutu, başlık, geçerlilik saatleri, kısa açıklama
            val tf = SimpleDateFormat("d MMM HH:mm", Locale("tr", "TR"))
            for (al in activeAlerts().sortedByDescending { it.lvl }) {
                val c = alertColor(al.lvl)
                val ab = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(du(12), du(9), du(12), du(9))
                    background = GradientDrawable().apply { cornerRadius = du(12).toFloat(); setColor(Color.argb(if (lightTheme) 55 else 42, Color.red(c), Color.green(c), Color.blue(c))); setStroke(dp(1), Color.argb(120, Color.red(c), Color.green(c), Color.blue(c))) } }
                ab.addView(View(this).apply { background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(c) } }, LinearLayout.LayoutParams(du(10), du(10)).apply { setMargins(0, du(5), du(10), 0) })
                val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
                col.addView(TextView(this).apply { text = alertLevelName(al.lvl) + " Uyarı · " + alertTypeName(al.type); textSize = sp(13f); setTextColor(cText()); typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL) })
                col.addView(TextView(this).apply { text = (if (al.from > 0) tf.format(Date(al.from)) + " – " else "") + tf.format(Date(al.to)); textSize = sp(10.5f); setTextColor(cSub()) })
                val d = al.desc.ifEmpty { al.head }; if (d.isNotEmpty()) col.addView(TextView(this).apply { text = d; textSize = sp(11f); setTextColor(cSub()); maxLines = 3; ellipsize = android.text.TextUtils.TruncateAt.END; setPadding(0, du(3), 0, 0) })
                ab.addView(col, LinearLayout.LayoutParams(0, wrap, 1f))
                box.addView(ab, LinearLayout.LayoutParams(matchP, wrap).apply { setMargins(du(4), 0, du(4), du(8)) })
            }
            box.addView(View(this).apply { setBackgroundColor(cDiv()) }, LinearLayout.LayoutParams(matchP, dp(1)).apply { setMargins(0, du(2), 0, du(10)) })
            // Gün kartları
            val days = o.getJSONArray("days"); val dayFmt = SimpleDateFormat("EEEE", Locale("tr", "TR")); val parse = SimpleDateFormat("yyyy-MM-dd", Locale.US)
            nDays = minOf(days.length(), maxDays)
            val strip = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (i in 0 until nDays) { val dd = days.getJSONObject(i)
                val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; setPadding(du(6), du(10), du(6), du(10))
                    background = GradientDrawable().apply { cornerRadius = du(14).toFloat(); setColor(cField()) } }
                val dayName = when (i) { 0 -> "Bugün"; 1 -> "Yarın"; else -> try { dayFmt.format(parse.parse(dd.getString("d"))!!) } catch (_: Exception) { dd.getString("d") } }
                card.addView(TextView(this).apply { text = dayName; textSize = sp(12.5f); setTextColor(cText()); typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL); maxLines = 1; gravity = Gravity.CENTER })
                card.addView(WxIconView(this, wxKindDay(dd.optInt("c", 3))), LinearLayout.LayoutParams(du(34), du(34)).apply { setMargins(0, du(6), 0, du(4)) })
                val tr = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.BOTTOM }
                tr.addView(TextView(this).apply { text = Math.round(dd.getDouble("mx")).toString() + "°"; textSize = sp(17f); setTextColor(cText()) })
                tr.addView(TextView(this).apply { text = "  " + Math.round(dd.getDouble("mn")) + "°"; textSize = sp(13f); setTextColor(cSub()) })
                card.addView(tr)
                card.addView(TextView(this).apply { text = rainText(dd, " "); textSize = sp(11.5f); setTextColor(Color.parseColor(if (lightTheme) "#1F6FD6" else "#8FC1FF")); gravity = Gravity.CENTER })
                card.addView(TextView(this).apply { text = wxText(dd.optInt("c", 3)); textSize = sp(10.5f); setTextColor(cSub()); gravity = Gravity.CENTER; maxLines = 2; minLines = 2 })
                strip.addView(card, LinearLayout.LayoutParams(0, wrap, 1f).apply { setMargins(du(4), 0, du(4), 0) }) }
            box.addView(strip, LinearLayout.LayoutParams(matchP, wrap))
        } catch (_: Exception) { box.addView(TextView(this).apply { text = "Hava durumu okunamadı"; setTextColor(cText()); textSize = sp(15f) }) }
        val alertNote = if (activeAlerts().isNotEmpty()) "   ·   Uyarılar: MGM (MeteoAlarm)" else ""
        box.addView(footView("‹  Geri: Kapat" + (if (srcName.isNotEmpty()) "   ·   Kaynak: $srcName" else "") + alertNote + (if (stName.isNotEmpty()) "\nMGM merkezi: $stName" else "")))
        dlg.setContentView(box); styleWindow(dlg, if (nDays <= 3) 380 else 470); registerDialog(dlg); dlg.show()
    }

    private fun openSystem(action: String) { try { startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { try { startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {} } }
    // ---------- Ağ: canlı Wi-Fi göstergesi, bağlantı kopunca akıllı davranış, Ağ Bağlantısı paneli ----------
    @Volatile private var online = true
    private var netCallback: ConnectivityManager.NetworkCallback? = null
    private fun cm() = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    @Suppress("DEPRECATION")
    private fun wifiInfo(): android.net.wifi.WifiInfo? = try { (applicationContext.getSystemService(Context.WIFI_SERVICE) as android.net.wifi.WifiManager).connectionInfo } catch (_: Exception) { null }
    private fun wifiBars(rssi: Int): Int = if (rssi >= -58) 3 else if (rssi >= -70) 2 else 1
    /** 0 bağlı değil, 1 Wi-Fi, 2 kablolu/diğer */
    private fun netKind(): Int { val c = cm(); val n = c.activeNetwork ?: return 0; val caps = c.getNetworkCapabilities(n) ?: return 0
        return if (caps.hasTransport(android.net.NetworkCapabilities.TRANSPORT_WIFI)) 1 else 2 }
    private fun hasInternet(): Boolean { val c = cm(); val n = c.activeNetwork ?: return false
        return c.getNetworkCapabilities(n)?.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET) == true }
    private fun updateWifi() {
        val kind = netKind(); val wasOnline = online; online = kind != 0 && hasInternet()
        val lvl = if (kind == 1) wifiBars(wifiInfo()?.rssi ?: -50) else 3
        wifiIcon.set(if (online) kind else 0, lvl, cPill())
        if (wasOnline != online) applyTopItems()
        // Bağlantı geri gelince hava durumu ve ekran koruyucu fotoğrafları beklemeden yenilenir
        if (!wasOnline && online) { lastWeather = System.currentTimeMillis(); fetchWeather(); if (prefs.getInt("saverBg", 0) == 0) fetchBing() }
    }
    // Ağ değişince (kopma/bağlanma) saniyesinde haber alınır; dakikalık saat döngüsünü beklemeye gerek kalmaz
    private fun watchNetwork() { if (Build.VERSION.SDK_INT < 24 || netCallback != null) return
        val cb = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(n: android.net.Network) { handler.post { updateWifi() } }
            override fun onLost(n: android.net.Network) { handler.postDelayed({ updateWifi() }, 300) }
            override fun onCapabilitiesChanged(n: android.net.Network, c: android.net.NetworkCapabilities) { handler.post { updateWifi() } } }
        try { cm().registerDefaultNetworkCallback(cb); netCallback = cb } catch (_: Exception) {} }
    private fun showNetPanel() {
        val dlg = PanelDialog(); val box = panelBox(); box.addView(titleView("Ağ Bağlantısı"))
        box.addView(View(this).apply { setBackgroundColor(cDiv()) }, LinearLayout.LayoutParams(matchP, dp(1)).apply { setMargins(0, 0, 0, du(6)) })
        val icon = NetView(this)
        fun row(label: String, withIcon: Boolean = false): TextView {
            val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(du(10), du(5), du(10), du(5)) }
            r.addView(TextView(this).apply { text = label; textSize = sp(12.5f); setTextColor(cSub()) }, LinearLayout.LayoutParams(0, wrap, 1f))
            if (withIcon) r.addView(icon, LinearLayout.LayoutParams(du(20), du(20)).apply { setMargins(0, 0, du(6), 0) })
            val v = TextView(this).apply { textSize = sp(12.5f); setTextColor(cText()); gravity = Gravity.END; maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END }
            r.addView(v, LinearLayout.LayoutParams(wrap, wrap)); box.addView(r); return v }
        val vType = row("Bağlantı"); val vName = row("Ağ adı"); val vSig = row("Sinyal", true); val vSpeed = row("Bağlantı hızı"); val vBand = row("Frekans"); val vIp = row("IP adresi"); val vNet = row("İnternet")
        box.addView(View(this).apply { setBackgroundColor(cDiv()) }, LinearLayout.LayoutParams(matchP, dp(1)).apply { setMargins(du(10), du(6), du(10), du(6)) })
        val needPerm = Build.VERSION.SDK_INT >= 23 && checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION) != android.content.pm.PackageManager.PERMISSION_GRANTED
        var permRow: View? = null
        if (needPerm) permRow = menuRow(PItem("Ağ Adını Göster", GlyphView.INFO, "#5B8BD0", sub = "Android, ağ adı için konum izni istiyor", arrow = true)) {
            try { requestPermissions(arrayOf(android.Manifest.permission.ACCESS_FINE_LOCATION, android.Manifest.permission.ACCESS_COARSE_LOCATION), 7) } catch (_: Exception) {} }.also { box.addView(it) }
        val settingsRow = menuRow(PItem("Wi-Fi Ayarları", GlyphView.GEAR, "#6F7684", sub = "Ağ değiştir, şifre gir", arrow = true)) { dlg.dismiss(); openSystem(Settings.ACTION_WIFI_SETTINGS) }
        box.addView(settingsRow)
        fun refresh() {
            val c = cm(); val n = c.activeNetwork; val kind = netKind(); val info = if (kind == 1) wifiInfo() else null
            vType.text = when (kind) { 1 -> "Wi-Fi"; 2 -> "Kablolu"; else -> "Bağlı değil" }
            val ssid = info?.ssid?.trim('"')?.takeIf { it.isNotEmpty() && it != "<unknown ssid>" && it != "0x" }
            vName.text = ssid ?: if (kind == 1) "Gizli (izin gerekli)" else "—"
            if (info != null) { val r = info.rssi; val b = wifiBars(r); icon.set(1, b, cText()); icon.visibility = View.VISIBLE
                vSig.text = (if (b == 3) "Güçlü" else if (b == 2) "İyi" else "Zayıf") + " · $r dBm"
                vSpeed.text = if (info.linkSpeed > 0) "${info.linkSpeed} Mbps" else "—"
                val f = info.frequency; vBand.text = if (f in 2400..2500) "2,4 GHz" else if (f in 4900..5900) "5 GHz" else if (f >= 5925) "6 GHz" else "—" }
            else { icon.visibility = View.GONE; vSig.text = if (kind == 2) "Kablo" else "—"; vSpeed.text = "—"; vBand.text = "—" }
            vIp.text = (if (n != null) c.getLinkProperties(n)?.linkAddresses?.map { it.address }?.firstOrNull { it is java.net.Inet4Address }?.hostAddress else null) ?: "—"
            vNet.text = if (hasInternet()) "Var" else "Yok"
            if (ssid != null) permRow?.visibility = View.GONE
        }
        refresh()
        // Panel açıkken sinyal ve hız 2 saniyede bir canlı güncellenir
        val loop = object : Runnable { override fun run() { if (dlg !in openDialogs) return; refresh(); handler.postDelayed(this, 2000) } }
        box.addView(footView(backText(null)))
        dlg.setContentView(box); styleWindow(dlg, 330); registerDialog(dlg)
        dlg.setOnShowListener { settingsRow.requestFocus(); handler.postDelayed(loop, 2000) }; dlg.show()
    }

    // Şeffaf zeminli, koyu logolu afişler (ör. HBO Max) koyu kutuda görünmüyor -> açık zemin ver
    private val lightBgCache = HashMap<String, Boolean>()
    private fun needsLightBg(app: AppItem): Boolean = lightBgCache.getOrPut(app.pkg) { lightOf(app.image) }
    // Saf hesap (önbelleğe dokunmaz): arka plan iş parçacığında da güvenle çağrılır
    private fun lightOf(d: Drawable): Boolean =
        try {
            val w = 48; val h = 27; val bmp = android.graphics.Bitmap.createBitmap(w, h, android.graphics.Bitmap.Config.ARGB_8888)
            val old = android.graphics.Rect(d.bounds); d.setBounds(0, 0, w, h); d.draw(Canvas(bmp)); d.bounds = old
            var clear = 0; var opaque = 0; var lum = 0.0
            for (y in 0 until h) for (x in 0 until w) { val c = bmp.getPixel(x, y); val a = Color.alpha(c)
                if (a < 40) clear++ else { opaque++; lum += (0.299 * Color.red(c) + 0.587 * Color.green(c) + 0.114 * Color.blue(c)) / 255.0 } }
            bmp.recycle()
            val total = w * h; opaque > 0 && clear > total * 0.25 && lum / opaque < 0.42
        } catch (_: Exception) { false }

    // ---------- Dinamik arka plan ----------
    // Sistem animasyonları kapalı olsa da çalışsın diye kare kare kendi zamanlayıcımız
    private fun animateFrames(durMs: Long, onFrame: (Float) -> Unit, onEnd: () -> Unit = {}) {
        val start = android.os.SystemClock.uptimeMillis()
        val cb = object : android.view.Choreographer.FrameCallback { override fun doFrame(t: Long) {
            val p = ((android.os.SystemClock.uptimeMillis() - start).toFloat() / durMs).coerceIn(0f, 1f); onFrame(p)
            if (p < 1f) android.view.Choreographer.getInstance().postFrameCallback(this) else onEnd() } }
        android.view.Choreographer.getInstance().postFrameCallback(cb)
    }
    // Ölçek/saydamlık/derinlik geçişi; sistem animasyonları kapalı olsa da çalışır, yeni geçiş eskisini iptal eder
    private val viewAnimGen = java.util.WeakHashMap<View, Int>()
    private fun animView(v: View, scale: Float, alpha: Float = v.alpha, z: Float = v.translationZ, dur: Long = animDur()) {
        val g = (viewAnimGen[v] ?: 0) + 1; viewAnimGen[v] = g
        val s0 = v.scaleX; val a0 = v.alpha; val z0 = v.translationZ
        animateFrames(dur, { p -> if (viewAnimGen[v] == g) { val e = ease(p); val sc = s0 + (scale - s0) * e; v.scaleX = sc; v.scaleY = sc; v.alpha = a0 + (alpha - a0) * e; v.translationZ = z0 + (z - z0) * e } })
    }
    private fun ease(p: Float): Float = 1f - (1f - p) * (1f - p) * (1f - p)
    private val colorCache = HashMap<String, Int>()
    // Afişin baskın canlı rengi (gri/beyaz/siyah afişlerde renk yok -> 0)
    private fun appColor(app: AppItem): Int = colorCache.getOrPut(app.pkg) { colorOf(app.image) }
    private fun colorOf(d: Drawable): Int =
        try { val w = 40; val h = 22; val bmp = android.graphics.Bitmap.createBitmap(w, h, android.graphics.Bitmap.Config.ARGB_8888)
            val old = android.graphics.Rect(d.bounds); d.setBounds(0, 0, w, h); d.draw(Canvas(bmp)); d.bounds = old
            var sx = 0.0; var sy = 0.0; var wsum = 0.0; val hsv = FloatArray(3)
            for (y in 0 until h) for (x in 0 until w) { val c = bmp.getPixel(x, y); if (Color.alpha(c) < 120) continue
                Color.colorToHSV(c, hsv); if (hsv[1] < 0.28f || hsv[2] < 0.18f) continue
                val wt = (hsv[1] * hsv[2]).toDouble(); val rad = Math.toRadians(hsv[0].toDouble()); sx += Math.cos(rad) * wt; sy += Math.sin(rad) * wt; wsum += wt }
            bmp.recycle()
            if (wsum < w * h * 0.04) 0 else { var hue = Math.toDegrees(Math.atan2(sy, sx)).toFloat(); if (hue < 0) hue += 360f; Color.HSVToColor(floatArrayOf(hue, 0.7f, 0.62f)) }
        } catch (_: Exception) { 0 }
    // Dinamik arka plan: düz renkli arka planda otomatik açılır, fotoğrafta kapanır; elle de değiştirilebilir
    private fun setDynBg(on: Boolean) { prefs.edit().putBoolean("dynBg", on).apply(); tintColor = null; setTintFor(shown.firstOrNull { it.pkg == lastPkg }) }
    private fun setTintFor(app: AppItem?) {
        val c = if (app == null || !prefs.getBoolean("dynBg", true)) 0 else appColor(app)
        if (c == (tintColor ?: -1)) return; tintColor = c
        val incoming = if (tintFront) tintA else tintB; val outgoing = if (tintFront) tintB else tintA; tintFront = !tintFront
        incoming.background = if (c == 0) null else GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.argb(150, Color.red(c), Color.green(c), Color.blue(c)), Color.argb(70, Color.red(c), Color.green(c), Color.blue(c)), Color.argb(0, 0, 0, 0)))
        val a0 = incoming.alpha; val b0 = outgoing.alpha
        val gen = ++tintGen
        animateFrames(450, { p -> if (gen == tintGen) { val e = ease(p); incoming.alpha = a0 + (1f - a0) * e; outgoing.alpha = b0 * (1f - e) } }, { markFrostDirty() })
    }
    private fun launchApp(app: AppItem) {
        try { startActivity(Intent(Intent.ACTION_MAIN).setClassName(app.pkg, app.cls).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
    }

    // ---------- Kutular ----------
    private fun tile(app: AppItem): View {
        val light = needsLightBg(app)
        val bg = GradientDrawable().apply { cornerRadius = tileRadiusPx(); setColor(if (light) Color.argb(tileBgAlpha(), 236, 236, 242) else Color.argb(tileBgAlpha(), 43, 43, 64)) }
        // Seçili kutuda çerçeve yok (büyüme + ışık parlaması yeterli); yalnızca taşıma modunda turuncu çerçeve ön planda çizilir
        val ring = GradientDrawable().apply { cornerRadius = tileRadiusPx(); setColor(Color.TRANSPARENT) }
        val frame = FrameLayout(this).apply { background = bg; foreground = ring; isFocusable = true; clipToOutline = true; elevation = dp(3).toFloat(); alpha = tileRestAlpha(); tag = app.pkg }
        val img = ImageView(this).apply { setImageDrawable(app.image); if (app.isBanner) scaleType = ImageView.ScaleType.CENTER_CROP else { scaleType = ImageView.ScaleType.FIT_CENTER; setPadding(dp(tileW / 7), dp(tileH / 6), dp(tileW / 7), dp(tileH / 6)) } }
        frame.addView(img, FrameLayout.LayoutParams(matchP, matchP))
        val shine = ShineView(this); frame.addView(shine, FrameLayout.LayoutParams(matchP, matchP))
        // Yeni kurulan uygulama: sol üstte "Yeni" etiketi (ilk açılışta kaybolur)
        val badge = if (isNew(app.pkg)) TextView(this).apply { text = "Yeni"; textSize = 10f; setTextColor(Color.WHITE); typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            background = GradientDrawable().apply { cornerRadius = dp(9).toFloat(); setColor(accent()) }; setPadding(dp(7), dp(1), dp(7), dp(2)); elevation = dp(2).toFloat() }
            .also { frame.addView(it, FrameLayout.LayoutParams(wrap, wrap, Gravity.TOP or Gravity.START).apply { setMargins(dp(6), dp(6), 0, 0) }) } else null
        frame.setOnFocusChangeListener { v, hasFocus ->
            if (hasFocus) { lastPkg = app.pkg; ensureRowVisible(v); setTintFor(app); if (prefs.getBoolean("shine", true)) shine.play() else shine.stop(); animView(v, focusZoom(), 1f, dp(18).toFloat()); ring.setStroke(if (movingPkg == app.pkg) dp(3) else 0, Color.parseColor("#FF9F0A"))
                if (movingPkg == app.pkg) startJiggle(v) }
            else { animView(v, 1f, tileRestAlpha(), 0f); ring.setStroke(0, Color.TRANSPARENT); shine.stop(); if (v.rotation != 0f) { jiggleGen++; v.rotation = 0f } }
        }
        // Basma hissi: kutu bir an hafifçe içe göçer, sonra uygulama açılır
        frame.setOnClickListener { v -> if (pressing) return@setOnClickListener; pressing = true
            animView(v, focusZoom() * 0.93f, dur = 70)
            handler.postDelayed({ animView(v, focusZoom(), dur = 120); pressing = false; badge?.visibility = View.GONE; clearNew(app.pkg); launchApp(app) }, 80) }
        frame.setOnLongClickListener { showMenu(app); true }
        frame.setOnKeyListener { view, k, e -> edgeKeys(view, k, e) }
        frame.layoutParams = LinearLayout.LayoutParams(dp(tileW), dp(tileH)).apply { setMargins(dp(tileGap) / 2, 0, dp(tileGap) - dp(tileGap) / 2, 0) }
        return frame
    }
    private var pressing = false
    // Taşıma modunda taşınan kutu Apple TV'deki gibi hafifçe sallanır
    private var jiggleGen = 0
    private fun startJiggle(v: View) { val g = ++jiggleGen; val t0 = android.os.SystemClock.uptimeMillis()
        val cb = object : android.view.Choreographer.FrameCallback { override fun doFrame(t: Long) {
            if (g != jiggleGen || movingPkg == null || !v.isAttachedToWindow) { v.rotation = 0f; return }
            v.rotation = (Math.sin((android.os.SystemClock.uptimeMillis() - t0) / 280.0 * 2 * Math.PI) * 1.4).toFloat()
            android.view.Choreographer.getInstance().postFrameCallback(this) } }
        android.view.Choreographer.getInstance().postFrameCallback(cb) }
    private fun edgeKeys(view: View, keyCode: Int, event: KeyEvent): Boolean {
        if (event.action != KeyEvent.ACTION_DOWN) return false
        val row = view.parent as? ViewGroup ?: return false; val idx = row.indexOfChild(view)
        if (keyCode == KeyEvent.KEYCODE_DPAD_RIGHT && idx == row.childCount - 1) return true
        if (keyCode == KeyEvent.KEYCODE_DPAD_LEFT && idx == 0) return true
        if (keyCode == KeyEvent.KEYCODE_DPAD_UP && grid.indexOfChild(row) == 0) { revealGear(); return true }
        return false
    }
}

// Küçük çizim simgeleri
class GlyphView(context: Context, private val kind: Int) : View(context) {
    companion object {
        const val GRID = 0; const val PALETTE = 1; const val CLOUD = 2; const val RESET = 3; const val MOVE = 4; const val EYE_OFF = 5; const val TRASH = 6; const val INFO = 7
        const val CHECK = 8; const val CHEVRON = 9; const val SLIDERS = 10; const val MONITOR = 13; const val GEAR = 15
        const val IMAGE = 16; const val CONTRAST = 17; const val BLUR = 18; const val CORNER = 19; const val OPACITY = 20; const val ZOOM = 21; const val CLOCK = 23; const val HEART = 25; const val SEARCH = 26
    }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }
    private val gearPath: Path by lazy { androidx.core.graphics.PathParser.createPathFromPathData("M19.14,12.94c0.04,-0.3 0.06,-0.61 0.06,-0.94c0,-0.32 -0.02,-0.64 -0.07,-0.94l2.03,-1.58c0.18,-0.14 0.23,-0.41 0.12,-0.61l-1.92,-3.32c-0.12,-0.22 -0.37,-0.29 -0.59,-0.22l-2.39,0.96c-0.5,-0.38 -1.03,-0.7 -1.62,-0.94L14.4,2.81c-0.04,-0.24 -0.24,-0.41 -0.48,-0.41h-3.84c-0.24,0 -0.43,0.17 -0.47,0.41L9.25,5.35C8.66,5.59 8.12,5.92 7.63,6.29L5.24,5.33c-0.22,-0.08 -0.47,0 -0.59,0.22L2.74,8.87C2.62,9.08 2.66,9.34 2.86,9.48l2.03,1.58C4.84,11.36 4.8,11.69 4.8,12s0.02,0.64 0.07,0.94l-2.03,1.58c-0.18,0.14 -0.23,0.41 -0.12,0.61l1.92,3.32c0.12,0.22 0.37,0.29 0.59,0.22l2.39,-0.96c0.5,0.38 1.03,0.7 1.62,0.94l0.36,2.54c0.05,0.24 0.24,0.41 0.48,0.41h3.84c0.24,0 0.44,-0.17 0.47,-0.41l0.36,-2.54c0.59,-0.24 1.13,-0.56 1.62,-0.94l2.39,0.96c0.22,0.08 0.47,0 0.59,-0.22l1.92,-3.32c0.12,-0.22 0.07,-0.47 -0.12,-0.61L19.14,12.94zM12,15.6c-1.98,0 -3.6,-1.62 -3.6,-3.6s1.62,-3.6 3.6,-3.6s3.6,1.62 3.6,3.6S13.98,15.6 12,15.6z") }
    fun setTint(c: Int) { p.color = c; invalidate() }
    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat(); val cx = w / 2f; val cy = height / 2f; p.strokeWidth = w * 0.085f; p.style = Paint.Style.STROKE
        when (kind) {
            GRID -> { p.style = Paint.Style.FILL; val s = w * 0.2f; val g = w * 0.07f; for (i in 0..1) for (j in 0..1) { val l = cx - g / 2 - s + i * (s + g); val t = cy - g / 2 - s + j * (s + g); canvas.drawRoundRect(RectF(l, t, l + s, t + s), w * 0.04f, w * 0.04f, p) } }
            PALETTE -> { canvas.drawCircle(cx, cy, w * 0.29f, p); p.style = Paint.Style.FILL; canvas.drawCircle(cx - w * 0.10f, cy - w * 0.07f, w * 0.045f, p); canvas.drawCircle(cx + w * 0.07f, cy - w * 0.12f, w * 0.045f, p); canvas.drawCircle(cx + w * 0.14f, cy + w * 0.05f, w * 0.045f, p); canvas.drawCircle(cx - w * 0.04f, cy + w * 0.10f, w * 0.045f, p) }
            CLOUD -> { p.style = Paint.Style.FILL; canvas.drawCircle(cx - w * 0.13f, cy + w * 0.04f, w * 0.13f, p); canvas.drawCircle(cx + w * 0.02f, cy - w * 0.05f, w * 0.17f, p); canvas.drawCircle(cx + w * 0.16f, cy + w * 0.05f, w * 0.12f, p); canvas.drawRoundRect(RectF(cx - w * 0.24f, cy + w * 0.04f, cx + w * 0.27f, cy + w * 0.17f), w * 0.06f, w * 0.06f, p) }
            RESET -> { val r = w * 0.26f; canvas.drawArc(RectF(cx - r, cy - r, cx + r, cy + r), -40f, 270f, false, p); val ang = Math.toRadians(230.0); val px = cx + (r * Math.cos(ang)).toFloat(); val py = cy + (r * Math.sin(ang)).toFloat(); val nx = Math.cos(ang).toFloat(); val ny = Math.sin(ang).toFloat(); val path = Path(); path.moveTo(px - ny * w * 0.13f, py + nx * w * 0.13f); path.lineTo(px + nx * w * 0.10f, py + ny * w * 0.10f); path.lineTo(px - nx * w * 0.10f, py - ny * w * 0.10f); path.close(); p.style = Paint.Style.FILL; canvas.drawPath(path, p) }
            MOVE -> { val a = w * 0.28f; val h = w * 0.12f; canvas.drawLine(cx - a, cy, cx + a, cy, p); canvas.drawLine(cx, cy - a, cx, cy + a, p); canvas.drawLine(cx - a, cy, cx - a + h, cy - h, p); canvas.drawLine(cx - a, cy, cx - a + h, cy + h, p); canvas.drawLine(cx + a, cy, cx + a - h, cy - h, p); canvas.drawLine(cx + a, cy, cx + a - h, cy + h, p); canvas.drawLine(cx, cy - a, cx - h, cy - a + h, p); canvas.drawLine(cx, cy - a, cx + h, cy - a + h, p); canvas.drawLine(cx, cy + a, cx - h, cy + a - h, p); canvas.drawLine(cx, cy + a, cx + h, cy + a - h, p) }
            EYE_OFF -> { canvas.drawOval(RectF(cx - w * 0.3f, cy - w * 0.17f, cx + w * 0.3f, cy + w * 0.17f), p); p.style = Paint.Style.FILL; canvas.drawCircle(cx, cy, w * 0.07f, p); p.style = Paint.Style.STROKE; canvas.drawLine(cx - w * 0.27f, cy + w * 0.27f, cx + w * 0.27f, cy - w * 0.27f, p) }
            TRASH -> { canvas.drawLine(cx - w * 0.25f, cy - w * 0.16f, cx + w * 0.25f, cy - w * 0.16f, p); canvas.drawLine(cx - w * 0.08f, cy - w * 0.25f, cx + w * 0.08f, cy - w * 0.25f, p); canvas.drawRoundRect(RectF(cx - w * 0.18f, cy - w * 0.16f, cx + w * 0.18f, cy + w * 0.28f), w * 0.05f, w * 0.05f, p); canvas.drawLine(cx - w * 0.05f, cy - w * 0.06f, cx - w * 0.05f, cy + w * 0.18f, p); canvas.drawLine(cx + w * 0.05f, cy - w * 0.06f, cx + w * 0.05f, cy + w * 0.18f, p) }
            INFO -> { canvas.drawCircle(cx, cy, w * 0.3f, p); p.style = Paint.Style.FILL; canvas.drawCircle(cx, cy - w * 0.11f, w * 0.04f, p); p.style = Paint.Style.STROKE; canvas.drawLine(cx, cy - w * 0.03f, cx, cy + w * 0.15f, p) }
            CHECK -> { val path = Path(); path.moveTo(cx - w * 0.2f, cy); path.lineTo(cx - w * 0.05f, cy + w * 0.15f); path.lineTo(cx + w * 0.22f, cy - w * 0.14f); canvas.drawPath(path, p) }
            CHEVRON -> { val path = Path(); path.moveTo(cx - w * 0.08f, cy - w * 0.2f); path.lineTo(cx + w * 0.1f, cy); path.lineTo(cx - w * 0.08f, cy + w * 0.2f); canvas.drawPath(path, p) }
            SLIDERS -> { canvas.drawLine(cx - w * 0.3f, cy - w * 0.14f, cx + w * 0.3f, cy - w * 0.14f, p); canvas.drawLine(cx - w * 0.3f, cy + w * 0.14f, cx + w * 0.3f, cy + w * 0.14f, p); p.style = Paint.Style.FILL; canvas.drawCircle(cx - w * 0.1f, cy - w * 0.14f, w * 0.085f, p); canvas.drawCircle(cx + w * 0.12f, cy + w * 0.14f, w * 0.085f, p) }
            MONITOR -> { canvas.drawRoundRect(RectF(cx - w * 0.3f, cy - w * 0.24f, cx + w * 0.3f, cy + w * 0.12f), w * 0.04f, w * 0.04f, p); canvas.drawLine(cx - w * 0.12f, cy + w * 0.26f, cx + w * 0.12f, cy + w * 0.26f, p); canvas.drawLine(cx, cy + w * 0.12f, cx, cy + w * 0.26f, p) }
            GEAR -> { // Android'in standart ayarlar (dişli) simgesi
                val path = Path(gearPath); val m = android.graphics.Matrix(); val sc = w * (if (w > 26 * resources.displayMetrics.density) 0.62f else 0.92f) / 24f; m.setScale(sc, sc); m.postTranslate(cx - 12f * sc, cy - 12f * sc); path.transform(m)
                p.style = Paint.Style.FILL; canvas.drawPath(path, p) }
            HEART -> { p.style = Paint.Style.FILL; val u = w * 0.19f; val hp = Path(); hp.moveTo(cx, cy + u * 1.15f)
                hp.cubicTo(cx - u * 2.3f, cy - u * 0.2f, cx - u * 1.1f, cy - u * 1.9f, cx, cy - u * 0.7f); hp.cubicTo(cx + u * 1.1f, cy - u * 1.9f, cx + u * 2.3f, cy - u * 0.2f, cx, cy + u * 1.15f); canvas.drawPath(hp, p) }
            IMAGE -> { canvas.drawRoundRect(RectF(cx - w * 0.3f, cy - w * 0.24f, cx + w * 0.3f, cy + w * 0.24f), w * 0.05f, w * 0.05f, p); p.style = Paint.Style.FILL; canvas.drawCircle(cx - w * 0.12f, cy - w * 0.08f, w * 0.05f, p); p.style = Paint.Style.STROKE; val path = Path(); path.moveTo(cx - w * 0.26f, cy + w * 0.16f); path.lineTo(cx - w * 0.06f, cy - w * 0.04f); path.lineTo(cx + w * 0.1f, cy + w * 0.12f); path.lineTo(cx + w * 0.18f, cy + w * 0.04f); path.lineTo(cx + w * 0.28f, cy + w * 0.16f); canvas.drawPath(path, p) }
            CONTRAST -> { canvas.drawCircle(cx, cy, w * 0.28f, p); val path = Path(); path.addArc(RectF(cx - w * 0.28f, cy - w * 0.28f, cx + w * 0.28f, cy + w * 0.28f), 90f, 180f); p.style = Paint.Style.FILL; canvas.drawPath(path, p) }
            BLUR -> { p.style = Paint.Style.FILL; canvas.drawCircle(cx, cy, w * 0.26f, p); p.color = Color.argb(120, 255, 255, 255); canvas.drawCircle(cx + w * 0.12f, cy - w * 0.1f, w * 0.14f, p) }
            CORNER -> { val path = Path(); path.moveTo(cx - w * 0.26f, cy + w * 0.26f); path.lineTo(cx - w * 0.26f, cy - w * 0.08f); path.cubicTo(cx - w * 0.26f, cy - w * 0.26f, cx - w * 0.26f, cy - w * 0.26f, cx - w * 0.08f, cy - w * 0.26f); path.lineTo(cx + w * 0.26f, cy - w * 0.26f); canvas.drawPath(path, p) }
            OPACITY -> { for (i in 0..2) for (j in 0..2) { if ((i + j) % 2 == 0) { p.style = Paint.Style.FILL; val s = w * 0.17f; val l = cx - w * 0.26f + i * s; val t = cy - w * 0.26f + j * s; canvas.drawRect(l, t, l + s, t + s, p) } }; p.style = Paint.Style.STROKE; canvas.drawCircle(cx, cy, w * 0.26f, p) }
            ZOOM -> { canvas.drawCircle(cx - w * 0.06f, cy - w * 0.06f, w * 0.2f, p); canvas.drawLine(cx + w * 0.09f, cy + w * 0.09f, cx + w * 0.26f, cy + w * 0.26f, p); canvas.drawLine(cx - w * 0.14f, cy - w * 0.06f, cx + w * 0.02f, cy - w * 0.06f, p); canvas.drawLine(cx - w * 0.06f, cy - w * 0.14f, cx - w * 0.06f, cy + w * 0.02f, p) }
            SEARCH -> { canvas.drawCircle(cx - w * 0.05f, cy - w * 0.05f, w * 0.19f, p); canvas.drawLine(cx + w * 0.09f, cy + w * 0.09f, cx + w * 0.25f, cy + w * 0.25f, p) }
            CLOCK -> { canvas.drawCircle(cx, cy, w * 0.28f, p); canvas.drawLine(cx, cy, cx, cy - w * 0.16f, p); canvas.drawLine(cx, cy, cx + w * 0.12f, cy + w * 0.06f, p) }
            else -> {}
        }
    }
}

// Hava durumu simgeleri
class WxIconView(context: Context, private var kind: Int) : View(context) {
    companion object { var cloudColor = Color.parseColor("#E8EBF2"); const val SUN = 0; const val MOON = 1; const val PARTLY = 2; const val CLOUD = 3; const val RAIN = 4; const val SNOW = 5; const val STORM = 6; const val FOG = 7 }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }
    fun setKind(k: Int) { kind = k; invalidate() }
    private fun cloud(c: Canvas, cx: Float, cy: Float, s: Float, color: Int) { p.style = Paint.Style.FILL; p.color = color; c.drawCircle(cx - 0.22f * s, cy + 0.06f * s, 0.2f * s, p); c.drawCircle(cx + 0.02f * s, cy - 0.06f * s, 0.26f * s, p); c.drawCircle(cx + 0.26f * s, cy + 0.07f * s, 0.18f * s, p); c.drawRoundRect(RectF(cx - 0.42f * s, cy + 0.06f * s, cx + 0.44f * s, cy + 0.26f * s), 0.1f * s, 0.1f * s, p) }
    private fun sun(c: Canvas, cx: Float, cy: Float, r: Float) { p.color = Color.parseColor("#FFD27A"); p.style = Paint.Style.FILL; c.drawCircle(cx, cy, r, p); p.style = Paint.Style.STROKE; p.strokeWidth = r * 0.35f; for (i in 0 until 8) { val a = Math.toRadians(i * 45.0); val cs = Math.cos(a).toFloat(); val sn = Math.sin(a).toFloat(); c.drawLine(cx + cs * r * 1.5f, cy + sn * r * 1.5f, cx + cs * r * 1.95f, cy + sn * r * 1.95f, p) } }
    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat(); val cx = w / 2f; val cy = height / 2f; val white = cloudColor
        when (kind) {
            SUN -> sun(canvas, cx, cy, w * 0.2f)
            MOON -> { val a = Path(); a.addCircle(cx, cy, w * 0.3f, Path.Direction.CW); val b = Path(); b.addCircle(cx + w * 0.15f, cy - w * 0.1f, w * 0.26f, Path.Direction.CW); a.op(b, Path.Op.DIFFERENCE); p.style = Paint.Style.FILL; p.color = white; canvas.drawPath(a, p) }
            PARTLY -> { sun(canvas, cx + w * 0.16f, cy - w * 0.16f, w * 0.12f); cloud(canvas, cx - w * 0.04f, cy + w * 0.08f, w * 0.85f, white) }
            CLOUD -> cloud(canvas, cx, cy, w * 0.95f, white)
            RAIN -> { cloud(canvas, cx, cy - w * 0.12f, w * 0.9f, white); p.style = Paint.Style.STROKE; p.color = Color.parseColor("#8FC1FF"); p.strokeWidth = w * 0.07f; for (i in 0..2) { val x = cx - w * 0.2f + i * w * 0.2f; canvas.drawLine(x, cy + w * 0.22f, x - w * 0.05f, cy + w * 0.36f, p) } }
            SNOW -> { cloud(canvas, cx, cy - w * 0.12f, w * 0.9f, white); p.style = Paint.Style.FILL; p.color = Color.WHITE; for (i in 0..2) canvas.drawCircle(cx - w * 0.2f + i * w * 0.2f, cy + w * 0.3f, w * 0.045f, p) }
            STORM -> { cloud(canvas, cx, cy - w * 0.14f, w * 0.9f, Color.parseColor("#B4BCC9")); val b = Path(); b.moveTo(cx + w * 0.06f, cy + w * 0.1f); b.lineTo(cx - w * 0.08f, cy + w * 0.3f); b.lineTo(cx, cy + w * 0.3f); b.lineTo(cx - w * 0.06f, cy + w * 0.46f); b.lineTo(cx + w * 0.14f, cy + w * 0.2f); b.lineTo(cx + w * 0.05f, cy + w * 0.2f); b.close(); p.style = Paint.Style.FILL; p.color = Color.parseColor("#FFD27A"); canvas.drawPath(b, p) }
            FOG -> { p.style = Paint.Style.STROKE; p.color = Color.parseColor("#C5CAD6"); p.strokeWidth = w * 0.08f; canvas.drawLine(cx - w * 0.3f, cy - w * 0.16f, cx + w * 0.3f, cy - w * 0.16f, p); canvas.drawLine(cx - w * 0.22f, cy, cx + w * 0.34f, cy, p); canvas.drawLine(cx - w * 0.3f, cy + w * 0.16f, cx + w * 0.22f, cy + w * 0.16f, p) }
            else -> {}
        }
    }
}

// Apple tarzı aç/kapa anahtarı (sistem animasyonları kapalı olsa da kayarak geçer)
class SwitchView(context: Context, initial: Boolean, private val light: Boolean = false) : View(context) {
    var on = initial; private set
    private var pos = if (initial) 1f else 0f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    fun flip() { on = !on; val from = pos; val to = if (on) 1f else 0f; val start = android.os.SystemClock.uptimeMillis()
        val cb = object : android.view.Choreographer.FrameCallback { override fun doFrame(t: Long) {
            val k = ((android.os.SystemClock.uptimeMillis() - start) / 180f).coerceIn(0f, 1f); val e = 1f - (1f - k) * (1f - k)
            pos = from + (to - from) * e; invalidate(); if (k < 1f) android.view.Choreographer.getInstance().postFrameCallback(this) } }
        android.view.Choreographer.getInstance().postFrameCallback(cb) }
    private fun mix(a: Int, b: Int, t: Float): Int = Color.rgb((Color.red(a) + (Color.red(b) - Color.red(a)) * t).toInt(), (Color.green(a) + (Color.green(b) - Color.green(a)) * t).toInt(), (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t).toInt())
    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat(); val r = h / 2f
        p.style = Paint.Style.FILL; p.color = mix(Color.parseColor(if (light) "#D1D1D6" else "#48484E"), Color.parseColor("#34C759"), pos); c.drawRoundRect(RectF(0f, 0f, w, h), r, r, p)
        val kr = r - h * 0.09f; val cx = r + (w - 2 * r) * pos
        p.color = Color.argb(60, 0, 0, 0); c.drawCircle(cx, r + h * 0.04f, kr, p)
        p.color = Color.WHITE; c.drawCircle(cx, r, kr, p)
    }
}

// Ağ simgesi: Wi-Fi'de sinyal gücü kadar dolu yay (1-3), kabloluda bağlı kutular, bağlantı yokken silik yaylar + çapraz çizgi
class NetView(context: Context) : View(context) {
    private var kind = 1; private var level = 3; private var color = Color.WHITE
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }
    private val oval = RectF()
    fun set(k: Int, l: Int, c: Int) { if (k != kind || l != level || c != color) { kind = k; level = l; color = c; invalidate() } }
    private fun a(c: Int, al: Int) = Color.argb(al, Color.red(c), Color.green(c), Color.blue(c))
    override fun onDraw(cv: Canvas) {
        val s = minOf(width - paddingLeft - paddingRight, height - paddingTop - paddingBottom).toFloat(); if (s <= 0f) return
        val cx = paddingLeft + (width - paddingLeft - paddingRight) / 2f; val cy = paddingTop + (height - paddingTop - paddingBottom) / 2f
        p.strokeWidth = s * 0.1f
        if (kind == 2) {   // kablolu: üstte bir, altta iki kutu, aralarında bağlantı
            p.style = Paint.Style.STROKE; p.color = color; val b = s * 0.2f
            cv.drawLine(cx, cy - s * 0.12f, cx, cy + s * 0.02f, p); cv.drawLine(cx - s * 0.3f, cy + s * 0.02f, cx + s * 0.3f, cy + s * 0.02f, p)
            cv.drawLine(cx - s * 0.3f, cy + s * 0.02f, cx - s * 0.3f, cy + s * 0.14f, p); cv.drawLine(cx + s * 0.3f, cy + s * 0.02f, cx + s * 0.3f, cy + s * 0.14f, p)
            p.style = Paint.Style.FILL
            cv.drawRoundRect(RectF(cx - b, cy - s * 0.44f, cx + b, cy - s * 0.12f), s * 0.05f, s * 0.05f, p)
            cv.drawRoundRect(RectF(cx - s * 0.3f - b * 0.8f, cy + s * 0.14f, cx - s * 0.3f + b * 0.8f, cy + s * 0.42f), s * 0.05f, s * 0.05f, p)
            cv.drawRoundRect(RectF(cx + s * 0.3f - b * 0.8f, cy + s * 0.14f, cx + s * 0.3f + b * 0.8f, cy + s * 0.42f), s * 0.05f, s * 0.05f, p)
            return }
        val by = cy + s * 0.3f
        p.style = Paint.Style.STROKE
        for (i in 1..3) { val r = s * (0.13f + 0.155f * i); oval.set(cx - r, by - r, cx + r, by + r)
            p.color = if (kind == 1 && i <= level) color else a(color, 70); cv.drawArc(oval, 225f, 90f, false, p) }
        p.style = Paint.Style.FILL; p.color = if (kind == 1) color else a(color, 70); cv.drawCircle(cx, by - s * 0.02f, s * 0.07f, p)
        if (kind == 0) { p.style = Paint.Style.STROKE; p.color = color; p.strokeWidth = s * 0.09f; cv.drawLine(cx - s * 0.36f, cy - s * 0.36f, cx + s * 0.36f, cy + s * 0.36f, p) }
    }
}

// Galeri durum simgesi. transient = true (pencere köşesi): boştayken hiç görünmez, yalnız işlem sırasında ve kısa süre sonrasında çıkar. İndirirken: halka mavi dolar (boyut bilinmiyorsa mavi yay döner), ok hafifçe
// iner-kalkar. Bitince: mavi daire büyüyerek belirir, içine tik çizilir. Hata: kırmızı halka + ünlem.
// outline = true ise (fotoğraf üstündeki küçük işaret) dairenin çevresine beyaz kenar ve gölge eklenir, her fotoğrafta seçilir.
class StatusBadge(context: Context, private val fg: Int, private val acc: Int, private val outline: Boolean = false, private val transient: Boolean = false) : View(context) {
    private var state = 0; private var prog = -1f; private var shown = 0f; private var t0 = 0L; private var gen = 0
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }
    private val path = android.graphics.Path(); private val seg = android.graphics.Path(); private val oval = RectF()
    private fun now() = android.os.SystemClock.uptimeMillis()
    fun idle() = set(0)
    fun busy() { prog = -1f; shown = 0f; set(1) }
    fun progress(f: Float) { prog = f.coerceIn(0f, 1f) }
    fun done(animate: Boolean = true) = set(2, animate)
    fun fail() = set(3)
    private fun set(s: Int, animate: Boolean = true) { state = s; t0 = if (animate) now() else now() - 10_000; gen++; if (animate) loop() else invalidate() }
    private fun loop() { val g = gen
        val cb = object : android.view.Choreographer.FrameCallback { override fun doFrame(t: Long) { if (g != gen) return; invalidate()
            if (state == 1 || now() - t0 < (if (transient && state >= 2) 2900 else 700)) android.view.Choreographer.getInstance().postFrameCallback(this) } }
        android.view.Choreographer.getInstance().postFrameCallback(cb) }
    override fun onAttachedToWindow() { super.onAttachedToWindow(); gen++; loop() }
    override fun onDetachedFromWindow() { gen++; super.onDetachedFromWindow() }
    private fun alpha(c: Int, a: Int) = Color.argb(a, Color.red(c), Color.green(c), Color.blue(c))
    override fun onDraw(c: Canvas) {
        val s = minOf(width, height).toFloat(); if (s <= 0f) return
        val cx = width / 2f; val cy = height / 2f; val sw = s * 0.085f; val r = s / 2f - sw; val el = (now() - t0).toFloat()
        oval.set(cx - r, cy - r, cx + r, cy + r)
        if (transient && state == 0) return
        // Geçici modda tik/ünlem 2,4 sn görünür, sonra yumuşakça kaybolur
        val fade = if (transient && state >= 2) (1f - (el - 2400f) / 400f).coerceIn(0f, 1f) else 1f
        if (fade <= 0f) { state = 0; return }
        if (fade < 1f) c.saveLayerAlpha(0f, 0f, width.toFloat(), height.toFloat(), (fade * 255).toInt())
        drawState(c, cx, cy, sw, r, el)
        if (fade < 1f) c.restore()
    }
    private fun drawState(c: Canvas, cx: Float, cy: Float, sw: Float, r: Float, el: Float) {
        when (state) {
            2 -> {
                val k = (el / 280f).coerceIn(0f, 1f); val km = k - 1f; val pop = 1f + 2.70158f * km * km * km + 1.70158f * km * km
                val rr = (r + sw / 2f) * pop
                p.style = Paint.Style.FILL
                if (outline) { p.color = Color.argb(70, 0, 0, 0); c.drawCircle(cx, cy + sw * 0.4f, rr + sw * 0.6f, p); p.color = Color.WHITE; c.drawCircle(cx, cy, rr + sw * 0.55f, p) }
                p.color = acc; c.drawCircle(cx, cy, rr, p)
                val kc = ((el - 140f) / 260f).coerceIn(0f, 1f); if (kc <= 0f) return
                path.reset(); path.moveTo(cx - r * 0.42f, cy + r * 0.02f); path.lineTo(cx - r * 0.12f, cy + r * 0.32f); path.lineTo(cx + r * 0.45f, cy - r * 0.30f)
                val pm = android.graphics.PathMeasure(path, false); seg.reset(); pm.getSegment(0f, pm.length * (1f - (1f - kc) * (1f - kc)), seg, true)
                p.style = Paint.Style.STROKE; p.strokeWidth = sw * 1.15f; p.color = Color.WHITE; c.drawPath(seg, p)
            }
            3 -> {
                val red = Color.parseColor("#FF453A")
                p.style = Paint.Style.STROKE; p.strokeWidth = sw; p.color = red; c.drawCircle(cx, cy, r, p)
                p.strokeWidth = sw * 1.1f; c.drawLine(cx, cy - r * 0.45f, cx, cy + r * 0.12f, p)
                p.style = Paint.Style.FILL; c.drawCircle(cx, cy + r * 0.42f, sw * 0.7f, p)
            }
            else -> {
                p.style = Paint.Style.STROKE; p.strokeWidth = sw; p.color = alpha(fg, if (state == 1) 60 else 70); c.drawCircle(cx, cy, r, p)
                if (state == 1) { p.color = acc
                    if (prog < 0f) c.drawArc(oval, (el * 0.4f) % 360f - 90f, 100f, false, p)
                    else { shown += (prog - shown) * 0.25f; c.drawArc(oval, -90f, maxOf(10f, 360f * shown), false, p) } }
                val u = r * 0.5f; val dy = if (state == 1) (Math.sin(el / 170.0) * u * 0.14).toFloat() else 0f
                p.color = if (state == 1) fg else alpha(fg, 190); p.strokeWidth = sw * 0.95f
                c.drawLine(cx, cy - u * 0.95f + dy, cx, cy + u * 0.3f + dy, p)
                path.reset(); path.moveTo(cx - u * 0.5f, cy - u * 0.15f + dy); path.lineTo(cx, cy + u * 0.35f + dy); path.lineTo(cx + u * 0.5f, cy - u * 0.15f + dy); c.drawPath(path, p)
                path.reset(); path.moveTo(cx - u * 0.8f, cy + u * 0.45f); path.lineTo(cx - u * 0.8f, cy + u * 0.85f); path.lineTo(cx + u * 0.8f, cy + u * 0.85f); path.lineTo(cx + u * 0.8f, cy + u * 0.45f); c.drawPath(path, p)
            }
        }
    }
}

// Favori işareti: beyaz kenarlı kırmızı daire içinde beyaz kalp (fotoğraf köşesinde). pop(): eklenince büyüyerek belirir.
class HeartBadge(context: Context) : View(context) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG); private val path = Path(); private var t0 = 0L
    private fun now() = android.os.SystemClock.uptimeMillis()
    fun pop() { t0 = now(); val cb = object : android.view.Choreographer.FrameCallback { override fun doFrame(t: Long) { invalidate(); if (now() - t0 < 320) android.view.Choreographer.getInstance().postFrameCallback(this) } }
        android.view.Choreographer.getInstance().postFrameCallback(cb) }
    override fun onDraw(c: Canvas) {
        val s = minOf(width, height).toFloat(); if (s <= 0f) return
        val k = ((now() - t0) / 300f).coerceIn(0f, 1f); val km = k - 1f; val pop = 1f + 2.70158f * km * km * km + 1.70158f * km * km
        val cx = width / 2f; val cy = height / 2f; val r = s / 2f * 0.86f * pop; val sw = s * 0.07f
        p.style = Paint.Style.FILL
        p.color = Color.argb(70, 0, 0, 0); c.drawCircle(cx, cy + sw * 0.5f, r + sw, p)
        p.color = Color.WHITE; c.drawCircle(cx, cy, r + sw * 0.8f, p)
        p.color = Color.parseColor("#FF375F"); c.drawCircle(cx, cy, r, p)
        val u = r * 0.36f; path.reset(); path.moveTo(cx, cy + u * 1.15f)
        path.cubicTo(cx - u * 2.3f, cy - u * 0.2f, cx - u * 1.1f, cy - u * 1.9f, cx, cy - u * 0.7f)
        path.cubicTo(cx + u * 1.1f, cy - u * 1.9f, cx + u * 2.3f, cy - u * 0.2f, cx, cy + u * 1.15f)
        p.color = Color.WHITE; c.drawPath(path, p)
    }
}

// Apple TV tarzı cam yansıması: seçilince kutunun üzerinden çapraz bir ışık bandı kayar, üstte hafif parlaklık kalır
class ShineView(context: Context) : View(context) {
    private var active = false; private var prog = 2f; private var gen = 0
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    fun play() { active = true; val g = ++gen; prog = 0f; val start = android.os.SystemClock.uptimeMillis() + 120
        val cb = object : android.view.Choreographer.FrameCallback { override fun doFrame(t: Long) { if (g != gen) return
            val k = ((android.os.SystemClock.uptimeMillis() - start) / 850f).coerceIn(0f, 1f); prog = k * k * (3 - 2 * k); invalidate()
            if (k < 1f) android.view.Choreographer.getInstance().postFrameCallback(this) else { prog = 2f; invalidate() } } }
        android.view.Choreographer.getInstance().postFrameCallback(cb) }
    fun stop() { active = false; gen++; prog = 2f; invalidate() }
    override fun onDraw(c: Canvas) {
        if (!active) return
        val w = width.toFloat(); val h = height.toFloat()
        // Üstte sabit, çok hafif cam parlaklığı
        p.shader = android.graphics.LinearGradient(0f, 0f, 0f, h * 0.55f, Color.argb(34, 255, 255, 255), Color.argb(0, 255, 255, 255), Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w, h, p)
        // Kayan çapraz ışık bandı
        if (prog <= 1f) { val band = w * 0.28f; val cx = -band + (w + 2 * band) * prog
            p.shader = android.graphics.LinearGradient(cx - band, -band * 0.45f, cx + band, band * 0.45f, intArrayOf(Color.argb(0, 255, 255, 255), Color.argb(95, 255, 255, 255), Color.argb(0, 255, 255, 255)), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
            c.drawRect(0f, 0f, w, h, p) }
        p.shader = null
    }
}

// Buzlu cam zemini: önceden bulanıklaştırılmış ekran görüntüsünün, görünümün ekrandaki yerine düşen kısmını çizer;
// üstüne cam tonu ve ince parlak kenar ekler. Yükseklik sonradan değişse de doğru parçayı çizer (yeniden hesap gerekmez).
class FrostDrawable(private val snap: android.graphics.Bitmap, private val scale: Float, private val sx: Int, private val sy: Int,
                    private val radius: Float, private val tintTop: Int, private val tintBottom: Int, private val strokeW: Float, private val strokeC: Int) : Drawable() {
    private val bp = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG)
    private val kp = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val path = Path(); private val rf = RectF(); private val src = android.graphics.Rect()
    override fun draw(c: Canvas) {
        val b = bounds; if (b.isEmpty) return
        rf.set(b); path.reset(); path.addRoundRect(rf, radius, radius, Path.Direction.CW)
        val save = c.save(); c.clipPath(path)
        src.set((sx * scale).toInt().coerceIn(0, snap.width - 1), (sy * scale).toInt().coerceIn(0, snap.height - 1), 0, 0)
        src.right = ((sx + b.width()) * scale).toInt().coerceIn(src.left + 1, snap.width); src.bottom = ((sy + b.height()) * scale).toInt().coerceIn(src.top + 1, snap.height)
        c.drawBitmap(snap, src, b, bp)
        tp.shader = android.graphics.LinearGradient(0f, b.top.toFloat(), 0f, b.bottom.toFloat(), tintTop, tintBottom, Shader.TileMode.CLAMP); c.drawRect(b, tp)
        c.restoreToCount(save)
        kp.strokeWidth = strokeW; kp.color = strokeC; rf.inset(strokeW / 2, strokeW / 2); c.drawRoundRect(rf, radius, radius, kp)
    }
    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(cf: android.graphics.ColorFilter?) {}
    @Deprecated("Deprecated in Java") override fun getOpacity(): Int = android.graphics.PixelFormat.TRANSLUCENT
    override fun getOutline(outline: android.graphics.Outline) { outline.setRoundRect(bounds, radius) }
}
