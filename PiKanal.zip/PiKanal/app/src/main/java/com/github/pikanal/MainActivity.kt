package com.github.pikanal

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.tv.TvContract
import android.media.tv.TvInputInfo
import android.media.tv.TvInputManager
import android.media.tv.TvTrackInfo
import android.media.tv.TvView
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast

/**
 * PiKanal — basit, hızlı TV uygulaması (deneme).
 *
 * Beko kanal listesini dışarıya vermiyor, ama TV'nin alıcı servisi content://android.media.tv/channel/<kimlik>
 * adresiyle kanal açabiliyor. Geçerli kimlikleri bulmak için tarama yapılır: servis olmayan kimliğe hemen
 * "bilinmiyor" diye cevap veriyor, gerçek kanalda ise "kanal ayarlanıyor" diyor. Bulunan kimlikler sırayla
 * kanal listesi olur.
 *
 * Kumanda: P+/P- veya Yukarı/Aşağı = sonraki/önceki kanal, rakamlar = kanal numarası, OK = bilgi göster/gizle,
 * Menü = giriş (alıcı) değiştir, Sarı tuş veya 000 = yeniden tara, Geri = (taramada) taramayı durdur / çık.
 */
class MainActivity : Activity() {

    companion object {
        const val TAG = "PiKanal"
        const val MAX_ID = 20000L          // en fazla bu kimliğe kadar taranır
        const val GAP_AFTER = 1500L        // son bulunan kanaldan sonra bu kadar boş kimlik gelirse tarama biter
        const val MIN_SCAN = 3000L         // ama en az bu kimliğe kadar bakılır
        const val PROBE_TIMEOUT = 1500L    // servis bu sürede cevap vermezse kimlik boş sayılır
        const val SETTLE = 700L            // gerçek kanal bulunduktan sonra geç gelen olayların dinmesi için bekleme
    }

    private val ui = Handler(Looper.getMainLooper())
    // İki görüntü alanı: öndeki izlenen kanal, arkadaki (küçük ve sessiz) sıradaki kanalı önceden açık tutar.
    // P+'da yalnızca yer değiştirirler. TV iki alıcıya izin vermezse arka devre dışı kalır.
    private lateinit var views: Array<TvView>
    private var fi = 0
    private val tv get() = views[fi]
    private val back get() = views[1 - fi]
    private var preId = -1L
    private var preReady = false
    private var preAt = 0L
    private var prefetchOn = false            // denendi: Beko tek alıcılı, ikinci kanal öndekini kesiyor (0.5 kaydı)
    private var watchUntil = 0L               // arka açılınca ön kanal bozulursa çakışma sayılır
    private lateinit var info: TextView
    private lateinit var big: TextView
    private val prefs by lazy { getSharedPreferences("kanal", MODE_PRIVATE) }

    private var inputs: List<TvInputInfo> = emptyList()
    private var inputIdx = 0
    private var list = mutableListOf<Long>()   // geçerli kanal kimlikleri (sırayla)
    private var pos = 0                        // listede şu anki kanal
    private var tuneAt = 0L
    private var lastMs = -1L
    private var status = ""
    private var digits = ""
    private var toast: Toast? = null
    private var eatBackUp = false              // taramayı durduran Geri'nin bırakılışı uygulamayı kapatmasın

    // Tarama durumu
    private var scanning = false
    private var probeId = 0L
    private var probeDone = true
    private var lastFound = 0L
    private var scanStart = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        views = Array(2) { TvView(this).apply { isFocusable = false; isFocusableInTouchMode = false } }
        root.addView(views[0], fullLp())
        root.addView(views[1], tinyLp())
        val dp = resources.displayMetrics.density
        info = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 15f; typeface = Typeface.MONOSPACE
            setPadding((18 * dp).toInt(), (14 * dp).toInt(), (18 * dp).toInt(), (14 * dp).toInt())
            background = GradientDrawable().apply { setColor(0xCC101418.toInt()); cornerRadius = 14 * dp }
        }
        root.addView(info, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.START).apply {
            setMargins((28 * dp).toInt(), (24 * dp).toInt(), 0, 0) })
        big = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 44f; typeface = Typeface.DEFAULT_BOLD
            setShadowLayer(8f, 0f, 0f, Color.BLACK)
        }
        root.addView(big, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.END).apply {
            setMargins(0, (24 * dp).toInt(), (36 * dp).toInt(), 0) })
        setContentView(root)
        info.bringToFront(); big.bringToFront()
        info.elevation = 20 * dp; big.elevation = 20 * dp

        for (i in 0..1) views[i].setCallback(object : TvView.TvInputCallback() {
            override fun onConnectionFailed(inputId: String) = if (i == fi) ev("Bağlantı kurulamadı") else backEv("bağlantı kurulamadı", bad = true)
            override fun onDisconnected(inputId: String) = if (i == fi) frontLost("bağlantı koptu") else backEv("bağlantı koptu", bad = true)
            override fun onVideoAvailable(inputId: String) {
                if (i != fi) {
                    if (preId >= 0 && !preReady) { preReady = true; backEv("hazır, kimlik $preId (${SystemClock.elapsedRealtime() - preAt} ms)") }
                    return
                }
                if (scanning) return
                lastMs = SystemClock.elapsedRealtime() - tuneAt
                ev("Görüntü geldi ($lastMs ms)")
                schedulePrefetch()
            }
            override fun onVideoUnavailable(inputId: String, reason: Int) {
                if (i != fi) {
                    if (reason == 6) backEv("alıcı meşgul (TV ikinci alıcıya izin vermiyor)", bad = true)
                    else if (reason != 1) { preReady = false; backEv("görüntü yok: " + reasonName(reason)) }
                    return
                }
                if (scanning) { ui.post { probeResult(reason != 0) }; return }
                if (reason != 1 && lastMs >= 0) frontLost("görüntü gitti: " + reasonName(reason))
                else ev("Görüntü yok: " + reasonName(reason))
            }
            override fun onTracksChanged(inputId: String, tracks: MutableList<TvTrackInfo>?) {
                if (scanning || i != fi) return
                val a = tracks?.count { it.type == TvTrackInfo.TYPE_AUDIO } ?: 0
                val v = tracks?.count { it.type == TvTrackInfo.TYPE_VIDEO } ?: 0
                Log.i(TAG, "İzler: $v görüntü, $a ses")
            }
            override fun onContentBlocked(inputId: String, rating: android.media.tv.TvContentRating) { if (i == fi) ev("İçerik engellendi (ebeveyn kilidi)") }
        })

        val tim = getSystemService(TV_INPUT_SERVICE) as? TvInputManager
        val all = try { tim?.tvInputList ?: emptyList() } catch (e: Exception) { emptyList() }
        // Önce alıcılar (anten/uydu), sonra diğer girişler
        inputs = all.sortedBy { if (it.type == TvInputInfo.TYPE_TUNER) 0 else 1 }
        val saved = prefs.getString("input", null)
        inputIdx = inputs.indexOfFirst { it.id == saved }.takeIf { it >= 0 } ?: 0
        loadList()
        if (inputs.isEmpty()) ev("TV girişi bulunamadı")
    }

    override fun onStart() {
        super.onStart()
        if (list.isEmpty()) startScan() else tuneCurrent()
    }

    // Uygulamadan çıkınca alıcıyı bırak; yoksa TV'nin kendi uygulaması görüntü alamaz
    override fun onStop() {
        if (scanning) stopScan(save = true)
        ui.removeCallbacksAndMessages(null)
        cancelPrefetch()
        try { tv.reset() } catch (_: Exception) {}
        super.onStop()
    }

    // ---- Kanal listesi (giriş başına ayrı saklanır) ----
    private fun inputKey() = "list_" + (inputs.getOrNull(inputIdx)?.id ?: "")
    private fun loadList() {
        list = prefs.getString(inputKey(), "")!!.split(',').mapNotNull { it.toLongOrNull() }.toMutableList()
        pos = prefs.getInt(inputKey() + "_pos", 0).coerceIn(0, maxOf(0, list.size - 1))
    }
    private fun saveList() {
        prefs.edit().putString(inputKey(), list.joinToString(",")).putInt(inputKey() + "_pos", pos)
            .putString("input", inputs.getOrNull(inputIdx)?.id).apply()
    }

    private fun tuneCurrent() {
        val id = list.getOrNull(pos) ?: run { draw(); return }
        if (!scanning && preReady && preId == id) swap()
        else { cancelPrefetch(); tuneId(id) }
        prefs.edit().putInt(inputKey() + "_pos", pos).putString("input", inputs.getOrNull(inputIdx)?.id).apply()
        ev("Kanal ${pos + 1}", toastIt = true)
    }

    private fun tuneId(id: Long) {
        val inp = inputs.getOrNull(inputIdx) ?: return
        lastMs = -1; status = ""
        tuneAt = SystemClock.elapsedRealtime()
        try { tv.tune(inp.id, TvContract.buildChannelUri(id)); Log.i(TAG, "Açılıyor: kimlik $id") }
        catch (e: Exception) { ev("Hata: ${e.javaClass.simpleName} ${e.message}") }
    }

    // ---- Önceden açma (ikinci alıcı) ----
    private fun fullLp() = FrameLayout.LayoutParams(-1, -1)
    private fun tinyLp() = FrameLayout.LayoutParams(64, 36, Gravity.BOTTOM or Gravity.END)

    private val prefetchRun = Runnable { Log.i(TAG, "Arka: zamanlayıcı çalıştı"); prefetch() }
    private fun schedulePrefetch() {
        ui.removeCallbacks(prefetchRun)
        Log.i(TAG, "Arka: zamanlandı (açık=$prefetchOn)")
        if (prefetchOn) ui.postDelayed(prefetchRun, 1000)
    }

    private fun prefetch() {
        val inp = inputs.getOrNull(inputIdx) ?: run { Log.i(TAG, "Arka: giriş yok"); return }
        if (!prefetchOn || scanning || list.size < 2) { Log.i(TAG, "Arka: atlandı (açık=$prefetchOn tarama=$scanning liste=${list.size})"); return }
        val id = list[(pos + 1) % list.size]
        if (preId == id) { Log.i(TAG, "Arka: zaten açık $id"); return }
        preId = id; preReady = false; preAt = SystemClock.elapsedRealtime()
        watchUntil = preAt + 6000
        try {
            back.setStreamVolume(0f)
            back.tune(inp.id, TvContract.buildChannelUri(id))
            Log.i(TAG, "Arka: açılıyor kimlik $id")
        } catch (t: Throwable) { backEv("hata ${t.javaClass.simpleName} ${t.message}", bad = true) }
    }

    private fun cancelPrefetch() {
        ui.removeCallbacks(prefetchRun)
        if (preId >= 0) Log.i(TAG, "Arka: iptal ($preId)")
        if (preId >= 0) try { back.reset() } catch (_: Exception) {}
        preId = -1; preReady = false
    }

    private fun swap() {
        val old = tv
        fi = 1 - fi
        tv.layoutParams = fullLp(); old.layoutParams = tinyLp()
        tv.setStreamVolume(1f); old.setStreamVolume(0f)
        try { old.reset() } catch (_: Exception) {}
        preId = -1; preReady = false
        lastMs = 0; status = "Anlık geçiş (önceden hazırdı)"
        ev("Anlık geçiş")
        schedulePrefetch()
    }

    private fun backEv(msg: String, bad: Boolean = false) {
        Log.i(TAG, "Arka: $msg")
        if (bad && prefetchOn) {
            prefetchOn = false; cancelPrefetch()
            ev("İkinci alıcı kullanılamıyor: $msg", toastIt = true)
        }
    }

    // Arka açıldıktan kısa süre sonra öndeki kanal bozulduysa iki alıcı aynı anda çalışmıyor demektir
    private fun frontLost(why: String) {
        if (prefetchOn && preId >= 0 && SystemClock.elapsedRealtime() < watchUntil) {
            prefetchOn = false; cancelPrefetch()
            ev("ÇAKIŞMA: arka kanal öndekini kesti ($why) — ikinci alıcı kapatıldı", toastIt = true)
            tuneCurrent()
        } else ev("Ön: $why")
    }

    // ---- Tarama ----
    private fun startScan() {
        if (inputs.isEmpty()) return
        cancelPrefetch()
        scanning = true; list.clear(); pos = 0; lastFound = 0; probeId = 0; scanStart = SystemClock.elapsedRealtime()
        ev("Kanallar taranıyor… (Geri = durdur)", toastIt = true)
        nextProbe()
    }

    private fun nextProbe() {
        if (!scanning) return
        probeId++
        val done = probeId > MAX_ID || (probeId > MIN_SCAN && lastFound > 0 && probeId - lastFound > GAP_AFTER)
        if (done) { stopScan(save = true); return }
        probeDone = false
        tuneId(probeId)
        ui.removeCallbacks(probeTimeout); ui.postDelayed(probeTimeout, PROBE_TIMEOUT)
        if (probeId % 20 == 0L) draw()
    }

    private val probeTimeout = Runnable { probeResult(false) }

    private fun probeResult(valid: Boolean) {
        if (!scanning || probeDone) return
        probeDone = true
        ui.removeCallbacks(probeTimeout)
        if (valid) {
            list.add(probeId); lastFound = probeId
            Log.i(TAG, "Bulundu: kimlik $probeId (toplam ${list.size})")
            draw()
            ui.postDelayed({ nextProbe() }, SETTLE)
        } else ui.post { nextProbe() }
    }

    private fun stopScan(save: Boolean) {
        scanning = false
        ui.removeCallbacks(probeTimeout)
        val sec = (SystemClock.elapsedRealtime() - scanStart) / 1000
        if (save) saveList()
        ev("Tarama bitti: ${list.size} kanal ($sec sn)", toastIt = true)
        Log.i(TAG, "Liste: " + list.joinToString(","))
        pos = 0
        tuneCurrent()
    }

    // ---- Ekran ----
    private val log = ArrayDeque<String>()

    private fun ev(msg: String, toastIt: Boolean = false) {
        Log.i(TAG, msg)
        ui.post {
            log.addLast(msg); while (log.size > 5) log.removeFirst()
            if (lastMs >= 0) status = "Açılış süresi: $lastMs ms"
            if (toastIt) {
                toast?.cancel()
                toast = Toast.makeText(this, msg, Toast.LENGTH_SHORT).also { it.show() }
            }
            draw()
        }
    }

    private fun draw() {
        val inp = inputs.getOrNull(inputIdx)
        val name = inp?.let { (it.loadLabel(this)?.toString() ?: "?") + if (it.type == TvInputInfo.TYPE_TUNER) " (alıcı)" else "" } ?: "—"
        big.text = when {
            digits.isNotEmpty() -> "${digits}_"
            scanning -> "Taranıyor ${list.size}"
            list.isEmpty() -> "—"
            else -> (pos + 1).toString()
        }
        info.text = buildString {
            append("PiKanal\n")
            append("Giriş  : ").append(name).append("  [").append(inputIdx + 1).append('/').append(inputs.size).append("]\n")
            if (scanning) {
                append("Tarama : kimlik ").append(probeId).append(" · bulunan ").append(list.size).append('\n')
            } else {
                append("Kanal  : ").append(if (list.isEmpty()) "—" else "${pos + 1} / ${list.size}  (kimlik ${list[pos]})").append('\n')
                append("Durum  : ").append(status).append('\n')
            }
            append('\n'); log.forEach { append("• ").append(it).append('\n') }
            append("\nP+/P- kanal · Rakam · OK gizle · Menü giriş · Sarı/000 tara")
        }
    }

    // ---- Kumanda ----
    private val commitDigits = Runnable {
        val d = digits; digits = ""
        when {
            d == "000" -> startScan()
            else -> d.toIntOrNull()?.takeIf { it in 1..list.size }?.let { pos = it - 1; tuneCurrent() } ?: draw()
        }
    }

    // TvView tuşları önce TV servisine yollar ve servis yutabilir; bu yüzden tuşları pencereye ulaşır ulaşmaz yakala
    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        val k = event.keyCode
        if (event.action == KeyEvent.ACTION_DOWN) {
            Log.i(TAG, "Tuş: " + KeyEvent.keyCodeToString(k))
            if (handleKey(k, event.repeatCount)) return true
        } else if (event.action == KeyEvent.ACTION_UP && (isMine(k) || (k == KeyEvent.KEYCODE_BACK && eatBackUp))) {
            if (k == KeyEvent.KEYCODE_BACK) eatBackUp = false
            return true
        }
        return super.dispatchKeyEvent(event)
    }

    private fun isMine(k: Int) = k in KeyEvent.KEYCODE_0..KeyEvent.KEYCODE_9 || k in intArrayOf(
        KeyEvent.KEYCODE_CHANNEL_UP, KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_PAGE_UP,
        KeyEvent.KEYCODE_CHANNEL_DOWN, KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_PAGE_DOWN,
        KeyEvent.KEYCODE_MENU, KeyEvent.KEYCODE_TV_INPUT, KeyEvent.KEYCODE_PROG_YELLOW,
        KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_NUMPAD_ENTER)

    private fun handleKey(k: Int, repeat: Int): Boolean {
        if (scanning) {
            if (k == KeyEvent.KEYCODE_BACK) { eatBackUp = true; stopScan(save = true); return true }
            return isMine(k)
        }
        when (k) {
            KeyEvent.KEYCODE_CHANNEL_UP, KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_PAGE_UP -> {
                if (list.isNotEmpty()) { pos = (pos + 1) % list.size; tuneCurrent() }; return true }
            KeyEvent.KEYCODE_CHANNEL_DOWN, KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_PAGE_DOWN -> {
                if (list.isNotEmpty()) { pos = (pos - 1 + list.size) % list.size; tuneCurrent() }; return true }
            KeyEvent.KEYCODE_MENU, KeyEvent.KEYCODE_TV_INPUT -> {
                if (repeat == 0 && inputs.size > 1) {
                    inputIdx = (inputIdx + 1) % inputs.size; loadList()
                    if (list.isEmpty()) startScan() else tuneCurrent()
                }; return true }
            KeyEvent.KEYCODE_PROG_YELLOW -> { if (repeat == 0) startScan(); return true }
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_NUMPAD_ENTER -> {
                if (digits.isNotEmpty()) { ui.removeCallbacks(commitDigits); commitDigits.run() }
                else if (repeat == 0) info.visibility = if (info.visibility == View.VISIBLE) View.GONE else View.VISIBLE
                return true }
        }
        if (k in KeyEvent.KEYCODE_0..KeyEvent.KEYCODE_9) {
            if (digits.length < 4) digits += ('0' + (k - KeyEvent.KEYCODE_0))
            draw(); ui.removeCallbacks(commitDigits); ui.postDelayed(commitDigits, 1500); return true
        }
        return false
    }

    private fun reasonName(r: Int) = when (r) {
        0 -> "bilinmiyor"; 1 -> "kanal ayarlanıyor"; 2 -> "zayıf sinyal"; 3 -> "arabelleğe alıyor"
        4 -> "sadece ses"; 5 -> "bağlı değil"; 6 -> "alıcı meşgul"
        else -> "kod $r"
    }
}
