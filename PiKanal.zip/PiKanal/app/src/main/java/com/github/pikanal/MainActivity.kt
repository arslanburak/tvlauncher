package com.github.pikanal

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.tv.TvContract
import android.media.tv.TvInputInfo
import android.media.tv.TvInputManager
import android.media.tv.TvTrackInfo
import android.media.tv.TvView
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView

/**
 * PiKanal — deneme amaçlı basit TV uygulaması.
 *
 * Beko kanal listesini dışarıya vermediği için kanalları "kanal kimliği" (sayı) ile açmayı dener:
 * TV'nin alıcı servisine (TunerInputService) doğrudan bağlanır, content://android.media.tv/channel/<kimlik>
 * adresini ister ve servisin verdiği yanıtı (görüntü geldi / sinyal yok / bağlanamadı) ve
 * kanalın kaç milisaniyede açıldığını ekrana yazar.
 *
 * Kumanda: P+/P- veya Yukarı/Aşağı = sonraki/önceki kimlik, rakamlar = kimliği doğrudan yaz,
 * Sol/Sağ = açma yöntemi, Menü = giriş (alıcı) değiştir, OK = bilgi panelini gizle/göster, Geri = çık.
 */
class MainActivity : Activity() {

    private val ui = Handler(Looper.getMainLooper())
    private lateinit var tv: TvView
    private lateinit var info: TextView
    private lateinit var big: TextView
    private val prefs by lazy { getSharedPreferences("kanal", MODE_PRIVATE) }

    private var inputs: List<TvInputInfo> = emptyList()
    private var inputIdx = 0
    private var chId = 1L
    private var mode = 0              // 0 = kanal kimliği, 1 = doğrudan giriş (passthrough)
    private var tuneAt = 0L
    private var status = ""
    private var lastMs = -1L
    private var digits = ""
    private val log = ArrayDeque<String>()

    private val modes = arrayOf("Kanal kimliği (channel/N)", "Doğrudan giriş (passthrough)")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        tv = TvView(this)
        root.addView(tv, FrameLayout.LayoutParams(-1, -1))
        val dp = resources.displayMetrics.density
        info = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 15f; typeface = Typeface.MONOSPACE
            setPadding((18 * dp).toInt(), (14 * dp).toInt(), (18 * dp).toInt(), (14 * dp).toInt())
            background = GradientDrawable().apply { setColor(0xCC101418.toInt()); cornerRadius = 14 * dp }
        }
        root.addView(info, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.START).apply {
            setMargins((28 * dp).toInt(), (24 * dp).toInt(), 0, 0) })
        big = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 44f; typeface = Typeface.DEFAULT_BOLD
            setShadowLayer(8f, 0f, 0f, Color.BLACK)
        }
        root.addView(big, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.END).apply {
            setMargins(0, (24 * dp).toInt(), (36 * dp).toInt(), 0) })
        setContentView(root)

        tv.setCallback(object : TvView.TvInputCallback() {
            override fun onConnectionFailed(inputId: String) = ev("Bağlantı kurulamadı")
            override fun onDisconnected(inputId: String) = ev("Bağlantı koptu")
            override fun onChannelRetuned(inputId: String, channelUri: Uri?) = ev("Servis kanalı değiştirdi: $channelUri")
            override fun onVideoAvailable(inputId: String) {
                lastMs = SystemClock.elapsedRealtime() - tuneAt
                ev("GÖRÜNTÜ GELDİ ($lastMs ms)")
            }
            override fun onVideoUnavailable(inputId: String, reason: Int) = ev("Görüntü yok: " + reasonName(reason))
            override fun onVideoSizeChanged(inputId: String, width: Int, height: Int) = ev("Çözünürlük ${width}x$height")
            override fun onTracksChanged(inputId: String, tracks: MutableList<TvTrackInfo>?) {
                val a = tracks?.count { it.type == TvTrackInfo.TYPE_AUDIO } ?: 0
                val v = tracks?.count { it.type == TvTrackInfo.TYPE_VIDEO } ?: 0
                ev("İzler: $v görüntü, $a ses")
            }
            override fun onContentBlocked(inputId: String, rating: android.media.tv.TvContentRating) = ev("İçerik engellendi (ebeveyn kilidi)")
        })

        val tim = getSystemService(TV_INPUT_SERVICE) as? TvInputManager
        val all = try { tim?.tvInputList ?: emptyList() } catch (e: Exception) { emptyList() }
        // Önce alıcılar (anten/uydu), sonra diğer girişler (HDMI vb.)
        inputs = all.sortedBy { if (it.type == TvInputInfo.TYPE_TUNER) 0 else 1 }
        val saved = prefs.getString("input", null)
        inputIdx = inputs.indexOfFirst { it.id == saved }.takeIf { it >= 0 } ?: 0
        chId = prefs.getLong("ch", 1L)
        mode = prefs.getInt("mode", 0)
        if (inputs.isEmpty()) ev("TV girişi bulunamadı")
        ev("Okunabilen kanal sayısı: " + countChannels())
    }

    override fun onStart() { super.onStart(); tune() }

    // Uygulamadan çıkınca alıcıyı bırak; yoksa TV'nin kendi uygulaması görüntü alamaz
    override fun onStop() { ui.removeCallbacksAndMessages(null); try { tv.reset() } catch (_: Exception) {}; super.onStop() }

    private fun countChannels(): String = try {
        contentResolver.query(TvContract.Channels.CONTENT_URI, arrayOf(TvContract.Channels._ID), null, null, null)
            ?.use { it.count.toString() } ?: "yok"
    } catch (e: Exception) { "izin yok" }

    private fun tune() {
        val inp = inputs.getOrNull(inputIdx) ?: run { draw(); return }
        val uri = if (mode == 0) TvContract.buildChannelUri(chId) else TvContract.buildChannelUriForPassthroughInput(inp.id)
        prefs.edit().putString("input", inp.id).putLong("ch", chId).putInt("mode", mode).apply()
        status = ""; lastMs = -1
        log.clear()
        tuneAt = SystemClock.elapsedRealtime()
        try { tv.tune(inp.id, uri); ev("Açılıyor: $uri") } catch (e: Exception) { ev("Hata: ${e.javaClass.simpleName} ${e.message}") }
        ui.removeCallbacks(waitTick); ui.postDelayed(waitTick, 500)
    }

    // Görüntü gelene kadar geçen süreyi canlı göster
    private val waitTick = object : Runnable {
        override fun run() {
            if (lastMs < 0) {
                val s = (SystemClock.elapsedRealtime() - tuneAt) / 1000.0
                status = "Bekleniyor… " + String.format("%.1f", s) + " sn"
                draw()
                if (s < 30) ui.postDelayed(this, 500)
            }
        }
    }

    private fun ev(msg: String) {
        ui.post {
            log.addLast(msg); while (log.size > 7) log.removeFirst()
            if (lastMs >= 0) status = "Açılış süresi: $lastMs ms"
            draw()
        }
    }

    private fun draw() {
        val inp = inputs.getOrNull(inputIdx)
        val name = inp?.let { (it.loadLabel(this)?.toString() ?: "?") + if (it.type == TvInputInfo.TYPE_TUNER) " (alıcı)" else "" } ?: "—"
        big.text = if (digits.isNotEmpty()) "${digits}_" else if (mode == 0) chId.toString() else "▶"
        info.text = buildString {
            append("PiKanal deneme\n")
            append("Giriş  : ").append(name).append("  [").append(inputIdx + 1).append('/').append(inputs.size).append("]\n")
            append("Yöntem : ").append(modes[mode]).append('\n')
            if (mode == 0) append("Kimlik : ").append(chId).append('\n')
            append("Durum  : ").append(status).append("\n\n")
            log.forEach { append("• ").append(it).append('\n') }
            append("\nP+/P- kimlik · Rakam yaz · ◀▶ yöntem · Menü giriş · OK gizle")
        }
    }

    private val commitDigits = Runnable {
        digits.toLongOrNull()?.takeIf { it > 0 }?.let { chId = it; digits = ""; tune() } ?: run { digits = ""; draw() }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        when (keyCode) {
            KeyEvent.KEYCODE_CHANNEL_UP, KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_PAGE_UP -> {
                if (mode == 0) { chId++; tune() }; return true }
            KeyEvent.KEYCODE_CHANNEL_DOWN, KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_PAGE_DOWN -> {
                if (mode == 0 && chId > 1) { chId--; tune() }; return true }
            KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT -> {
                mode = 1 - mode; tune(); return true }
            KeyEvent.KEYCODE_MENU, KeyEvent.KEYCODE_TV_INPUT, KeyEvent.KEYCODE_INFO, KeyEvent.KEYCODE_PROG_RED -> {
                if (inputs.isNotEmpty()) { inputIdx = (inputIdx + 1) % inputs.size; tune() }; return true }
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_NUMPAD_ENTER -> {
                if (digits.isNotEmpty()) { ui.removeCallbacks(commitDigits); commitDigits.run() }
                else info.visibility = if (info.visibility == View.VISIBLE) View.GONE else View.VISIBLE
                return true }
        }
        if (keyCode in KeyEvent.KEYCODE_0..KeyEvent.KEYCODE_9 && mode == 0) {
            if (digits.length < 6) digits += ('0' + (keyCode - KeyEvent.KEYCODE_0))
            draw(); ui.removeCallbacks(commitDigits); ui.postDelayed(commitDigits, 1500); return true
        }
        return super.onKeyDown(keyCode, event)
    }

    private fun reasonName(r: Int) = when (r) {
        0 -> "bilinmiyor"; 1 -> "kanal ayarlanıyor"; 2 -> "zayıf sinyal"; 3 -> "arabelleğe alıyor"
        4 -> "sadece ses"; 5 -> "bağlı değil"; 6 -> "alıcı meşgul"
        else -> "kod $r"
    }
}
